<?php
/*
Template Name: Search results
*/
get_template_part('blog');
?>