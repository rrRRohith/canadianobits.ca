<?php
/*
Template Name: Only Audio
*/

global $ANCORA_GLOBALS;
$ANCORA_GLOBALS['blog_filters'] = 'audio';

get_template_part('blog');
?>