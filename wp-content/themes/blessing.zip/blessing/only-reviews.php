<?php
/*
Template Name: Only Reviews
*/

global $ANCORA_GLOBALS;
$ANCORA_GLOBALS['blog_filters'] = 'reviews';

get_template_part('blog');
?>