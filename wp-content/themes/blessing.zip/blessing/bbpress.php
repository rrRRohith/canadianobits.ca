<?php
/*
Template Name: bbPress page
*/

get_template_part('single');
?>
