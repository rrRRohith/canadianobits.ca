<?php

// Check if shortcodes settings are now used
if ( !function_exists( 'ancora_shortcodes_is_used' ) ) {
	function ancora_shortcodes_is_used() {
		return ancora_options_is_used() 															// All modes when Theme Options are used
			|| (is_admin() && isset($_POST['action']) 
					&& in_array($_POST['action'], array('vc_edit_form', 'wpb_show_edit_form')))		// AJAX query when save post/page
			|| ancora_vc_is_frontend();															// VC Frontend editor mode
	}
}

// Width and height params
if ( !function_exists( 'ancora_shortcodes_width' ) ) {
	function ancora_shortcodes_width($w="") {
		return array(
			"title" => __("Width", 'blessing'),
			"divider" => true,
			"value" => $w,
			"type" => "text"
		);
	}
}
if ( !function_exists( 'ancora_shortcodes_height' ) ) {
	function ancora_shortcodes_height($h='') {
		return array(
			"title" => __("Height", 'blessing'),
			"desc" => __("Width (in pixels or percent) and height (only in pixels) of element", 'blessing'),
			"value" => $h,
			"type" => "text"
		);
	}
}

/* Theme setup section
-------------------------------------------------------------------- */

if ( !function_exists( 'ancora_shortcodes_settings_theme_setup' ) ) {
//	if ( ancora_vc_is_frontend() )
	if ( (isset($_GET['vc_editable']) && $_GET['vc_editable']=='true') || (isset($_GET['vc_action']) && $_GET['vc_action']=='vc_inline') )
		add_action( 'ancora_action_before_init_theme', 'ancora_shortcodes_settings_theme_setup', 20 );
	else
		add_action( 'ancora_action_after_init_theme', 'ancora_shortcodes_settings_theme_setup' );
	function ancora_shortcodes_settings_theme_setup() {
		if (ancora_shortcodes_is_used()) {
			global $ANCORA_GLOBALS;

			// Prepare arrays 
			$ANCORA_GLOBALS['sc_params'] = array(
			
				// Current element id
				'id' => array(
					"title" => __("Element ID", 'blessing'),
					"desc" => __("ID for current element", 'blessing'),
					"divider" => true,
					"value" => "",
					"type" => "text"
				),
			
				// Current element class
				'class' => array(
					"title" => __("Element CSS class", 'blessing'),
					"desc" => __("CSS class for current element (optional)", 'blessing'),
					"value" => "",
					"type" => "text"
				),
			
				// Current element style
				'css' => array(
					"title" => __("CSS styles", 'blessing'),
					"desc" => __("Any additional CSS rules (if need)", 'blessing'),
					"value" => "",
					"type" => "text"
				),
			
				// Margins params
				'top' => array(
					"title" => __("Top margin", 'blessing'),
					"divider" => true,
					"value" => "",
					"type" => "text"
				),
			
				'bottom' => array(
					"title" => __("Bottom margin", 'blessing'),
					"value" => "",
					"type" => "text"
				),
			
				'left' => array(
					"title" => __("Left margin", 'blessing'),
					"value" => "",
					"type" => "text"
				),
			
				'right' => array(
					"title" => __("Right margin", 'blessing'),
					"desc" => __("Margins around list (in pixels).", 'blessing'),
					"value" => "",
					"type" => "text"
				),
			
				// Switcher choises
				'list_styles' => array(
					'ul'	=> __('Unordered', 'blessing'),
					'ol'	=> __('Ordered', 'blessing'),
					'iconed'=> __('Iconed', 'blessing')
				),
				'yes_no'	=> ancora_get_list_yesno(),
				'on_off'	=> ancora_get_list_onoff(),
				'dir' 		=> ancora_get_list_directions(),
				'align'		=> ancora_get_list_alignments(),
				'float'		=> ancora_get_list_floats(),
				'show_hide'	=> ancora_get_list_showhide(),
				'sorting' 	=> ancora_get_list_sortings(),
				'ordering' 	=> ancora_get_list_orderings(),
				'sliders'	=> ancora_get_list_sliders(),
				'users'		=> ancora_get_list_users(),
				'members'	=> ancora_get_list_posts(false, array('post_type'=>'team', 'orderby'=>'title', 'order'=>'asc', 'return'=>'title')),
				'categories'=> ancora_get_list_categories(),
				'testimonials_groups'=> ancora_get_list_terms(false, 'testimonial_group'),
				'team_groups'=> ancora_get_list_terms(false, 'team_group'),
				'columns'	=> ancora_get_list_columns(),
				'images'	=> array_merge(array('none'=>"none"), ancora_get_list_files("images/icons", "png")),
				'icons'		=> array_merge(array("inherit", "none"), ancora_get_list_icons()),
				'locations'	=> ancora_get_list_dedicated_locations(),
				'filters'	=> ancora_get_list_portfolio_filters(),
				'formats'	=> ancora_get_list_post_formats_filters(),
				'hovers'	=> ancora_get_list_hovers(),
				'hovers_dir'=> ancora_get_list_hovers_directions(),
				'tint'		=> ancora_get_list_bg_tints(),
				'animations'=> ancora_get_list_animations_in(),
				'blogger_styles'	=> ancora_get_list_templates_blogger(),
				'posts_types'		=> ancora_get_list_posts_types(),
				'button_styles'		=> ancora_get_list_button_styles(),
				'googlemap_styles'	=> ancora_get_list_googlemap_styles(),
				'field_types'		=> ancora_get_list_field_types(),
				'label_positions'	=> ancora_get_list_label_positions()
			);

			$ANCORA_GLOBALS['sc_params']['animation'] = array(
				"title" => __("Animation",  'blessing'),
				"desc" => __('Select animation while object enter in the visible area of page',  'blessing'),
				"value" => "none",
				"type" => "select",
				"options" => $ANCORA_GLOBALS['sc_params']['animations']
			);
	
			// Shortcodes list
			//------------------------------------------------------------------
			$ANCORA_GLOBALS['shortcodes'] = array(
			
				// Accordion
				"trx_accordion" => array(
					"title" => __("Accordion", 'blessing'),
					"desc" => __("Accordion items", 'blessing'),
					"decorate" => true,
					"container" => false,
					"params" => array(
						"style" => array(
							"title" => __("Accordion style", 'blessing'),
							"desc" => __("Select style for display accordion", 'blessing'),
							"value" => 1,
							"options" => array(
								1 => __('Style 1', 'blessing'),
								2 => __('Style 2', 'blessing')
							),
							"type" => "radio"
						),
						"counter" => array(
							"title" => __("Counter", 'blessing'),
							"desc" => __("Display counter before each accordion title", 'blessing'),
							"value" => "off",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['on_off']
						),
						"initial" => array(
							"title" => __("Initially opened item", 'blessing'),
							"desc" => __("Number of initially opened item", 'blessing'),
							"value" => 1,
							"min" => 0,
							"type" => "spinner"
						),
						"icon_closed" => array(
							"title" => __("Icon while closed",  'blessing'),
							"desc" => __('Select icon for the closed accordion item from Fontello icons set',  'blessing'),
							"value" => "",
							"type" => "icons",
							"options" => $ANCORA_GLOBALS['sc_params']['icons']
						),
						"icon_opened" => array(
							"title" => __("Icon while opened",  'blessing'),
							"desc" => __('Select icon for the opened accordion item from Fontello icons set',  'blessing'),
							"value" => "",
							"type" => "icons",
							"options" => $ANCORA_GLOBALS['sc_params']['icons']
						),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					),
					"children" => array(
						"name" => "trx_accordion_item",
						"title" => __("Item", 'blessing'),
						"desc" => __("Accordion item", 'blessing'),
						"container" => true,
						"params" => array(
							"title" => array(
								"title" => __("Accordion item title", 'blessing'),
								"desc" => __("Title for current accordion item", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"icon_closed" => array(
								"title" => __("Icon while closed",  'blessing'),
								"desc" => __('Select icon for the closed accordion item from Fontello icons set',  'blessing'),
								"value" => "",
								"type" => "icons",
								"options" => $ANCORA_GLOBALS['sc_params']['icons']
							),
							"icon_opened" => array(
								"title" => __("Icon while opened",  'blessing'),
								"desc" => __('Select icon for the opened accordion item from Fontello icons set',  'blessing'),
								"value" => "",
								"type" => "icons",
								"options" => $ANCORA_GLOBALS['sc_params']['icons']
							),
							"_content_" => array(
								"title" => __("Accordion item content", 'blessing'),
								"desc" => __("Current accordion item content", 'blessing'),
								"rows" => 4,
								"value" => "",
								"type" => "textarea"
							),
							"id" => $ANCORA_GLOBALS['sc_params']['id'],
							"class" => $ANCORA_GLOBALS['sc_params']['class'],
							"css" => $ANCORA_GLOBALS['sc_params']['css']
						)
					)
				),
			
			
			
			
				// Anchor
				"trx_anchor" => array(
					"title" => __("Anchor", 'blessing'),
					"desc" => __("Insert anchor for the TOC (table of content)", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"icon" => array(
							"title" => __("Anchor's icon",  'blessing'),
							"desc" => __('Select icon for the anchor from Fontello icons set',  'blessing'),
							"value" => "",
							"type" => "icons",
							"options" => $ANCORA_GLOBALS['sc_params']['icons']
						),
						"title" => array(
							"title" => __("Short title", 'blessing'),
							"desc" => __("Short title of the anchor (for the table of content)", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"description" => array(
							"title" => __("Long description", 'blessing'),
							"desc" => __("Description for the popup (then hover on the icon). You can use '{' and '}' - make the text italic, '|' - insert line break", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"url" => array(
							"title" => __("External URL", 'blessing'),
							"desc" => __("External URL for this TOC item", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"separator" => array(
							"title" => __("Add separator", 'blessing'),
							"desc" => __("Add separator under item in the TOC", 'blessing'),
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"id" => $ANCORA_GLOBALS['sc_params']['id']
					)
				),
			
			
				// Audio
				"trx_audio" => array(
					"title" => __("Audio", 'blessing'),
					"desc" => __("Insert audio player", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"url" => array(
							"title" => __("URL for audio file", 'blessing'),
							"desc" => __("URL for audio file", 'blessing'),
							"readonly" => false,
							"value" => "",
							"type" => "media",
							"before" => array(
								'title' => __('Choose audio', 'blessing'),
								'action' => 'media_upload',
								'type' => 'audio',
								'multiple' => false,
								'linked_field' => '',
								'captions' => array( 	
									'choose' => __('Choose audio file', 'blessing'),
									'update' => __('Select audio file', 'blessing')
								)
							),
							"after" => array(
								'icon' => 'icon-cancel',
								'action' => 'media_reset'
							)
						),
                        "style" => array(
                            "title" => __("Style", 'blessing'),
                            "desc" => __("Select style", 'blessing'),
                            "value" => "none",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => array('audio_normal' => 'Normal', 'audio_dark' => 'Dark'),
                        ),
						"image" => array(
							"title" => __("Cover image", 'blessing'),
							"desc" => __("Select or upload image or write URL from other site for audio cover", 'blessing'),
							"readonly" => false,
							"value" => "",
							"type" => "media"
						),
						"title" => array(
							"title" => __("Title", 'blessing'),
							"desc" => __("Title of the audio file", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "text"
						),
						"author" => array(
							"title" => __("Author", 'blessing'),
							"desc" => __("Author of the audio file", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"controls" => array(
							"title" => __("Show controls", 'blessing'),
							"desc" => __("Show controls in audio player", 'blessing'),
							"divider" => true,
							"size" => "medium",
							"value" => "show",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['show_hide']
						),
						"autoplay" => array(
							"title" => __("Autoplay audio", 'blessing'),
							"desc" => __("Autoplay audio on page load", 'blessing'),
							"value" => "off",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['on_off']
						),
						"align" => array(
							"title" => __("Align", 'blessing'),
							"desc" => __("Select block alignment", 'blessing'),
							"value" => "none",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
				// Block
				"trx_block" => array(
					"title" => __("Block container", 'blessing'),
					"desc" => __("Container for any block ([section] analog - to enable nesting)", 'blessing'),
					"decorate" => true,
					"container" => true,
					"params" => array(
						"dedicated" => array(
							"title" => __("Dedicated", 'blessing'),
							"desc" => __("Use this block as dedicated content - show it before post title on single page", 'blessing'),
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"align" => array(
							"title" => __("Align", 'blessing'),
							"desc" => __("Select block alignment", 'blessing'),
							"value" => "none",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						),
						"columns" => array(
							"title" => __("Columns emulation", 'blessing'),
							"desc" => __("Select width for columns emulation", 'blessing'),
							"value" => "none",
							"type" => "checklist",
							"options" => $ANCORA_GLOBALS['sc_params']['columns']
						), 
						"pan" => array(
							"title" => __("Use pan effect", 'blessing'),
							"desc" => __("Use pan effect to show section content", 'blessing'),
							"divider" => true,
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"scroll" => array(
							"title" => __("Use scroller", 'blessing'),
							"desc" => __("Use scroller to show section content", 'blessing'),
							"divider" => true,
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"scroll_dir" => array(
							"title" => __("Scroll direction", 'blessing'),
							"desc" => __("Scroll direction (if Use scroller = yes)", 'blessing'),
							"dependency" => array(
								'scroll' => array('yes')
							),
							"value" => "horizontal",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['dir']
						),
						"scroll_controls" => array(
							"title" => __("Scroll controls", 'blessing'),
							"desc" => __("Show scroll controls (if Use scroller = yes)", 'blessing'),
							"dependency" => array(
								'scroll' => array('yes')
							),
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"color" => array(
							"title" => __("Fore color", 'blessing'),
							"desc" => __("Any color for objects in this section", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "color"
						),
						"bg_tint" => array(
							"title" => __("Background tint", 'blessing'),
							"desc" => __("Main background tint: dark or light", 'blessing'),
							"value" => "",
							"type" => "checklist",
							"options" => $ANCORA_GLOBALS['sc_params']['tint']
						),
						"bg_color" => array(
							"title" => __("Background color", 'blessing'),
							"desc" => __("Any background color for this section", 'blessing'),
							"value" => "",
							"type" => "color"
						),
						"bg_image" => array(
							"title" => __("Background image URL", 'blessing'),
							"desc" => __("Select or upload image or write URL from other site for the background", 'blessing'),
							"readonly" => false,
							"value" => "",
							"type" => "media"
						),
						"bg_overlay" => array(
							"title" => __("Overlay", 'blessing'),
							"desc" => __("Overlay color opacity (from 0.0 to 1.0)", 'blessing'),
							"min" => "0",
							"max" => "1",
							"step" => "0.1",
							"value" => "0",
							"type" => "spinner"
						),
						"bg_texture" => array(
							"title" => __("Texture", 'blessing'),
							"desc" => __("Predefined texture style from 1 to 11. 0 - without texture.", 'blessing'),
							"min" => "0",
							"max" => "11",
							"step" => "1",
							"value" => "0",
							"type" => "spinner"
						),
						"font_size" => array(
							"title" => __("Font size", 'blessing'),
							"desc" => __("Font size of the text (default - in pixels, allows any CSS units of measure)", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"font_weight" => array(
							"title" => __("Font weight", 'blessing'),
							"desc" => __("Font weight of the text", 'blessing'),
							"value" => "",
							"type" => "select",
							"size" => "medium",
							"options" => array(
								'100' => __('Thin (100)', 'blessing'),
								'300' => __('Light (300)', 'blessing'),
								'400' => __('Normal (400)', 'blessing'),
								'700' => __('Bold (700)', 'blessing')
							)
						),
						"_content_" => array(
							"title" => __("Container content", 'blessing'),
							"desc" => __("Content for section container", 'blessing'),
							"divider" => true,
							"rows" => 4,
							"value" => "",
							"type" => "textarea"
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
				// Blogger
				"trx_blogger" => array(
					"title" => __("Blogger", 'blessing'),
					"desc" => __("Insert posts (pages) in many styles from desired categories or directly from ids", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"style" => array(
							"title" => __("Posts output style", 'blessing'),
							"desc" => __("Select desired style for posts output", 'blessing'),
							"value" => "regular",
							"type" => "select",
							"options" => $ANCORA_GLOBALS['sc_params']['blogger_styles']
						),
						"filters" => array(
							"title" => __("Show filters", 'blessing'),
							"desc" => __("Use post's tags or categories as filter buttons", 'blessing'),
							"value" => "no",
							"dir" => "horizontal",
							"type" => "checklist",
							"options" => $ANCORA_GLOBALS['sc_params']['filters']
						),
						"hover" => array(
							"title" => __("Hover effect", 'blessing'),
							"desc" => __("Select hover effect (only if style=Portfolio)", 'blessing'),
							"dependency" => array(
								'style' => array('portfolio','grid','square','courses')
							),
							"value" => "",
							"type" => "select",
							"options" => $ANCORA_GLOBALS['sc_params']['hovers']
						),
						"hover_dir" => array(
							"title" => __("Hover direction", 'blessing'),
							"desc" => __("Select hover direction (only if style=Portfolio and hover=Circle|Square)", 'blessing'),
							"dependency" => array(
								'style' => array('portfolio','grid','square','courses'),
								'hover' => array('square','circle')
							),
							"value" => "left_to_right",
							"type" => "select",
							"options" => $ANCORA_GLOBALS['sc_params']['hovers_dir']
						),
						"dir" => array(
							"title" => __("Posts direction", 'blessing'),
							"desc" => __("Display posts in horizontal or vertical direction", 'blessing'),
							"value" => "horizontal",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['dir']
						),
						"post_type" => array(
							"title" => __("Post type", 'blessing'),
							"desc" => __("Select post type to show", 'blessing'),
							"value" => "post",
							"type" => "select",
							"options" => $ANCORA_GLOBALS['sc_params']['posts_types']
						),
						"ids" => array(
							"title" => __("Post IDs list", 'blessing'),
							"desc" => __("Comma separated list of posts ID. If set - parameters above are ignored!", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"cat" => array(
							"title" => __("Categories list", 'blessing'),
							"desc" => __("Select the desired categories. If not selected - show posts from any category or from IDs list", 'blessing'),
							"dependency" => array(
								'ids' => array('is_empty'),
								'post_type' => array('refresh')
							),
							"divider" => true,
							"value" => "",
							"type" => "select",
							"style" => "list",
							"multiple" => true,
							"options" => $ANCORA_GLOBALS['sc_params']['categories']
						),
						"count" => array(
							"title" => __("Total posts to show", 'blessing'),
							"desc" => __("How many posts will be displayed? If used IDs - this parameter ignored.", 'blessing'),
							"dependency" => array(
								'ids' => array('is_empty')
							),
							"value" => 3,
							"min" => 1,
							"max" => 100,
							"type" => "spinner"
						),
						"columns" => array(
							"title" => __("Columns number", 'blessing'),
							"desc" => __("How many columns used to show posts? If empty or 0 - equal to posts number", 'blessing'),
							"dependency" => array(
								'dir' => array('horizontal')
							),
							"value" => 3,
							"min" => 1,
							"max" => 100,
							"type" => "spinner"
						),
						"offset" => array(
							"title" => __("Offset before select posts", 'blessing'),
							"desc" => __("Skip posts before select next part.", 'blessing'),
							"dependency" => array(
								'ids' => array('is_empty')
							),
							"value" => 0,
							"min" => 0,
							"max" => 100,
							"type" => "spinner"
						),
						"orderby" => array(
							"title" => __("Post order by", 'blessing'),
							"desc" => __("Select desired posts sorting method", 'blessing'),
							"value" => "date",
							"type" => "select",
							"options" => $ANCORA_GLOBALS['sc_params']['sorting']
						),
						"order" => array(
							"title" => __("Post order", 'blessing'),
							"desc" => __("Select desired posts order", 'blessing'),
							"value" => "desc",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['ordering']
						),
						"only" => array(
							"title" => __("Select posts only", 'blessing'),
							"desc" => __("Select posts only with reviews, videos, audios, thumbs or galleries", 'blessing'),
							"value" => "no",
							"type" => "select",
							"options" => $ANCORA_GLOBALS['sc_params']['formats']
						),
						"scroll" => array(
							"title" => __("Use scroller", 'blessing'),
							"desc" => __("Use scroller to show all posts", 'blessing'),
							"divider" => true,
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"controls" => array(
							"title" => __("Show slider controls", 'blessing'),
							"desc" => __("Show arrows to control scroll slider", 'blessing'),
							"dependency" => array(
								'scroll' => array('yes')
							),
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"location" => array(
							"title" => __("Dedicated content location", 'blessing'),
							"desc" => __("Select position for dedicated content (only for style=excerpt)", 'blessing'),
							"divider" => true,
							"dependency" => array(
								'style' => array('excerpt')
							),
							"value" => "default",
							"type" => "select",
							"options" => $ANCORA_GLOBALS['sc_params']['locations']
						),
						"rating" => array(
							"title" => __("Show rating stars", 'blessing'),
							"desc" => __("Show rating stars under post's header", 'blessing'),
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"info" => array(
							"title" => __("Show post info block", 'blessing'),
							"desc" => __("Show post info block (author, date, tags, etc.)", 'blessing'),
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"links" => array(
							"title" => __("Allow links on the post", 'blessing'),
							"desc" => __("Allow links on the post from each blogger item", 'blessing'),
							"value" => "yes",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"descr" => array(
							"title" => __("Description length", 'blessing'),
							"desc" => __("How many characters are displayed from post excerpt? If 0 - don't show description", 'blessing'),
							"value" => 0,
							"min" => 0,
							"step" => 10,
							"type" => "spinner"
						),
						"readmore" => array(
							"title" => __("More link text", 'blessing'),
							"desc" => __("Read more link text. If empty - show 'More', else - used as link text", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
			
				// Br
				"trx_br" => array(
					"title" => __("Break", 'blessing'),
					"desc" => __("Line break with clear floating (if need)", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"clear" => 	array(
							"title" => __("Clear floating", 'blessing'),
							"desc" => __("Clear floating (if need)", 'blessing'),
							"value" => "",
							"type" => "checklist",
							"options" => array(
								'none' => __('None', 'blessing'),
								'left' => __('Left', 'blessing'),
								'right' => __('Right', 'blessing'),
								'both' => __('Both', 'blessing')
							)
						)
					)
				),
			
			
			
			
				// Button
				"trx_button" => array(
					"title" => __("Button", 'blessing'),
					"desc" => __("Button with link", 'blessing'),
					"decorate" => false,
					"container" => true,
					"params" => array(
						"_content_" => array(
							"title" => __("Caption", 'blessing'),
							"desc" => __("Button caption", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"type" => array(
							"title" => __("Button's shape", 'blessing'),
							"desc" => __("Select button's shape", 'blessing'),
							"value" => "square",
							"size" => "medium",
							"options" => array(
								'square' => __('Square', 'blessing'),
								'round' => __('Round', 'blessing')
							),
							"type" => "switch"
						), 
						"style" => array(
							"title" => __("Button's style", 'blessing'),
							"desc" => __("Select button's style", 'blessing'),
							"value" => "default",
							"dir" => "horizontal",
							"options" => array(
								'dark' => __('Dark', 'blessing'),
								'light' => __('Light', 'blessing'),
                                'global' => __('Global', 'blessing')
							),
							"type" => "checklist"
						), 
						"size" => array(
							"title" => __("Button's size", 'blessing'),
							"desc" => __("Select button's size", 'blessing'),
							"value" => "small",
							"dir" => "horizontal",
							"options" => array(
								'small' => __('Small', 'blessing'),
								'medium' => __('Medium', 'blessing'),
								'large' => __('Large', 'blessing')
							),
							"type" => "checklist"
						), 
						"icon" => array(
							"title" => __("Button's icon",  'blessing'),
							"desc" => __('Select icon for the title from Fontello icons set',  'blessing'),
							"value" => "",
							"type" => "icons",
							"options" => $ANCORA_GLOBALS['sc_params']['icons']
						),
						"bg_style" => array(
							"title" => __("Button's color scheme", 'blessing'),
							"desc" => __("Select button's color scheme", 'blessing'),
							"value" => "custom",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['button_styles']
						), 
						"color" => array(
							"title" => __("Button's text color", 'blessing'),
							"desc" => __("Any color for button's caption", 'blessing'),
							"value" => "",
							"type" => "color"
						),
						"bg_color" => array(
							"title" => __("Button's backcolor", 'blessing'),
							"desc" => __("Any color for button's background", 'blessing'),
							"value" => "",
							"type" => "color"
						),
						"align" => array(
							"title" => __("Button's alignment", 'blessing'),
							"desc" => __("Align button to left, center or right", 'blessing'),
							"value" => "none",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						), 
						"link" => array(
							"title" => __("Link URL", 'blessing'),
							"desc" => __("URL for link on button click", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "text"
						),
						"target" => array(
							"title" => __("Link target", 'blessing'),
							"desc" => __("Target for link on button click", 'blessing'),
							"dependency" => array(
								'link' => array('not_empty')
							),
							"value" => "",
							"type" => "text"
						),
						"popup" => array(
							"title" => __("Open link in popup", 'blessing'),
							"desc" => __("Open link target in popup window", 'blessing'),
							"dependency" => array(
								'link' => array('not_empty')
							),
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						), 
						"rel" => array(
							"title" => __("Rel attribute", 'blessing'),
							"desc" => __("Rel attribute for button's link (if need)", 'blessing'),
							"dependency" => array(
								'link' => array('not_empty')
							),
							"value" => "",
							"type" => "text"
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
				// Chat
				"trx_chat" => array(
					"title" => __("Chat", 'blessing'),
					"desc" => __("Chat message", 'blessing'),
					"decorate" => true,
					"container" => true,
					"params" => array(
						"title" => array(
							"title" => __("Item title", 'blessing'),
							"desc" => __("Chat item title", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"photo" => array(
							"title" => __("Item photo", 'blessing'),
							"desc" => __("Select or upload image or write URL from other site for the item photo (avatar)", 'blessing'),
							"readonly" => false,
							"value" => "",
							"type" => "media"
						),
						"link" => array(
							"title" => __("Item link", 'blessing'),
							"desc" => __("Chat item link", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"_content_" => array(
							"title" => __("Chat item content", 'blessing'),
							"desc" => __("Current chat item content", 'blessing'),
							"rows" => 4,
							"value" => "",
							"type" => "textarea"
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
				// Columns
				"trx_columns" => array(
					"title" => __("Columns", 'blessing'),
					"desc" => __("Insert up to 5 columns in your page (post)", 'blessing'),
					"decorate" => true,
					"container" => false,
					"params" => array(
						"fluid" => array(
							"title" => __("Fluid columns", 'blessing'),
							"desc" => __("To squeeze the columns when reducing the size of the window (fluid=yes) or to rebuild them (fluid=no)", 'blessing'),
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						), 
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					),
					"children" => array(
						"name" => "trx_column_item",
						"title" => __("Column", 'blessing'),
						"desc" => __("Column item", 'blessing'),
						"container" => true,
						"params" => array(
							"span" => array(
								"title" => __("Merge columns", 'blessing'),
								"desc" => __("Count merged columns from current", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"align" => array(
								"title" => __("Alignment", 'blessing'),
								"desc" => __("Alignment text in the column", 'blessing'),
								"value" => "",
								"type" => "checklist",
								"dir" => "horizontal",
								"options" => $ANCORA_GLOBALS['sc_params']['align']
							),
							"color" => array(
								"title" => __("Fore color", 'blessing'),
								"desc" => __("Any color for objects in this column", 'blessing'),
								"value" => "",
								"type" => "color"
							),
							"bg_color" => array(
								"title" => __("Background color", 'blessing'),
								"desc" => __("Any background color for this column", 'blessing'),
								"value" => "",
								"type" => "color"
							),
							"bg_image" => array(
								"title" => __("URL for background image file", 'blessing'),
								"desc" => __("Select or upload image or write URL from other site for the background", 'blessing'),
								"readonly" => false,
								"value" => "",
								"type" => "media"
							),
							"_content_" => array(
								"title" => __("Column item content", 'blessing'),
								"desc" => __("Current column item content", 'blessing'),
								"divider" => true,
								"rows" => 4,
								"value" => "",
								"type" => "textarea"
							),
							"id" => $ANCORA_GLOBALS['sc_params']['id'],
							"class" => $ANCORA_GLOBALS['sc_params']['class'],
							"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
							"css" => $ANCORA_GLOBALS['sc_params']['css']
						)
					)
				),
			
			
			
			
				// Contact form
				"trx_contact_form" => array(
					"title" => __("Contact form", 'blessing'),
					"desc" => __("Insert contact form", 'blessing'),
					"decorate" => true,
					"container" => false,
					"params" => array(
						"custom" => array(
							"title" => __("Custom", 'blessing'),
							"desc" => __("Use custom fields or create standard contact form (ignore info from 'Field' tabs)", 'blessing'),
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						), 
						"action" => array(
							"title" => __("Action", 'blessing'),
							"desc" => __("Contact form action (URL to handle form data). If empty - use internal action", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "text"
						),
						"align" => array(
							"title" => __("Align", 'blessing'),
							"desc" => __("Select form alignment", 'blessing'),
							"value" => "none",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						),
						"title" => array(
							"title" => __("Title", 'blessing'),
							"desc" => __("Contact form title", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "text"
						),
						"description" => array(
							"title" => __("Description", 'blessing'),
							"desc" => __("Short description for contact form", 'blessing'),
							"divider" => true,
							"rows" => 4,
							"value" => "",
							"type" => "textarea"
						),
						"width" => ancora_shortcodes_width(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					),
					"children" => array(
						"name" => "trx_form_item",
						"title" => __("Field", 'blessing'),
						"desc" => __("Custom field", 'blessing'),
						"container" => false,
						"params" => array(
							"type" => array(
								"title" => __("Type", 'blessing'),
								"desc" => __("Type of the custom field", 'blessing'),
								"value" => "text",
								"type" => "checklist",
								"dir" => "horizontal",
								"options" => $ANCORA_GLOBALS['sc_params']['field_types']
							), 
							"name" => array(
								"title" => __("Name", 'blessing'),
								"desc" => __("Name of the custom field", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"value" => array(
								"title" => __("Default value", 'blessing'),
								"desc" => __("Default value of the custom field", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"label" => array(
								"title" => __("Label", 'blessing'),
								"desc" => __("Label for the custom field", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"label_position" => array(
								"title" => __("Label position", 'blessing'),
								"desc" => __("Label position relative to the field", 'blessing'),
								"value" => "top",
								"type" => "checklist",
								"dir" => "horizontal",
								"options" => $ANCORA_GLOBALS['sc_params']['label_positions']
							), 
							"top" => $ANCORA_GLOBALS['sc_params']['top'],
							"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
							"left" => $ANCORA_GLOBALS['sc_params']['left'],
							"right" => $ANCORA_GLOBALS['sc_params']['right'],
							"id" => $ANCORA_GLOBALS['sc_params']['id'],
							"class" => $ANCORA_GLOBALS['sc_params']['class'],
							"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
							"css" => $ANCORA_GLOBALS['sc_params']['css']
						)
					)
				),
			
			
			
			
				// Content block on fullscreen page
				"trx_content" => array(
					"title" => __("Content block", 'blessing'),
					"desc" => __("Container for main content block with desired class and style (use it only on fullscreen pages)", 'blessing'),
					"decorate" => true,
					"container" => true,
					"params" => array(
						"_content_" => array(
							"title" => __("Container content", 'blessing'),
							"desc" => __("Content for section container", 'blessing'),
							"divider" => true,
							"rows" => 4,
							"value" => "",
							"type" => "textarea"
						),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
			
				// Countdown
				"trx_countdown" => array(
					"title" => __("Countdown", 'blessing'),
					"desc" => __("Insert countdown object", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"date" => array(
							"title" => __("Date", 'blessing'),
							"desc" => __("Upcoming date (format: yyyy-mm-dd)", 'blessing'),
							"value" => "",
							"format" => "yy-mm-dd",
							"type" => "date"
						),
						"time" => array(
							"title" => __("Time", 'blessing'),
							"desc" => __("Upcoming time (format: HH:mm:ss)", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"style" => array(
							"title" => __("Style", 'blessing'),
							"desc" => __("Countdown style", 'blessing'),
							"value" => "1",
							"type" => "checklist",
							"options" => array(
								1 => __('Style 1', 'blessing'),
								2 => __('Style 2', 'blessing')
							)
						),
						"align" => array(
							"title" => __("Alignment", 'blessing'),
							"desc" => __("Align counter to left, center or right", 'blessing'),
							"divider" => true,
							"value" => "none",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						), 
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
				// Dropcaps
				"trx_dropcaps" => array(
					"title" => __("Dropcaps", 'blessing'),
					"desc" => __("Make first letter as dropcaps", 'blessing'),
					"decorate" => false,
					"container" => true,
					"params" => array(
						"style" => array(
							"title" => __("Style", 'blessing'),
							"desc" => __("Dropcaps style", 'blessing'),
							"value" => "1",
							"type" => "checklist",
							"options" => array(
								1 => __('Style 1', 'blessing'),
								2 => __('Style 2', 'blessing'),
								3 => __('Style 3', 'blessing'),
								4 => __('Style 4', 'blessing')
							)
						),
						"_content_" => array(
							"title" => __("Paragraph content", 'blessing'),
							"desc" => __("Paragraph with dropcaps content", 'blessing'),
							"divider" => true,
							"rows" => 4,
							"value" => "",
							"type" => "textarea"
						),
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
			
				// Emailer
				"trx_emailer" => array(
					"title" => __("E-mail collector", 'blessing'),
					"desc" => __("Collect the e-mail address into specified group", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"group" => array(
							"title" => __("Group", 'blessing'),
							"desc" => __("The name of group to collect e-mail address", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"open" => array(
							"title" => __("Open", 'blessing'),
							"desc" => __("Initially open the input field on show object", 'blessing'),
							"divider" => true,
							"value" => "yes",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"align" => array(
							"title" => __("Alignment", 'blessing'),
							"desc" => __("Align object to left, center or right", 'blessing'),
							"divider" => true,
							"value" => "none",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						), 
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
			
				// Gap
				"trx_gap" => array(
					"title" => __("Gap", 'blessing'),
					"desc" => __("Insert gap (fullwidth area) in the post content. Attention! Use the gap only in the posts (pages) without left or right sidebar", 'blessing'),
					"decorate" => true,
					"container" => true,
					"params" => array(
						"_content_" => array(
							"title" => __("Gap content", 'blessing'),
							"desc" => __("Gap inner content", 'blessing'),
							"rows" => 4,
							"value" => "",
							"type" => "textarea"
						)
					)
				),
			
			
			
			
			
				// Google map
				"trx_googlemap" => array(
					"title" => __("Google map", 'blessing'),
					"desc" => __("Insert Google map with desired address or coordinates", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"address" => array(
							"title" => __("Address", 'blessing'),
							"desc" => __("Address to show in map center", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"latlng" => array(
							"title" => __("Latitude and Longtitude", 'blessing'),
							"desc" => __("Comma separated map center coorditanes (instead Address)", 'blessing'),
							"value" => "",
							"type" => "text"
						),
                        "description" => array(
                            "title" => __("Description", 'blessing'),
                            "desc" => __("Description", 'blessing'),
                            "value" => "",
                            "type" => "text"
                        ),
						"zoom" => array(
							"title" => __("Zoom", 'blessing'),
							"desc" => __("Map zoom factor", 'blessing'),
							"divider" => true,
							"value" => 16,
							"min" => 1,
							"max" => 20,
							"type" => "spinner"
						),
						"style" => array(
							"title" => __("Map style", 'blessing'),
							"desc" => __("Select map style", 'blessing'),
							"value" => "default",
							"type" => "checklist",
							"options" => $ANCORA_GLOBALS['sc_params']['googlemap_styles']
						),
						"width" => ancora_shortcodes_width('100%'),
						"height" => ancora_shortcodes_height(240),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
				// Hide or show any block
				"trx_hide" => array(
					"title" => __("Hide/Show any block", 'blessing'),
					"desc" => __("Hide or Show any block with desired CSS-selector", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"selector" => array(
							"title" => __("Selector", 'blessing'),
							"desc" => __("Any block's CSS-selector", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"hide" => array(
							"title" => __("Hide or Show", 'blessing'),
							"desc" => __("New state for the block: hide or show", 'blessing'),
							"value" => "yes",
							"size" => "small",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no'],
							"type" => "switch"
						)
					)
				),
			
			
			
				// Highlght text
				"trx_highlight" => array(
					"title" => __("Highlight text", 'blessing'),
					"desc" => __("Highlight text with selected color, background color and other styles", 'blessing'),
					"decorate" => false,
					"container" => true,
					"params" => array(
						"type" => array(
							"title" => __("Type", 'blessing'),
							"desc" => __("Highlight type", 'blessing'),
							"value" => "1",
							"type" => "checklist",
							"options" => array(
								0 => __('Custom', 'blessing'),
								1 => __('Type 1', 'blessing'),
								2 => __('Type 2', 'blessing'),
								3 => __('Type 3', 'blessing')
							)
						),
						"color" => array(
							"title" => __("Color", 'blessing'),
							"desc" => __("Color for the highlighted text", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "color"
						),
						"bg_color" => array(
							"title" => __("Background color", 'blessing'),
							"desc" => __("Background color for the highlighted text", 'blessing'),
							"value" => "",
							"type" => "color"
						),
						"font_size" => array(
							"title" => __("Font size", 'blessing'),
							"desc" => __("Font size of the highlighted text (default - in pixels, allows any CSS units of measure)", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"_content_" => array(
							"title" => __("Highlighting content", 'blessing'),
							"desc" => __("Content for highlight", 'blessing'),
							"divider" => true,
							"rows" => 4,
							"value" => "",
							"type" => "textarea"
						),
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
				// Icon
				"trx_icon" => array(
					"title" => __("Icon", 'blessing'),
					"desc" => __("Insert icon", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"icon" => array(
							"title" => __('Icon',  'blessing'),
							"desc" => __('Select font icon from the Fontello icons set',  'blessing'),
							"value" => "",
							"type" => "icons",
							"options" => $ANCORA_GLOBALS['sc_params']['icons']
						),
						"color" => array(
							"title" => __("Icon's color", 'blessing'),
							"desc" => __("Icon's color", 'blessing'),
							"dependency" => array(
								'icon' => array('not_empty')
							),
							"value" => "",
							"type" => "color"
						),
						"bg_shape" => array(
							"title" => __("Background shape", 'blessing'),
							"desc" => __("Shape of the icon background", 'blessing'),
							"dependency" => array(
								'icon' => array('not_empty')
							),
							"value" => "none",
							"type" => "radio",
							"options" => array(
								'none' => __('None', 'blessing'),
								'round' => __('Round', 'blessing'),
								'square' => __('Square', 'blessing')
							)
						),
						"bg_style" => array(
							"title" => __("Background style", 'blessing'),
							"desc" => __("Select icon's color scheme", 'blessing'),
							"value" => "custom",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['button_styles']
						), 
						"bg_color" => array(
							"title" => __("Icon's background color", 'blessing'),
							"desc" => __("Icon's background color", 'blessing'),
							"dependency" => array(
								'icon' => array('not_empty'),
								'background' => array('round','square')
							),
							"value" => "",
							"type" => "color"
						),
						"font_size" => array(
							"title" => __("Font size", 'blessing'),
							"desc" => __("Icon's font size", 'blessing'),
							"dependency" => array(
								'icon' => array('not_empty')
							),
							"value" => "",
							"type" => "spinner",
							"min" => 8,
							"max" => 240
						),
						"font_weight" => array(
							"title" => __("Font weight", 'blessing'),
							"desc" => __("Icon font weight", 'blessing'),
							"dependency" => array(
								'icon' => array('not_empty')
							),
							"value" => "",
							"type" => "select",
							"size" => "medium",
							"options" => array(
								'100' => __('Thin (100)', 'blessing'),
								'300' => __('Light (300)', 'blessing'),
								'400' => __('Normal (400)', 'blessing'),
								'700' => __('Bold (700)', 'blessing')
							)
						),
						"align" => array(
							"title" => __("Alignment", 'blessing'),
							"desc" => __("Icon text alignment", 'blessing'),
							"dependency" => array(
								'icon' => array('not_empty')
							),
							"value" => "",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						), 
						"link" => array(
							"title" => __("Link URL", 'blessing'),
							"desc" => __("Link URL from this icon (if not empty)", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
				// Image
				"trx_image" => array(
					"title" => __("Image", 'blessing'),
					"desc" => __("Insert image into your post (page)", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"url" => array(
							"title" => __("URL for image file", 'blessing'),
							"desc" => __("Select or upload image or write URL from other site", 'blessing'),
							"readonly" => false,
							"value" => "",
							"type" => "media"
						),
						"title" => array(
							"title" => __("Title", 'blessing'),
							"desc" => __("Image title (if need)", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"icon" => array(
							"title" => __("Icon before title",  'blessing'),
							"desc" => __('Select icon for the title from Fontello icons set',  'blessing'),
							"value" => "none",
							"type" => "icons",
							"options" => $ANCORA_GLOBALS['sc_params']['icons']
						),
						"align" => array(
							"title" => __("Float image", 'blessing'),
							"desc" => __("Float image to left or right side", 'blessing'),
							"value" => "",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['float']
						), 
						"shape" => array(
							"title" => __("Image Shape", 'blessing'),
							"desc" => __("Shape of the image: square (rectangle) or round", 'blessing'),
							"value" => "square",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => array(
								"square" => __('Square', 'blessing'),
								"round" => __('Round', 'blessing')
							)
						), 
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
				// Infobox
				"trx_infobox" => array(
					"title" => __("Infobox", 'blessing'),
					"desc" => __("Insert infobox into your post (page)", 'blessing'),
					"decorate" => false,
					"container" => true,
					"params" => array(
						"style" => array(
							"title" => __("Style", 'blessing'),
							"desc" => __("Infobox style", 'blessing'),
							"value" => "regular",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => array(
								'regular' => __('Regular', 'blessing'),
								'info' => __('Info', 'blessing'),
								'success' => __('Success', 'blessing'),
								'error' => __('Error', 'blessing'),
                                'warning'=> __('Warning','blessing')
							)
						),
						"closeable" => array(
							"title" => __("Closeable box", 'blessing'),
							"desc" => __("Create closeable box (with close button)", 'blessing'),
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"icon" => array(
							"title" => __("Custom icon",  'blessing'),
							"desc" => __('Select icon for the infobox from Fontello icons set. If empty - use default icon',  'blessing'),
							"value" => "",
							"type" => "icons",
							"options" => $ANCORA_GLOBALS['sc_params']['icons']
						),
						"color" => array(
							"title" => __("Text color", 'blessing'),
							"desc" => __("Any color for text and headers", 'blessing'),
							"value" => "",
							"type" => "color"
						),
						"bg_color" => array(
							"title" => __("Background color", 'blessing'),
							"desc" => __("Any background color for this infobox", 'blessing'),
							"value" => "",
							"type" => "color"
						),
						"_content_" => array(
							"title" => __("Infobox content", 'blessing'),
							"desc" => __("Content for infobox", 'blessing'),
							"divider" => true,
							"rows" => 4,
							"value" => "",
							"type" => "textarea"
						),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
				// Line
				"trx_line" => array(
					"title" => __("Line", 'blessing'),
					"desc" => __("Insert Line into your post (page)", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"style" => array(
							"title" => __("Style", 'blessing'),
							"desc" => __("Line style", 'blessing'),
							"value" => "solid",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => array(
								'solid' => __('Solid', 'blessing'),
								'dashed' => __('Dashed', 'blessing'),
								'dotted' => __('Dotted', 'blessing'),
								'double' => __('Double', 'blessing')
							)
						),
						"color" => array(
							"title" => __("Color", 'blessing'),
							"desc" => __("Line color", 'blessing'),
							"value" => "",
							"type" => "color"
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
				// List
				"trx_list" => array(
					"title" => __("List", 'blessing'),
					"desc" => __("List items with specific bullets", 'blessing'),
					"decorate" => true,
					"container" => false,
					"params" => array(
						"style" => array(
							"title" => __("Bullet's style", 'blessing'),
							"desc" => __("Bullet's style for each list item", 'blessing'),
							"value" => "ul",
							"type" => "checklist",
							"options" => $ANCORA_GLOBALS['sc_params']['list_styles']
						), 
						"color" => array(
							"title" => __("Color", 'blessing'),
							"desc" => __("List items color", 'blessing'),
							"value" => "",
							"type" => "color"
						),
						"icon" => array(
							"title" => __('List icon',  'blessing'),
							"desc" => __("Select list icon from Fontello icons set (only for style=Iconed)",  'blessing'),
							"dependency" => array(
								'style' => array('iconed')
							),
							"value" => "",
							"type" => "icons",
							"options" => $ANCORA_GLOBALS['sc_params']['icons']
						),
						"icon_color" => array(
							"title" => __("Icon color", 'blessing'),
							"desc" => __("List icons color", 'blessing'),
							"value" => "",
							"dependency" => array(
								'style' => array('iconed')
							),
							"type" => "color"
						),
                        "boxed_icon" => array(
                            "title" => __("Boxed Icon", 'blessing'),
                            "desc" => __("Create border around icon", 'blessing'),
                            "value" => "",
                            "type" => "checklist",
                            "options" => array('' => 'No', 'boxed_icon' => 'Yes'),
                        ),
                        "top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					),
					"children" => array(
						"name" => "trx_list_item",
						"title" => __("Item", 'blessing'),
						"desc" => __("List item with specific bullet", 'blessing'),
						"decorate" => false,
						"container" => true,
						"params" => array(
							"_content_" => array(
								"title" => __("List item content", 'blessing'),
								"desc" => __("Current list item content", 'blessing'),
								"rows" => 4,
								"value" => "",
								"type" => "textarea"
							),
							"title" => array(
								"title" => __("List item title", 'blessing'),
								"desc" => __("Current list item title (show it as tooltip)", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"color" => array(
								"title" => __("Color", 'blessing'),
								"desc" => __("Text color for this item", 'blessing'),
								"value" => "",
								"type" => "color"
							),
							"icon" => array(
								"title" => __('List icon',  'blessing'),
								"desc" => __("Select list item icon from Fontello icons set (only for style=Iconed)",  'blessing'),
								"value" => "",
								"type" => "icons",
								"options" => $ANCORA_GLOBALS['sc_params']['icons']
							),
							"icon_color" => array(
								"title" => __("Icon color", 'blessing'),
								"desc" => __("Icon color for this item", 'blessing'),
								"value" => "",
								"type" => "color"
							),
							"link" => array(
								"title" => __("Link URL", 'blessing'),
								"desc" => __("Link URL for the current list item", 'blessing'),
								"divider" => true,
								"value" => "",
								"type" => "text"
							),
							"target" => array(
								"title" => __("Link target", 'blessing'),
								"desc" => __("Link target for the current list item", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"id" => $ANCORA_GLOBALS['sc_params']['id'],
							"class" => $ANCORA_GLOBALS['sc_params']['class'],
							"css" => $ANCORA_GLOBALS['sc_params']['css']
						)
					)
				),
			
			
			
				// Number
				"trx_number" => array(
					"title" => __("Number", 'blessing'),
					"desc" => __("Insert number or any word as set separate characters", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"value" => array(
							"title" => __("Value", 'blessing'),
							"desc" => __("Number or any word", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"align" => array(
							"title" => __("Align", 'blessing'),
							"desc" => __("Select block alignment", 'blessing'),
							"value" => "none",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
				// Parallax
				"trx_parallax" => array(
					"title" => __("Parallax", 'blessing'),
					"desc" => __("Create the parallax container (with asinc background image)", 'blessing'),
					"decorate" => false,
					"container" => true,
					"params" => array(
						"gap" => array(
							"title" => __("Create gap", 'blessing'),
							"desc" => __("Create gap around parallax container", 'blessing'),
							"value" => "no",
							"size" => "small",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no'],
							"type" => "switch"
						), 
						"dir" => array(
							"title" => __("Dir", 'blessing'),
							"desc" => __("Scroll direction for the parallax background", 'blessing'),
							"value" => "up",
							"size" => "medium",
							"options" => array(
								'up' => __('Up', 'blessing'),
								'down' => __('Down', 'blessing')
							),
							"type" => "switch"
						), 
						"speed" => array(
							"title" => __("Speed", 'blessing'),
							"desc" => __("Image motion speed (from 0.0 to 1.0)", 'blessing'),
							"min" => "0",
							"max" => "1",
							"step" => "0.1",
							"value" => "0.3",
							"type" => "spinner"
						),
						"color" => array(
							"title" => __("Text color", 'blessing'),
							"desc" => __("Select color for text object inside parallax block", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "color"
						),
						"bg_tint" => array(
							"title" => __("Bg tint", 'blessing'),
							"desc" => __("Select tint of the parallax background (for correct font color choise)", 'blessing'),
							"value" => "light",
							"size" => "medium",
							"options" => array(
								'light' => __('Light', 'blessing'),
								'dark' => __('Dark', 'blessing')
							),
							"type" => "switch"
						), 
						"bg_color" => array(
							"title" => __("Background color", 'blessing'),
							"desc" => __("Select color for parallax background", 'blessing'),
							"value" => "",
							"type" => "color"
						),
						"bg_image" => array(
							"title" => __("Background image", 'blessing'),
							"desc" => __("Select or upload image or write URL from other site for the parallax background", 'blessing'),
							"readonly" => false,
							"value" => "",
							"type" => "media"
						),
						"bg_image_x" => array(
							"title" => __("Image X position", 'blessing'),
							"desc" => __("Image horizontal position (as background of the parallax block) - in percent", 'blessing'),
							"min" => "0",
							"max" => "100",
							"value" => "50",
							"type" => "spinner"
						),
						"bg_video" => array(
							"title" => __("Video background", 'blessing'),
							"desc" => __("Select video from media library or paste URL for video file from other site to show it as parallax background", 'blessing'),
							"readonly" => false,
							"value" => "",
							"type" => "media",
							"before" => array(
								'title' => __('Choose video', 'blessing'),
								'action' => 'media_upload',
								'type' => 'video',
								'multiple' => false,
								'linked_field' => '',
								'captions' => array( 	
									'choose' => __('Choose video file', 'blessing'),
									'update' => __('Select video file', 'blessing')
								)
							),
							"after" => array(
								'icon' => 'icon-cancel',
								'action' => 'media_reset'
							)
						),
						"bg_video_ratio" => array(
							"title" => __("Video ratio", 'blessing'),
							"desc" => __("Specify ratio of the video background. For example: 16:9 (default), 4:3, etc.", 'blessing'),
							"value" => "16:9",
							"type" => "text"
						),
						"bg_overlay" => array(
							"title" => __("Overlay", 'blessing'),
							"desc" => __("Overlay color opacity (from 0.0 to 1.0)", 'blessing'),
							"min" => "0",
							"max" => "1",
							"step" => "0.1",
							"value" => "0",
							"type" => "spinner"
						),
						"bg_texture" => array(
							"title" => __("Texture", 'blessing'),
							"desc" => __("Predefined texture style from 1 to 11. 0 - without texture.", 'blessing'),
							"min" => "0",
							"max" => "11",
							"step" => "1",
							"value" => "0",
							"type" => "spinner"
						),
						"_content_" => array(
							"title" => __("Content", 'blessing'),
							"desc" => __("Content for the parallax container", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "text"
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
				// Popup
				"trx_popup" => array(
					"title" => __("Popup window", 'blessing'),
					"desc" => __("Container for any html-block with desired class and style for popup window", 'blessing'),
					"decorate" => true,
					"container" => true,
					"params" => array(
						"_content_" => array(
							"title" => __("Container content", 'blessing'),
							"desc" => __("Content for section container", 'blessing'),
							"divider" => true,
							"rows" => 4,
							"value" => "",
							"type" => "textarea"
						),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
				// Price
				"trx_price" => array(
					"title" => __("Price", 'blessing'),
					"desc" => __("Insert price with decoration", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"money" => array(
							"title" => __("Money", 'blessing'),
							"desc" => __("Money value (dot or comma separated)", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"currency" => array(
							"title" => __("Currency", 'blessing'),
							"desc" => __("Currency character", 'blessing'),
							"value" => "$",
							"type" => "text"
						),
						"period" => array(
							"title" => __("Period", 'blessing'),
							"desc" => __("Period text (if need). For example: monthly, daily, etc.", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"align" => array(
							"title" => __("Alignment", 'blessing'),
							"desc" => __("Align price to left or right side", 'blessing'),
							"value" => "",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['float']
						), 
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
				// Price block
				"trx_price_block" => array(
					"title" => __("Price block", 'blessing'),
					"desc" => __("Insert price block with title, price and description", 'blessing'),
					"decorate" => false,
					"container" => true,
					"params" => array(
						"title" => array(
							"title" => __("Title", 'blessing'),
							"desc" => __("Block title", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"link" => array(
							"title" => __("Link URL", 'blessing'),
							"desc" => __("URL for link from button (at bottom of the block)", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"link_text" => array(
							"title" => __("Link text", 'blessing'),
							"desc" => __("Text (caption) for the link button (at bottom of the block). If empty - button not showed", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"icon" => array(
							"title" => __("Icon",  'blessing'),
							"desc" => __('Select icon from Fontello icons set (placed before/instead price)',  'blessing'),
							"value" => "",
							"type" => "icons",
							"options" => $ANCORA_GLOBALS['sc_params']['icons']
						),
						"money" => array(
							"title" => __("Money", 'blessing'),
							"desc" => __("Money value (dot or comma separated)", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "text"
						),
						"currency" => array(
							"title" => __("Currency", 'blessing'),
							"desc" => __("Currency character", 'blessing'),
							"value" => "$",
							"type" => "text"
						),
						"period" => array(
							"title" => __("Period", 'blessing'),
							"desc" => __("Period text (if need). For example: monthly, daily, etc.", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"align" => array(
							"title" => __("Alignment", 'blessing'),
							"desc" => __("Align price to left or right side", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['float']
						), 
						"_content_" => array(
							"title" => __("Description", 'blessing'),
							"desc" => __("Description for this price block", 'blessing'),
							"divider" => true,
							"rows" => 4,
							"value" => "",
							"type" => "textarea"
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
				// Quote
				"trx_quote" => array(
					"title" => __("Quote", 'blessing'),
					"desc" => __("Quote text", 'blessing'),
					"decorate" => false,
					"container" => true,
					"params" => array(
                        "style" => array(
                            "title" => __("Style", 'blessing'),
                            "desc" => __("Quote style", 'blessing'),
                            "value" => "",
                            "type" => "checklist",
                            "options" => array ( '1' => 'Dark', '2' => 'White')
                        ),
						"cite" => array(
							"title" => __("Quote cite", 'blessing'),
							"desc" => __("URL for quote cite", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"title" => array(
							"title" => __("Title (author)", 'blessing'),
							"desc" => __("Quote title (author name)", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"_content_" => array(
							"title" => __("Quote content", 'blessing'),
							"desc" => __("Quote content", 'blessing'),
							"rows" => 4,
							"value" => "",
							"type" => "textarea"
						),
						"width" => ancora_shortcodes_width(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
				// Reviews
				"trx_reviews" => array(
					"title" => __("Reviews", 'blessing'),
					"desc" => __("Insert reviews block in the single post", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"align" => array(
							"title" => __("Alignment", 'blessing'),
							"desc" => __("Align counter to left, center or right", 'blessing'),
							"divider" => true,
							"value" => "none",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						), 
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
				// Search
				"trx_search" => array(
					"title" => __("Search", 'blessing'),
					"desc" => __("Show search form", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"ajax" => array(
							"title" => __("Style", 'blessing'),
							"desc" => __("Select style to display search field", 'blessing'),
							"value" => "regular",
							"options" => array(
								"regular" => __('Regular', 'blessing'),
								"flat" => __('Flat', 'blessing')
							),
							"type" => "checklist"
						),
						"title" => array(
							"title" => __("Title", 'blessing'),
							"desc" => __("Title (placeholder) for the search field", 'blessing'),
							"value" => __("Search &hellip;", 'blessing'),
							"type" => "text"
						),
						"ajax" => array(
							"title" => __("AJAX", 'blessing'),
							"desc" => __("Search via AJAX or reload page", 'blessing'),
							"value" => "yes",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no'],
							"type" => "switch"
						),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
				// Section
				"trx_section" => array(
					"title" => __("Section container", 'blessing'),
					"desc" => __("Container for any block with desired class and style", 'blessing'),
					"decorate" => true,
					"container" => true,
					"params" => array(
						"dedicated" => array(
							"title" => __("Dedicated", 'blessing'),
							"desc" => __("Use this block as dedicated content - show it before post title on single page", 'blessing'),
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"align" => array(
							"title" => __("Align", 'blessing'),
							"desc" => __("Select block alignment", 'blessing'),
							"value" => "none",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						),
						"columns" => array(
							"title" => __("Columns emulation", 'blessing'),
							"desc" => __("Select width for columns emulation", 'blessing'),
							"value" => "none",
							"type" => "checklist",
							"options" => $ANCORA_GLOBALS['sc_params']['columns']
						), 
						"pan" => array(
							"title" => __("Use pan effect", 'blessing'),
							"desc" => __("Use pan effect to show section content", 'blessing'),
							"divider" => true,
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"scroll" => array(
							"title" => __("Use scroller", 'blessing'),
							"desc" => __("Use scroller to show section content", 'blessing'),
							"divider" => true,
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"scroll_dir" => array(
							"title" => __("Scroll and Pan direction", 'blessing'),
							"desc" => __("Scroll and Pan direction (if Use scroller = yes or Pan = yes)", 'blessing'),
							"dependency" => array(
								'pan' => array('yes'),
								'scroll' => array('yes')
							),
							"value" => "horizontal",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['dir']
						),
						"scroll_controls" => array(
							"title" => __("Scroll controls", 'blessing'),
							"desc" => __("Show scroll controls (if Use scroller = yes)", 'blessing'),
							"dependency" => array(
								'scroll' => array('yes')
							),
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"color" => array(
							"title" => __("Fore color", 'blessing'),
							"desc" => __("Any color for objects in this section", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "color"
						),
						"bg_tint" => array(
							"title" => __("Background tint", 'blessing'),
							"desc" => __("Main background tint: dark or light", 'blessing'),
							"value" => "",
							"type" => "checklist",
							"options" => $ANCORA_GLOBALS['sc_params']['tint']
						),
						"bg_color" => array(
							"title" => __("Background color", 'blessing'),
							"desc" => __("Any background color for this section", 'blessing'),
							"value" => "",
							"type" => "color"
						),
						"bg_image" => array(
							"title" => __("Background image URL", 'blessing'),
							"desc" => __("Select or upload image or write URL from other site for the background", 'blessing'),
							"readonly" => false,
							"value" => "",
							"type" => "media"
						),
						"bg_overlay" => array(
							"title" => __("Overlay", 'blessing'),
							"desc" => __("Overlay color opacity (from 0.0 to 1.0)", 'blessing'),
							"min" => "0",
							"max" => "1",
							"step" => "0.1",
							"value" => "0",
							"type" => "spinner"
						),
						"bg_texture" => array(
							"title" => __("Texture", 'blessing'),
							"desc" => __("Predefined texture style from 1 to 11. 0 - without texture.", 'blessing'),
							"min" => "0",
							"max" => "11",
							"step" => "1",
							"value" => "0",
							"type" => "spinner"
						),
						"font_size" => array(
							"title" => __("Font size", 'blessing'),
							"desc" => __("Font size of the text (default - in pixels, allows any CSS units of measure)", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"font_weight" => array(
							"title" => __("Font weight", 'blessing'),
							"desc" => __("Font weight of the text", 'blessing'),
							"value" => "",
							"type" => "select",
							"size" => "medium",
							"options" => array(
								'100' => __('Thin (100)', 'blessing'),
								'300' => __('Light (300)', 'blessing'),
								'400' => __('Normal (400)', 'blessing'),
								'700' => __('Bold (700)', 'blessing')
							)
						),
						"_content_" => array(
							"title" => __("Container content", 'blessing'),
							"desc" => __("Content for section container", 'blessing'),
							"divider" => true,
							"rows" => 4,
							"value" => "",
							"type" => "textarea"
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
				// Skills
				"trx_skills" => array(
					"title" => __("Skills", 'blessing'),
					"desc" => __("Insert skills diagramm in your page (post)", 'blessing'),
					"decorate" => true,
					"container" => false,
					"params" => array(
						"max_value" => array(
							"title" => __("Max value", 'blessing'),
							"desc" => __("Max value for skills items", 'blessing'),
							"value" => 100,
							"min" => 1,
							"type" => "spinner"
						),
						"type" => array(
							"title" => __("Skills type", 'blessing'),
							"desc" => __("Select type of skills block", 'blessing'),
							"value" => "bar",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => array(
								'bar' => __('Bar', 'blessing'),
								'pie' => __('Pie chart', 'blessing'),
								'counter' => __('Counter', 'blessing'),
								'arc' => __('Arc', 'blessing')
							)
						), 
						"layout" => array(
							"title" => __("Skills layout", 'blessing'),
							"desc" => __("Select layout of skills block", 'blessing'),
							"dependency" => array(
								'type' => array('counter','pie','bar')
							),
							"value" => "rows",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => array(
								'rows' => __('Rows', 'blessing'),
								'columns' => __('Columns', 'blessing')
							)
						),
						"dir" => array(
							"title" => __("Direction", 'blessing'),
							"desc" => __("Select direction of skills block", 'blessing'),
							"dependency" => array(
								'type' => array('counter','pie','bar')
							),
							"value" => "horizontal",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['dir']
						), 
						"style" => array(
							"title" => __("Counters style", 'blessing'),
							"desc" => __("Select style of skills items (only for type=counter)", 'blessing'),
							"dependency" => array(
								'type' => array('counter')
							),
							"value" => 1,
							"min" => 1,
							"max" => 4,
							"type" => "spinner"
						), 
						// "columns" - autodetect, not set manual
						"color" => array(
							"title" => __("Skills items color", 'blessing'),
							"desc" => __("Color for all skills items", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "color"
						),
						"bg_color" => array(
							"title" => __("Background color", 'blessing'),
							"desc" => __("Background color for all skills items (only for type=pie)", 'blessing'),
							"dependency" => array(
								'type' => array('pie')
							),
							"value" => "",
							"type" => "color"
						),
						"border_color" => array(
							"title" => __("Border color", 'blessing'),
							"desc" => __("Border color for all skills items (only for type=pie)", 'blessing'),
							"dependency" => array(
								'type' => array('pie')
							),
							"value" => "",
							"type" => "color"
						),
						"title" => array(
							"title" => __("Skills title", 'blessing'),
							"desc" => __("Skills block title", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "text"
						),
						"subtitle" => array(
							"title" => __("Skills subtitle", 'blessing'),
							"desc" => __("Skills block subtitle - text in the center (only for type=arc)", 'blessing'),
							"dependency" => array(
								'type' => array('arc')
							),
							"value" => "",
							"type" => "text"
						),
						"align" => array(
							"title" => __("Align skills block", 'blessing'),
							"desc" => __("Align skills block to left or right side", 'blessing'),
							"value" => "",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['float']
						), 
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					),
					"children" => array(
						"name" => "trx_skills_item",
						"title" => __("Skill", 'blessing'),
						"desc" => __("Skills item", 'blessing'),
						"container" => false,
						"params" => array(
							"title" => array(
								"title" => __("Title", 'blessing'),
								"desc" => __("Current skills item title", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"value" => array(
								"title" => __("Value", 'blessing'),
								"desc" => __("Current skills level", 'blessing'),
								"value" => 50,
								"min" => 0,
								"step" => 1,
								"type" => "spinner"
							),
							"color" => array(
								"title" => __("Color", 'blessing'),
								"desc" => __("Current skills item color", 'blessing'),
								"value" => "",
								"type" => "color"
							),
							"bg_color" => array(
								"title" => __("Background color", 'blessing'),
								"desc" => __("Current skills item background color (only for type=pie)", 'blessing'),
								"value" => "",
								"type" => "color"
							),
							"border_color" => array(
								"title" => __("Border color", 'blessing'),
								"desc" => __("Current skills item border color (only for type=pie)", 'blessing'),
								"value" => "",
								"type" => "color"
							),
							"style" => array(
								"title" => __("Counter tyle", 'blessing'),
								"desc" => __("Select style for the current skills item (only for type=counter)", 'blessing'),
								"value" => 1,
								"min" => 1,
								"max" => 4,
								"type" => "spinner"
							), 
							"id" => $ANCORA_GLOBALS['sc_params']['id'],
							"class" => $ANCORA_GLOBALS['sc_params']['class'],
							"css" => $ANCORA_GLOBALS['sc_params']['css']
						)
					)
				),
			
			
			
			
				// Slider
				"trx_slider" => array(
					"title" => __("Slider", 'blessing'),
					"desc" => __("Insert slider into your post (page)", 'blessing'),
					"decorate" => true,
					"container" => false,
					"params" => array_merge(array(
						"engine" => array(
							"title" => __("Slider engine", 'blessing'),
							"desc" => __("Select engine for slider. Attention! Swiper is built-in engine, all other engines appears only if corresponding plugings are installed", 'blessing'),
							"value" => "swiper",
							"type" => "checklist",
							"options" => $ANCORA_GLOBALS['sc_params']['sliders']
						),
						"align" => array(
							"title" => __("Float slider", 'blessing'),
							"desc" => __("Float slider to left or right side", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['float']
						),
						"custom" => array(
							"title" => __("Custom slides", 'blessing'),
							"desc" => __("Make custom slides from inner shortcodes (prepare it on tabs) or prepare slides from posts thumbnails", 'blessing'),
							"divider" => true,
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						)
						),
						ancora_exists_revslider() ? array(
						"alias" => array(
							"title" => __("Revolution slider alias", 'blessing'),
							"desc" => __("Alias for Revolution slider", 'blessing'),
							"dependency" => array(
								'engine' => array('revo','royal')
							),
							"divider" => true,
							"value" => "",
							"type" => "text"
						)) : array(), array(
						"cat" => array(
							"title" => __("Swiper: Category list", 'blessing'),
							"desc" => __("Comma separated list of category slugs. If empty - select posts from any category or from IDs list", 'blessing'),
							"dependency" => array(
								'engine' => array('swiper')
							),
							"divider" => true,
							"value" => "",
							"type" => "select",
							"style" => "list",
							"multiple" => true,
							"options" => $ANCORA_GLOBALS['sc_params']['categories']
						),
						"count" => array(
							"title" => __("Swiper: Number of posts", 'blessing'),
							"desc" => __("How many posts will be displayed? If used IDs - this parameter ignored.", 'blessing'),
							"dependency" => array(
								'engine' => array('swiper')
							),
							"value" => 3,
							"min" => 1,
							"max" => 100,
							"type" => "spinner"
						),
						"offset" => array(
							"title" => __("Swiper: Offset before select posts", 'blessing'),
							"desc" => __("Skip posts before select next part.", 'blessing'),
							"dependency" => array(
								'engine' => array('swiper')
							),
							"value" => 0,
							"min" => 0,
							"type" => "spinner"
						),
						"orderby" => array(
							"title" => __("Swiper: Post order by", 'blessing'),
							"desc" => __("Select desired posts sorting method", 'blessing'),
							"dependency" => array(
								'engine' => array('swiper')
							),
							"value" => "date",
							"type" => "select",
							"options" => $ANCORA_GLOBALS['sc_params']['sorting']
						),
						"order" => array(
							"title" => __("Swiper: Post order", 'blessing'),
							"desc" => __("Select desired posts order", 'blessing'),
							"dependency" => array(
								'engine' => array('swiper')
							),
							"value" => "desc",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['ordering']
						),
						"ids" => array(
							"title" => __("Swiper: Post IDs list", 'blessing'),
							"desc" => __("Comma separated list of posts ID. If set - parameters above are ignored!", 'blessing'),
							"dependency" => array(
								'engine' => array('swiper')
							),
							"value" => "",
							"type" => "text"
						),
						"controls" => array(
							"title" => __("Swiper: Show slider controls", 'blessing'),
							"desc" => __("Show arrows inside slider", 'blessing'),
							"dependency" => array(
								'engine' => array('swiper')
							),
							"divider" => true,
							"value" => "yes",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"pagination" => array(
							"title" => __("Swiper: Show slider pagination", 'blessing'),
							"desc" => __("Show bullets for switch slides", 'blessing'),
							"dependency" => array(
								'engine' => array('swiper')
							),
							"value" => "yes",
							"type" => "checklist",
							"options" => array(
								'yes'  => __('Dots', 'blessing'),
								'full' => __('Side Titles', 'blessing'),
								'over' => __('Over Titles', 'blessing'),
								'no'   => __('None', 'blessing')
							)
						),
						"titles" => array(
							"title" => __("Swiper: Show titles section", 'blessing'),
							"desc" => __("Show section with post's title and short post's description", 'blessing'),
							"dependency" => array(
								'engine' => array('swiper')
							),
							"divider" => true,
							"value" => "no",
							"type" => "checklist",
							"options" => array(
								"no"    => __('Not show', 'blessing'),
								"slide" => __('Show/Hide info', 'blessing'),
								"fixed" => __('Fixed info', 'blessing')
							)
						),
						"descriptions" => array(
							"title" => __("Swiper: Post descriptions", 'blessing'),
							"dependency" => array(
								'engine' => array('swiper')
							),
							"desc" => __("Show post's excerpt max length (characters)", 'blessing'),
							"value" => 0,
							"min" => 0,
							"max" => 1000,
							"step" => 10,
							"type" => "spinner"
						),
						"links" => array(
							"title" => __("Swiper: Post's title as link", 'blessing'),
							"desc" => __("Make links from post's titles", 'blessing'),
							"dependency" => array(
								'engine' => array('swiper')
							),
							"value" => "yes",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"crop" => array(
							"title" => __("Swiper: Crop images", 'blessing'),
							"desc" => __("Crop images in each slide or live it unchanged", 'blessing'),
							"dependency" => array(
								'engine' => array('swiper')
							),
							"value" => "yes",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"autoheight" => array(
							"title" => __("Swiper: Autoheight", 'blessing'),
							"desc" => __("Change whole slider's height (make it equal current slide's height)", 'blessing'),
							"dependency" => array(
								'engine' => array('swiper')
							),
							"value" => "yes",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"interval" => array(
							"title" => __("Swiper: Slides change interval", 'blessing'),
							"desc" => __("Slides change interval (in milliseconds: 1000ms = 1s)", 'blessing'),
							"dependency" => array(
								'engine' => array('swiper')
							),
							"value" => 5000,
							"step" => 500,
							"min" => 0,
							"type" => "spinner"
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)),
					"children" => array(
						"name" => "trx_slider_item",
						"title" => __("Slide", 'blessing'),
						"desc" => __("Slider item", 'blessing'),
						"container" => false,
						"params" => array(
							"src" => array(
								"title" => __("URL (source) for image file", 'blessing'),
								"desc" => __("Select or upload image or write URL from other site for the current slide", 'blessing'),
								"readonly" => false,
								"value" => "",
								"type" => "media"
							),
							"id" => $ANCORA_GLOBALS['sc_params']['id'],
							"class" => $ANCORA_GLOBALS['sc_params']['class'],
							"css" => $ANCORA_GLOBALS['sc_params']['css']
						)
					)
				),
			
			
			
			
				// Socials
				"trx_socials" => array(
					"title" => __("Social icons", 'blessing'),
					"desc" => __("List of social icons (with hovers)", 'blessing'),
					"decorate" => true,
					"container" => false,
					"params" => array(
						"size" => array(
							"title" => __("Icon's size", 'blessing'),
							"desc" => __("Size of the icons", 'blessing'),
							"value" => "small",
							"type" => "checklist",
							"options" => array(
								"tiny" => __('Tiny', 'blessing'),
								"small" => __('Small', 'blessing'),
								"large" => __('Large', 'blessing')
							)
						), 
						"socials" => array(
							"title" => __("Manual socials list", 'blessing'),
							"desc" => __("Custom list of social networks. For example: twitter=http://twitter.com/my_profile|facebook=http://facebooc.com/my_profile. If empty - use socials from Theme options.", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "text"
						),
						"custom" => array(
							"title" => __("Custom socials", 'blessing'),
							"desc" => __("Make custom icons from inner shortcodes (prepare it on tabs)", 'blessing'),
							"divider" => true,
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					),
					"children" => array(
						"name" => "trx_social_item",
						"title" => __("Custom social item", 'blessing'),
						"desc" => __("Custom social item: name, profile url and icon url", 'blessing'),
						"decorate" => false,
						"container" => false,
						"params" => array(
							"name" => array(
								"title" => __("Social name", 'blessing'),
								"desc" => __("Name (slug) of the social network (twitter, facebook, linkedin, etc.)", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"url" => array(
								"title" => __("Your profile URL", 'blessing'),
								"desc" => __("URL of your profile in specified social network", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"icon" => array(
								"title" => __("URL (source) for icon file", 'blessing'),
								"desc" => __("Select or upload image or write URL from other site for the current social icon", 'blessing'),
								"readonly" => false,
								"value" => "",
								"type" => "media"
							)
						)
					)
				),
			
			
			
			
				// Table
				"trx_table" => array(
					"title" => __("Table", 'blessing'),
					"desc" => __("Insert a table into post (page). ", 'blessing'),
					"decorate" => true,
					"container" => true,
					"params" => array(
						"align" => array(
							"title" => __("Content alignment", 'blessing'),
							"desc" => __("Select alignment for each table cell", 'blessing'),
							"value" => "none",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						),
						"_content_" => array(
							"title" => __("Table content", 'blessing'),
							"desc" => __("Content, created with any table-generator", 'blessing'),
							"divider" => true,
							"rows" => 8,
							"value" => "Paste here table content, generated on one of many public internet resources, for example: http://www.impressivewebs.com/html-table-code-generator/ or http://html-tables.com/",
							"type" => "textarea"
						),
						"width" => ancora_shortcodes_width(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
			
				// Tabs
				"trx_tabs" => array(
					"title" => __("Tabs", 'blessing'),
					"desc" => __("Insert tabs in your page (post)", 'blessing'),
					"decorate" => true,
					"container" => false,
					"params" => array(
						"style" => array(
							"title" => __("Tabs style", 'blessing'),
							"desc" => __("Select style for tabs items", 'blessing'),
							"value" => 1,
							"options" => array(
								1 => __('Style 1', 'blessing'),
								2 => __('Style 2', 'blessing')
							),
							"type" => "radio"
						),
						"initial" => array(
							"title" => __("Initially opened tab", 'blessing'),
							"desc" => __("Number of initially opened tab", 'blessing'),
							"divider" => true,
							"value" => 1,
							"min" => 0,
							"type" => "spinner"
						),
						"scroll" => array(
							"title" => __("Use scroller", 'blessing'),
							"desc" => __("Use scroller to show tab content (height parameter required)", 'blessing'),
							"divider" => true,
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					),
					"children" => array(
						"name" => "trx_tab",
						"title" => __("Tab", 'blessing'),
						"desc" => __("Tab item", 'blessing'),
						"container" => true,
						"params" => array(
							"title" => array(
								"title" => __("Tab title", 'blessing'),
								"desc" => __("Current tab title", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"_content_" => array(
								"title" => __("Tab content", 'blessing'),
								"desc" => __("Current tab content", 'blessing'),
								"divider" => true,
								"rows" => 4,
								"value" => "",
								"type" => "textarea"
							),
							"id" => $ANCORA_GLOBALS['sc_params']['id'],
							"class" => $ANCORA_GLOBALS['sc_params']['class'],
							"css" => $ANCORA_GLOBALS['sc_params']['css']
						)
					)
				),
			
			
			
			
			
				// Team
				"trx_team" => array(
					"title" => __("Team", 'blessing'),
					"desc" => __("Insert team in your page (post)", 'blessing'),
					"decorate" => true,
					"container" => false,
					"params" => array(
						"style" => array(
							"title" => __("Team style", 'blessing'),
							"desc" => __("Select style to display team members", 'blessing'),
							"value" => "1",
							"type" => "select",
							"options" => array(
								1 => __('Style 1', 'blessing'),
								2 => __('Style 2', 'blessing')
							)
						),
						"columns" => array(
							"title" => __("Columns", 'blessing'),
							"desc" => __("How many columns use to show team members", 'blessing'),
							"value" => 3,
							"min" => 2,
							"max" => 5,
							"step" => 1,
							"type" => "spinner"
						),
						"custom" => array(
							"title" => __("Custom", 'blessing'),
							"desc" => __("Allow get team members from inner shortcodes (custom) or get it from specified group (cat)", 'blessing'),
							"divider" => true,
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"cat" => array(
							"title" => __("Categories", 'blessing'),
							"desc" => __("Select categories (groups) to show team members. If empty - select team members from any category (group) or from IDs list", 'blessing'),
							"dependency" => array(
								'custom' => array('no')
							),
							"divider" => true,
							"value" => "",
							"type" => "select",
							"style" => "list",
							"multiple" => true,
							"options" => $ANCORA_GLOBALS['sc_params']['team_groups']
						),
						"count" => array(
							"title" => __("Number of posts", 'blessing'),
							"desc" => __("How many posts will be displayed? If used IDs - this parameter ignored.", 'blessing'),
							"dependency" => array(
								'custom' => array('no')
							),
							"value" => 3,
							"min" => 1,
							"max" => 100,
							"type" => "spinner"
						),
						"offset" => array(
							"title" => __("Offset before select posts", 'blessing'),
							"desc" => __("Skip posts before select next part.", 'blessing'),
							"dependency" => array(
								'custom' => array('no')
							),
							"value" => 0,
							"min" => 0,
							"type" => "spinner"
						),
						"orderby" => array(
							"title" => __("Post order by", 'blessing'),
							"desc" => __("Select desired posts sorting method", 'blessing'),
							"dependency" => array(
								'custom' => array('no')
							),
							"value" => "title",
							"type" => "select",
							"options" => $ANCORA_GLOBALS['sc_params']['sorting']
						),
						"order" => array(
							"title" => __("Post order", 'blessing'),
							"desc" => __("Select desired posts order", 'blessing'),
							"dependency" => array(
								'custom' => array('no')
							),
							"value" => "asc",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['ordering']
						),
						"ids" => array(
							"title" => __("Post IDs list", 'blessing'),
							"desc" => __("Comma separated list of posts ID. If set - parameters above are ignored!", 'blessing'),
							"dependency" => array(
								'custom' => array('no')
							),
							"value" => "",
							"type" => "text"
						),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					),
					"children" => array(
						"name" => "trx_team_item",
						"title" => __("Member", 'blessing'),
						"desc" => __("Team member", 'blessing'),
						"container" => true,
						"params" => array(
							"user" => array(
								"title" => __("Registerd user", 'blessing'),
								"desc" => __("Select one of registered users (if present) or put name, position, etc. in fields below", 'blessing'),
								"value" => "",
								"type" => "select",
								"options" => $ANCORA_GLOBALS['sc_params']['users']
							),
							"member" => array(
								"title" => __("Team member", 'blessing'),
								"desc" => __("Select one of team members (if present) or put name, position, etc. in fields below", 'blessing'),
								"value" => "",
								"type" => "select",
								"options" => $ANCORA_GLOBALS['sc_params']['members']
							),
							"link" => array(
								"title" => __("Link", 'blessing'),
								"desc" => __("Link on team member's personal page", 'blessing'),
								"divider" => true,
								"value" => "",
								"type" => "text"
							),
							"name" => array(
								"title" => __("Name", 'blessing'),
								"desc" => __("Team member's name", 'blessing'),
								"divider" => true,
								"dependency" => array(
									'user' => array('is_empty', 'none'),
									'member' => array('is_empty', 'none')
								),
								"value" => "",
								"type" => "text"
							),
							"position" => array(
								"title" => __("Position", 'blessing'),
								"desc" => __("Team member's position", 'blessing'),
								"dependency" => array(
									'user' => array('is_empty', 'none'),
									'member' => array('is_empty', 'none')
								),
								"value" => "",
								"type" => "text"
							),
							"email" => array(
								"title" => __("E-mail", 'blessing'),
								"desc" => __("Team member's e-mail", 'blessing'),
								"dependency" => array(
									'user' => array('is_empty', 'none'),
									'member' => array('is_empty', 'none')
								),
								"value" => "",
								"type" => "text"
							),
							"photo" => array(
								"title" => __("Photo", 'blessing'),
								"desc" => __("Team member's photo (avatar)", 'blessing'),
								"dependency" => array(
									'user' => array('is_empty', 'none'),
									'member' => array('is_empty', 'none')
								),
								"value" => "",
								"readonly" => false,
								"type" => "media"
							),
							"socials" => array(
								"title" => __("Socials", 'blessing'),
								"desc" => __("Team member's socials icons: name=url|name=url... For example: facebook=http://facebook.com/myaccount|twitter=http://twitter.com/myaccount", 'blessing'),
								"dependency" => array(
									'user' => array('is_empty', 'none'),
									'member' => array('is_empty', 'none')
								),
								"value" => "",
								"type" => "text"
							),
							"_content_" => array(
								"title" => __("Description", 'blessing'),
								"desc" => __("Team member's short description", 'blessing'),
								"divider" => true,
								"rows" => 4,
								"value" => "",
								"type" => "textarea"
							),
							"id" => $ANCORA_GLOBALS['sc_params']['id'],
							"class" => $ANCORA_GLOBALS['sc_params']['class'],
							"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
							"css" => $ANCORA_GLOBALS['sc_params']['css']
						)
					)
				),
			
			
			
			
				// Testimonials
				"trx_testimonials" => array(
					"title" => __("Testimonials", 'blessing'),
					"desc" => __("Insert testimonials into post (page)", 'blessing'),
					"decorate" => true,
					"container" => false,
					"params" => array(
						"controls" => array(
							"title" => __("Show arrows", 'blessing'),
							"desc" => __("Show control buttons", 'blessing'),
							"value" => "yes",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"interval" => array(
							"title" => __("Testimonials change interval", 'blessing'),
							"desc" => __("Testimonials change interval (in milliseconds: 1000ms = 1s)", 'blessing'),
							"value" => 7000,
							"step" => 500,
							"min" => 0,
							"type" => "spinner"
						),
						"align" => array(
							"title" => __("Alignment", 'blessing'),
							"desc" => __("Alignment of the testimonials block", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						),
						"autoheight" => array(
							"title" => __("Autoheight", 'blessing'),
							"desc" => __("Change whole slider's height (make it equal current slide's height)", 'blessing'),
							"value" => "yes",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"custom" => array(
							"title" => __("Custom", 'blessing'),
							"desc" => __("Allow get testimonials from inner shortcodes (custom) or get it from specified group (cat)", 'blessing'),
							"divider" => true,
							"value" => "no",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"cat" => array(
							"title" => __("Categories", 'blessing'),
							"desc" => __("Select categories (groups) to show testimonials. If empty - select testimonials from any category (group) or from IDs list", 'blessing'),
							"dependency" => array(
								'custom' => array('yes')
							),
							"divider" => true,
							"value" => "",
							"type" => "select",
							"style" => "list",
							"multiple" => true,
							"options" => $ANCORA_GLOBALS['sc_params']['testimonials_groups']
						),
						"count" => array(
							"title" => __("Number of posts", 'blessing'),
							"desc" => __("How many posts will be displayed? If used IDs - this parameter ignored.", 'blessing'),
							"dependency" => array(
								'custom' => array('yes')
							),
							"value" => 3,
							"min" => 1,
							"max" => 100,
							"type" => "spinner"
						),
						"offset" => array(
							"title" => __("Offset before select posts", 'blessing'),
							"desc" => __("Skip posts before select next part.", 'blessing'),
							"dependency" => array(
								'custom' => array('yes')
							),
							"value" => 0,
							"min" => 0,
							"type" => "spinner"
						),
						"orderby" => array(
							"title" => __("Post order by", 'blessing'),
							"desc" => __("Select desired posts sorting method", 'blessing'),
							"dependency" => array(
								'custom' => array('yes')
							),
							"value" => "date",
							"type" => "select",
							"options" => $ANCORA_GLOBALS['sc_params']['sorting']
						),
						"order" => array(
							"title" => __("Post order", 'blessing'),
							"desc" => __("Select desired posts order", 'blessing'),
							"dependency" => array(
								'custom' => array('yes')
							),
							"value" => "desc",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['ordering']
						),
						"ids" => array(
							"title" => __("Post IDs list", 'blessing'),
							"desc" => __("Comma separated list of posts ID. If set - parameters above are ignored!", 'blessing'),
							"dependency" => array(
								'custom' => array('yes')
							),
							"value" => "",
							"type" => "text"
						),
						"bg_tint" => array(
							"title" => __("Background tint", 'blessing'),
							"desc" => __("Main background tint: dark or light", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "checklist",
							"options" => $ANCORA_GLOBALS['sc_params']['tint']
						),
						"bg_color" => array(
							"title" => __("Background color", 'blessing'),
							"desc" => __("Any background color for this section", 'blessing'),
							"value" => "",
							"type" => "color"
						),
						"bg_image" => array(
							"title" => __("Background image URL", 'blessing'),
							"desc" => __("Select or upload image or write URL from other site for the background", 'blessing'),
							"readonly" => false,
							"value" => "",
							"type" => "media"
						),
						"bg_overlay" => array(
							"title" => __("Overlay", 'blessing'),
							"desc" => __("Overlay color opacity (from 0.0 to 1.0)", 'blessing'),
							"min" => "0",
							"max" => "1",
							"step" => "0.1",
							"value" => "0",
							"type" => "spinner"
						),
						"bg_texture" => array(
							"title" => __("Texture", 'blessing'),
							"desc" => __("Predefined texture style from 1 to 11. 0 - without texture.", 'blessing'),
							"min" => "0",
							"max" => "11",
							"step" => "1",
							"value" => "0",
							"type" => "spinner"
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					),
					"children" => array(
						"name" => "trx_testimonials_item",
						"title" => __("Item", 'blessing'),
						"desc" => __("Testimonials item", 'blessing'),
						"container" => true,
						"params" => array(
							"author" => array(
								"title" => __("Author", 'blessing'),
								"desc" => __("Name of the testimonmials author", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"link" => array(
								"title" => __("Link", 'blessing'),
								"desc" => __("Link URL to the testimonmials author page", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"email" => array(
								"title" => __("E-mail", 'blessing'),
								"desc" => __("E-mail of the testimonmials author (to get gravatar)", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"photo" => array(
								"title" => __("Photo", 'blessing'),
								"desc" => __("Select or upload photo of testimonmials author or write URL of photo from other site", 'blessing'),
								"value" => "",
								"type" => "media"
							),
							"_content_" => array(
								"title" => __("Testimonials text", 'blessing'),
								"desc" => __("Current testimonials text", 'blessing'),
								"divider" => true,
								"rows" => 4,
								"value" => "",
								"type" => "textarea"
							),
							"id" => $ANCORA_GLOBALS['sc_params']['id'],
							"class" => $ANCORA_GLOBALS['sc_params']['class'],
							"css" => $ANCORA_GLOBALS['sc_params']['css']
						)
					)
				),
			
			
			
			
				// Title
				"trx_title" => array(
					"title" => __("Title", 'blessing'),
					"desc" => __("Create header tag (1-6 level) with many styles", 'blessing'),
					"decorate" => false,
					"container" => true,
					"params" => array(
						"_content_" => array(
							"title" => __("Title content", 'blessing'),
							"desc" => __("Title content", 'blessing'),
							"rows" => 4,
							"value" => "",
							"type" => "textarea"
						),
						"type" => array(
							"title" => __("Title type", 'blessing'),
							"desc" => __("Title type (header level)", 'blessing'),
							"divider" => true,
							"value" => "1",
							"type" => "select",
							"options" => array(
								'1' => __('Header 1', 'blessing'),
								'2' => __('Header 2', 'blessing'),
								'3' => __('Header 3', 'blessing'),
								'4' => __('Header 4', 'blessing'),
								'5' => __('Header 5', 'blessing'),
								'6' => __('Header 6', 'blessing'),
							)
						),
						"style" => array(
							"title" => __("Title style", 'blessing'),
							"desc" => __("Title style", 'blessing'),
							"value" => "regular",
							"type" => "select",
							"options" => array(
								'regular' => __('Regular', 'blessing'),
								'underline' => __('Underline', 'blessing'),
								'divider' => __('Divider', 'blessing'),
								'iconed' => __('With icon (image)', 'blessing')
							)
						),
						"align" => array(
							"title" => __("Alignment", 'blessing'),
							"desc" => __("Title text alignment", 'blessing'),
							"value" => "",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						), 
						"font_size" => array(
							"title" => __("Font_size", 'blessing'),
							"desc" => __("Custom font size. If empty - use theme default", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"font_weight" => array(
							"title" => __("Font weight", 'blessing'),
							"desc" => __("Custom font weight. If empty or inherit - use theme default", 'blessing'),
							"value" => "",
							"type" => "select",
							"size" => "medium",
							"options" => array(
								'inherit' => __('Default', 'blessing'),
								'100' => __('Thin (100)', 'blessing'),
								'300' => __('Light (300)', 'blessing'),
								'400' => __('Normal (400)', 'blessing'),
								'600' => __('Semibold (600)', 'blessing'),
								'700' => __('Bold (700)', 'blessing'),
								'900' => __('Black (900)', 'blessing')
							)
						),
                        "fig_border" => array(
                            "title" => __("Figure botoom border", 'blessing'),
                            "desc" => __("Apply a figure botoom border", 'blessing'),
                            "value" => "",
                            "type" => "checklist",
                            "options" => array('No' => '', 'Yes' => 'fig_border'),
                        ),
                        "color" => array(
							"title" => __("Title color", 'blessing'),
							"desc" => __("Select color for the title", 'blessing'),
							"value" => "",
							"type" => "color"
						),
						"icon" => array(
							"title" => __('Title font icon',  'blessing'),
							"desc" => __("Select font icon for the title from Fontello icons set (if style=iconed)",  'blessing'),
							"dependency" => array(
								'style' => array('iconed')
							),
							"value" => "",
							"type" => "icons",
							"options" => $ANCORA_GLOBALS['sc_params']['icons']
						),
						"image" => array(
							"title" => __('or image icon',  'blessing'),
							"desc" => __("Select image icon for the title instead icon above (if style=iconed)",  'blessing'),
							"dependency" => array(
								'style' => array('iconed')
							),
							"value" => "",
							"type" => "images",
							"size" => "small",
							"options" => $ANCORA_GLOBALS['sc_params']['images']
						),
						"picture" => array(
							"title" => __('or URL for image file', 'blessing'),
							"desc" => __("Select or upload image or write URL from other site (if style=iconed)", 'blessing'),
							"dependency" => array(
								'style' => array('iconed')
							),
							"readonly" => false,
							"value" => "",
							"type" => "media"
						),
						"image_size" => array(
							"title" => __('Image (picture) size', 'blessing'),
							"desc" => __("Select image (picture) size (if style='iconed')", 'blessing'),
							"dependency" => array(
								'style' => array('iconed')
							),
							"value" => "small",
							"type" => "checklist",
							"options" => array(
								'small' => __('Small', 'blessing'),
								'medium' => __('Medium', 'blessing'),
								'large' => __('Large', 'blessing')
							)
						),
						"position" => array(
							"title" => __('Icon (image) position', 'blessing'),
							"desc" => __("Select icon (image) position (if style=iconed)", 'blessing'),
							"dependency" => array(
								'style' => array('iconed')
							),
							"value" => "left",
							"type" => "checklist",
							"options" => array(
								'top' => __('Top', 'blessing'),
								'left' => __('Left', 'blessing')
							)
						),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
			
				// Toggles
				"trx_toggles" => array(
					"title" => __("Toggles", 'blessing'),
					"desc" => __("Toggles items", 'blessing'),
					"decorate" => true,
					"container" => false,
					"params" => array(
						"style" => array(
							"title" => __("Toggles style", 'blessing'),
							"desc" => __("Select style for display toggles", 'blessing'),
							"value" => 1,
							"options" => array(
								1 => __('Style 1', 'blessing'),
								2 => __('Style 2', 'blessing')
							),
							"type" => "radio"
						),
						"counter" => array(
							"title" => __("Counter", 'blessing'),
							"desc" => __("Display counter before each toggles title", 'blessing'),
							"value" => "off",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['on_off']
						),
						"icon_closed" => array(
							"title" => __("Icon while closed",  'blessing'),
							"desc" => __('Select icon for the closed toggles item from Fontello icons set',  'blessing'),
							"value" => "",
							"type" => "icons",
							"options" => $ANCORA_GLOBALS['sc_params']['icons']
						),
						"icon_opened" => array(
							"title" => __("Icon while opened",  'blessing'),
							"desc" => __('Select icon for the opened toggles item from Fontello icons set',  'blessing'),
							"value" => "",
							"type" => "icons",
							"options" => $ANCORA_GLOBALS['sc_params']['icons']
						),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					),
					"children" => array(
						"name" => "trx_toggles_item",
						"title" => __("Toggles item", 'blessing'),
						"desc" => __("Toggles item", 'blessing'),
						"container" => true,
						"params" => array(
							"title" => array(
								"title" => __("Toggles item title", 'blessing'),
								"desc" => __("Title for current toggles item", 'blessing'),
								"value" => "",
								"type" => "text"
							),
							"open" => array(
								"title" => __("Open on show", 'blessing'),
								"desc" => __("Open current toggles item on show", 'blessing'),
								"value" => "no",
								"type" => "switch",
								"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
							),
							"icon_closed" => array(
								"title" => __("Icon while closed",  'blessing'),
								"desc" => __('Select icon for the closed toggles item from Fontello icons set',  'blessing'),
								"value" => "",
								"type" => "icons",
								"options" => $ANCORA_GLOBALS['sc_params']['icons']
							),
							"icon_opened" => array(
								"title" => __("Icon while opened",  'blessing'),
								"desc" => __('Select icon for the opened toggles item from Fontello icons set',  'blessing'),
								"value" => "",
								"type" => "icons",
								"options" => $ANCORA_GLOBALS['sc_params']['icons']
							),
							"_content_" => array(
								"title" => __("Toggles item content", 'blessing'),
								"desc" => __("Current toggles item content", 'blessing'),
								"rows" => 4,
								"value" => "",
								"type" => "textarea"
							),
							"id" => $ANCORA_GLOBALS['sc_params']['id'],
							"class" => $ANCORA_GLOBALS['sc_params']['class'],
							"css" => $ANCORA_GLOBALS['sc_params']['css']
						)
					)
				),
			
			
			
			
			
				// Tooltip
				"trx_tooltip" => array(
					"title" => __("Tooltip", 'blessing'),
					"desc" => __("Create tooltip for selected text", 'blessing'),
					"decorate" => false,
					"container" => true,
					"params" => array(
						"title" => array(
							"title" => __("Title", 'blessing'),
							"desc" => __("Tooltip title (required)", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"_content_" => array(
							"title" => __("Tipped content", 'blessing'),
							"desc" => __("Highlighted content with tooltip", 'blessing'),
							"divider" => true,
							"rows" => 4,
							"value" => "",
							"type" => "textarea"
						),
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),

			
				// Twitter
				"trx_twitter" => array(
					"title" => __("Twitter", 'blessing'),
					"desc" => __("Insert twitter feed into post (page)", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"user" => array(
							"title" => __("Twitter Username", 'blessing'),
							"desc" => __("Your username in the twitter account. If empty - get it from Theme Options.", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"consumer_key" => array(
							"title" => __("Consumer Key", 'blessing'),
							"desc" => __("Consumer Key from the twitter account", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"consumer_secret" => array(
							"title" => __("Consumer Secret", 'blessing'),
							"desc" => __("Consumer Secret from the twitter account", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"token_key" => array(
							"title" => __("Token Key", 'blessing'),
							"desc" => __("Token Key from the twitter account", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"token_secret" => array(
							"title" => __("Token Secret", 'blessing'),
							"desc" => __("Token Secret from the twitter account", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"count" => array(
							"title" => __("Tweets number", 'blessing'),
							"desc" => __("Tweets number to show", 'blessing'),
							"divider" => true,
							"value" => 3,
							"max" => 20,
							"min" => 1,
							"type" => "spinner"
						),
						"controls" => array(
							"title" => __("Show arrows", 'blessing'),
							"desc" => __("Show control buttons", 'blessing'),
							"value" => "yes",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"interval" => array(
							"title" => __("Tweets change interval", 'blessing'),
							"desc" => __("Tweets change interval (in milliseconds: 1000ms = 1s)", 'blessing'),
							"value" => 7000,
							"step" => 500,
							"min" => 0,
							"type" => "spinner"
						),
						"align" => array(
							"title" => __("Alignment", 'blessing'),
							"desc" => __("Alignment of the tweets block", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						),
						"autoheight" => array(
							"title" => __("Autoheight", 'blessing'),
							"desc" => __("Change whole slider's height (make it equal current slide's height)", 'blessing'),
							"value" => "yes",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						),
						"bg_tint" => array(
							"title" => __("Background tint", 'blessing'),
							"desc" => __("Main background tint: dark or light", 'blessing'),
							"divider" => true,
							"value" => "",
							"type" => "checklist",
							"options" => $ANCORA_GLOBALS['sc_params']['tint']
						),
						"bg_color" => array(
							"title" => __("Background color", 'blessing'),
							"desc" => __("Any background color for this section", 'blessing'),
							"value" => "",
							"type" => "color"
						),
						"bg_image" => array(
							"title" => __("Background image URL", 'blessing'),
							"desc" => __("Select or upload image or write URL from other site for the background", 'blessing'),
							"readonly" => false,
							"value" => "",
							"type" => "media"
						),
						"bg_overlay" => array(
							"title" => __("Overlay", 'blessing'),
							"desc" => __("Overlay color opacity (from 0.0 to 1.0)", 'blessing'),
							"min" => "0",
							"max" => "1",
							"step" => "0.1",
							"value" => "0",
							"type" => "spinner"
						),
						"bg_texture" => array(
							"title" => __("Texture", 'blessing'),
							"desc" => __("Predefined texture style from 1 to 11. 0 - without texture.", 'blessing'),
							"min" => "0",
							"max" => "11",
							"step" => "1",
							"value" => "0",
							"type" => "spinner"
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
				// Video
				"trx_video" => array(
					"title" => __("Video", 'blessing'),
					"desc" => __("Insert video player", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"url" => array(
							"title" => __("URL for video file", 'blessing'),
							"desc" => __("Select video from media library or paste URL for video file from other site", 'blessing'),
							"readonly" => false,
							"value" => "",
							"type" => "media",
							"before" => array(
								'title' => __('Choose video', 'blessing'),
								'action' => 'media_upload',
								'type' => 'video',
								'multiple' => false,
								'linked_field' => '',
								'captions' => array( 	
									'choose' => __('Choose video file', 'blessing'),
									'update' => __('Select video file', 'blessing')
								)
							),
							"after" => array(
								'icon' => 'icon-cancel',
								'action' => 'media_reset'
							)
						),
						"ratio" => array(
							"title" => __("Ratio", 'blessing'),
							"desc" => __("Ratio of the video", 'blessing'),
							"value" => "16:9",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => array(
								"16:9" => __("16:9", 'blessing'),
								"4:3" => __("4:3", 'blessing')
							)
						),
						"autoplay" => array(
							"title" => __("Autoplay video", 'blessing'),
							"desc" => __("Autoplay video on page load", 'blessing'),
							"value" => "off",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['on_off']
						),
						"align" => array(
							"title" => __("Align", 'blessing'),
							"desc" => __("Select block alignment", 'blessing'),
							"value" => "none",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['align']
						),
						"image" => array(
							"title" => __("Cover image", 'blessing'),
							"desc" => __("Select or upload image or write URL from other site for video preview", 'blessing'),
							"readonly" => false,
							"value" => "",
							"type" => "media"
						),
						"bg_image" => array(
							"title" => __("Background image", 'blessing'),
							"desc" => __("Select or upload image or write URL from other site for video background. Attention! If you use background image - specify paddings below from background margins to video block in percents!", 'blessing'),
							"divider" => true,
							"readonly" => false,
							"value" => "",
							"type" => "media"
						),
						"bg_top" => array(
							"title" => __("Top offset", 'blessing'),
							"desc" => __("Top offset (padding) inside background image to video block (in percent). For example: 3%", 'blessing'),
							"dependency" => array(
								'bg_image' => array('not_empty')
							),
							"value" => "",
							"type" => "text"
						),
						"bg_bottom" => array(
							"title" => __("Bottom offset", 'blessing'),
							"desc" => __("Bottom offset (padding) inside background image to video block (in percent). For example: 3%", 'blessing'),
							"dependency" => array(
								'bg_image' => array('not_empty')
							),
							"value" => "",
							"type" => "text"
						),
						"bg_left" => array(
							"title" => __("Left offset", 'blessing'),
							"desc" => __("Left offset (padding) inside background image to video block (in percent). For example: 20%", 'blessing'),
							"dependency" => array(
								'bg_image' => array('not_empty')
							),
							"value" => "",
							"type" => "text"
						),
						"bg_right" => array(
							"title" => __("Right offset", 'blessing'),
							"desc" => __("Right offset (padding) inside background image to video block (in percent). For example: 12%", 'blessing'),
							"dependency" => array(
								'bg_image' => array('not_empty')
							),
							"value" => "",
							"type" => "text"
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				),
			
			
			
			
				// Zoom
				"trx_zoom" => array(
					"title" => __("Zoom", 'blessing'),
					"desc" => __("Insert the image with zoom/lens effect", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"effect" => array(
							"title" => __("Effect", 'blessing'),
							"desc" => __("Select effect to display overlapping image", 'blessing'),
							"value" => "lens",
							"size" => "medium",
							"type" => "switch",
							"options" => array(
								"lens" => __('Lens', 'blessing'),
								"zoom" => __('Zoom', 'blessing')
							)
						),
						"url" => array(
							"title" => __("Main image", 'blessing'),
							"desc" => __("Select or upload main image", 'blessing'),
							"readonly" => false,
							"value" => "",
							"type" => "media"
						),
						"over" => array(
							"title" => __("Overlaping image", 'blessing'),
							"desc" => __("Select or upload overlaping image", 'blessing'),
							"readonly" => false,
							"value" => "",
							"type" => "media"
						),
						"align" => array(
							"title" => __("Float zoom", 'blessing'),
							"desc" => __("Float zoom to left or right side", 'blessing'),
							"value" => "",
							"type" => "checklist",
							"dir" => "horizontal",
							"options" => $ANCORA_GLOBALS['sc_params']['float']
						), 
						"bg_image" => array(
							"title" => __("Background image", 'blessing'),
							"desc" => __("Select or upload image or write URL from other site for zoom block background. Attention! If you use background image - specify paddings below from background margins to zoom block in percents!", 'blessing'),
							"divider" => true,
							"readonly" => false,
							"value" => "",
							"type" => "media"
						),
						"bg_top" => array(
							"title" => __("Top offset", 'blessing'),
							"desc" => __("Top offset (padding) inside background image to zoom block (in percent). For example: 3%", 'blessing'),
							"dependency" => array(
								'bg_image' => array('not_empty')
							),
							"value" => "",
							"type" => "text"
						),
						"bg_bottom" => array(
							"title" => __("Bottom offset", 'blessing'),
							"desc" => __("Bottom offset (padding) inside background image to zoom block (in percent). For example: 3%", 'blessing'),
							"dependency" => array(
								'bg_image' => array('not_empty')
							),
							"value" => "",
							"type" => "text"
						),
						"bg_left" => array(
							"title" => __("Left offset", 'blessing'),
							"desc" => __("Left offset (padding) inside background image to zoom block (in percent). For example: 20%", 'blessing'),
							"dependency" => array(
								'bg_image' => array('not_empty')
							),
							"value" => "",
							"type" => "text"
						),
						"bg_right" => array(
							"title" => __("Right offset", 'blessing'),
							"desc" => __("Right offset (padding) inside background image to zoom block (in percent). For example: 12%", 'blessing'),
							"dependency" => array(
								'bg_image' => array('not_empty')
							),
							"value" => "",
							"type" => "text"
						),
						"width" => ancora_shortcodes_width(),
						"height" => ancora_shortcodes_height(),
						"top" => $ANCORA_GLOBALS['sc_params']['top'],
						"bottom" => $ANCORA_GLOBALS['sc_params']['bottom'],
						"left" => $ANCORA_GLOBALS['sc_params']['left'],
						"right" => $ANCORA_GLOBALS['sc_params']['right'],
						"id" => $ANCORA_GLOBALS['sc_params']['id'],
						"class" => $ANCORA_GLOBALS['sc_params']['class'],
						"animation" => $ANCORA_GLOBALS['sc_params']['animation'],
						"css" => $ANCORA_GLOBALS['sc_params']['css']
					)
				)
			);
	
			// Woocommerce Shortcodes list
			//------------------------------------------------------------------
			if (ancora_exists_woocommerce()) {
				
				// WooCommerce - Cart
				$ANCORA_GLOBALS['shortcodes']["woocommerce_cart"] = array(
					"title" => __("Woocommerce: Cart", 'blessing'),
					"desc" => __("WooCommerce shortcode: show Cart page", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array()
				);
				
				// WooCommerce - Checkout
				$ANCORA_GLOBALS['shortcodes']["woocommerce_checkout"] = array(
					"title" => __("Woocommerce: Checkout", 'blessing'),
					"desc" => __("WooCommerce shortcode: show Checkout page", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array()
				);
				
				// WooCommerce - My Account
				$ANCORA_GLOBALS['shortcodes']["woocommerce_my_account"] = array(
					"title" => __("Woocommerce: My Account", 'blessing'),
					"desc" => __("WooCommerce shortcode: show My Account page", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array()
				);
				
				// WooCommerce - Order Tracking
				$ANCORA_GLOBALS['shortcodes']["woocommerce_order_tracking"] = array(
					"title" => __("Woocommerce: Order Tracking", 'blessing'),
					"desc" => __("WooCommerce shortcode: show Order Tracking page", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array()
				);
				
				// WooCommerce - Shop Messages
				$ANCORA_GLOBALS['shortcodes']["shop_messages"] = array(
					"title" => __("Woocommerce: Shop Messages", 'blessing'),
					"desc" => __("WooCommerce shortcode: show shop messages", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array()
				);
				
				// WooCommerce - Product Page
				$ANCORA_GLOBALS['shortcodes']["product_page"] = array(
					"title" => __("Woocommerce: Product Page", 'blessing'),
					"desc" => __("WooCommerce shortcode: display single product page", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"sku" => array(
							"title" => __("SKU", 'blessing'),
							"desc" => __("SKU code of displayed product", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"id" => array(
							"title" => __("ID", 'blessing'),
							"desc" => __("ID of displayed product", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"posts_per_page" => array(
							"title" => __("Number", 'blessing'),
							"desc" => __("How many products showed", 'blessing'),
							"value" => "1",
							"min" => 1,
							"type" => "spinner"
						),
						"post_type" => array(
							"title" => __("Post type", 'blessing'),
							"desc" => __("Post type for the WP query (leave 'product')", 'blessing'),
							"value" => "product",
							"type" => "text"
						),
						"post_status" => array(
							"title" => __("Post status", 'blessing'),
							"desc" => __("Display posts only with this status", 'blessing'),
							"value" => "publish",
							"type" => "select",
							"options" => array(
								"publish" => __('Publish', 'blessing'),
								"protected" => __('Protected', 'blessing'),
								"private" => __('Private', 'blessing'),
								"pending" => __('Pending', 'blessing'),
								"draft" => __('Draft', 'blessing')
							)
						)
					)
				);
				
				// WooCommerce - Product
				$ANCORA_GLOBALS['shortcodes']["product"] = array(
					"title" => __("Woocommerce: Product", 'blessing'),
					"desc" => __("WooCommerce shortcode: display one product", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"sku" => array(
							"title" => __("SKU", 'blessing'),
							"desc" => __("SKU code of displayed product", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"id" => array(
							"title" => __("ID", 'blessing'),
							"desc" => __("ID of displayed product", 'blessing'),
							"value" => "",
							"type" => "text"
						)
					)
				);
				
				// WooCommerce - Best Selling Products
				$ANCORA_GLOBALS['shortcodes']["best_selling_products"] = array(
					"title" => __("Woocommerce: Best Selling Products", 'blessing'),
					"desc" => __("WooCommerce shortcode: show best selling products", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"per_page" => array(
							"title" => __("Number", 'blessing'),
							"desc" => __("How many products showed", 'blessing'),
							"value" => 4,
							"min" => 1,
							"type" => "spinner"
						),
						"columns" => array(
							"title" => __("Columns", 'blessing'),
							"desc" => __("How many columns per row use for products output", 'blessing'),
							"value" => 4,
							"min" => 2,
							"max" => 4,
							"type" => "spinner"
						)
					)
				);
				
				// WooCommerce - Recent Products
				$ANCORA_GLOBALS['shortcodes']["recent_products"] = array(
					"title" => __("Woocommerce: Recent Products", 'blessing'),
					"desc" => __("WooCommerce shortcode: show recent products", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"per_page" => array(
							"title" => __("Number", 'blessing'),
							"desc" => __("How many products showed", 'blessing'),
							"value" => 4,
							"min" => 1,
							"type" => "spinner"
						),
						"columns" => array(
							"title" => __("Columns", 'blessing'),
							"desc" => __("How many columns per row use for products output", 'blessing'),
							"value" => 4,
							"min" => 2,
							"max" => 4,
							"type" => "spinner"
						),
						"orderby" => array(
							"title" => __("Order by", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "date",
							"type" => "select",
							"options" => array(
								"date" => __('Date', 'blessing'),
								"title" => __('Title', 'blessing')
							)
						),
						"order" => array(
							"title" => __("Order", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "desc",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['ordering']
						)
					)
				);
				
				// WooCommerce - Related Products
				$ANCORA_GLOBALS['shortcodes']["related_products"] = array(
					"title" => __("Woocommerce: Related Products", 'blessing'),
					"desc" => __("WooCommerce shortcode: show related products", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"posts_per_page" => array(
							"title" => __("Number", 'blessing'),
							"desc" => __("How many products showed", 'blessing'),
							"value" => 4,
							"min" => 1,
							"type" => "spinner"
						),
						"columns" => array(
							"title" => __("Columns", 'blessing'),
							"desc" => __("How many columns per row use for products output", 'blessing'),
							"value" => 4,
							"min" => 2,
							"max" => 4,
							"type" => "spinner"
						),
						"orderby" => array(
							"title" => __("Order by", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "date",
							"type" => "select",
							"options" => array(
								"date" => __('Date', 'blessing'),
								"title" => __('Title', 'blessing')
							)
						)
					)
				);
				
				// WooCommerce - Featured Products
				$ANCORA_GLOBALS['shortcodes']["featured_products"] = array(
					"title" => __("Woocommerce: Featured Products", 'blessing'),
					"desc" => __("WooCommerce shortcode: show featured products", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"per_page" => array(
							"title" => __("Number", 'blessing'),
							"desc" => __("How many products showed", 'blessing'),
							"value" => 4,
							"min" => 1,
							"type" => "spinner"
						),
						"columns" => array(
							"title" => __("Columns", 'blessing'),
							"desc" => __("How many columns per row use for products output", 'blessing'),
							"value" => 4,
							"min" => 2,
							"max" => 4,
							"type" => "spinner"
						),
						"orderby" => array(
							"title" => __("Order by", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "date",
							"type" => "select",
							"options" => array(
								"date" => __('Date', 'blessing'),
								"title" => __('Title', 'blessing')
							)
						),
						"order" => array(
							"title" => __("Order", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "desc",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['ordering']
						)
					)
				);
				
				// WooCommerce - Top Rated Products
				$ANCORA_GLOBALS['shortcodes']["featured_products"] = array(
					"title" => __("Woocommerce: Top Rated Products", 'blessing'),
					"desc" => __("WooCommerce shortcode: show top rated products", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"per_page" => array(
							"title" => __("Number", 'blessing'),
							"desc" => __("How many products showed", 'blessing'),
							"value" => 4,
							"min" => 1,
							"type" => "spinner"
						),
						"columns" => array(
							"title" => __("Columns", 'blessing'),
							"desc" => __("How many columns per row use for products output", 'blessing'),
							"value" => 4,
							"min" => 2,
							"max" => 4,
							"type" => "spinner"
						),
						"orderby" => array(
							"title" => __("Order by", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "date",
							"type" => "select",
							"options" => array(
								"date" => __('Date', 'blessing'),
								"title" => __('Title', 'blessing')
							)
						),
						"order" => array(
							"title" => __("Order", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "desc",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['ordering']
						)
					)
				);
				
				// WooCommerce - Sale Products
				$ANCORA_GLOBALS['shortcodes']["featured_products"] = array(
					"title" => __("Woocommerce: Sale Products", 'blessing'),
					"desc" => __("WooCommerce shortcode: list products on sale", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"per_page" => array(
							"title" => __("Number", 'blessing'),
							"desc" => __("How many products showed", 'blessing'),
							"value" => 4,
							"min" => 1,
							"type" => "spinner"
						),
						"columns" => array(
							"title" => __("Columns", 'blessing'),
							"desc" => __("How many columns per row use for products output", 'blessing'),
							"value" => 4,
							"min" => 2,
							"max" => 4,
							"type" => "spinner"
						),
						"orderby" => array(
							"title" => __("Order by", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "date",
							"type" => "select",
							"options" => array(
								"date" => __('Date', 'blessing'),
								"title" => __('Title', 'blessing')
							)
						),
						"order" => array(
							"title" => __("Order", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "desc",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['ordering']
						)
					)
				);
				
				// WooCommerce - Product Category
				$ANCORA_GLOBALS['shortcodes']["product_category"] = array(
					"title" => __("Woocommerce: Products from category", 'blessing'),
					"desc" => __("WooCommerce shortcode: list products in specified category(-ies)", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"per_page" => array(
							"title" => __("Number", 'blessing'),
							"desc" => __("How many products showed", 'blessing'),
							"value" => 4,
							"min" => 1,
							"type" => "spinner"
						),
						"columns" => array(
							"title" => __("Columns", 'blessing'),
							"desc" => __("How many columns per row use for products output", 'blessing'),
							"value" => 4,
							"min" => 2,
							"max" => 4,
							"type" => "spinner"
						),
						"orderby" => array(
							"title" => __("Order by", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "date",
							"type" => "select",
							"options" => array(
								"date" => __('Date', 'blessing'),
								"title" => __('Title', 'blessing')
							)
						),
						"order" => array(
							"title" => __("Order", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "desc",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['ordering']
						),
						"category" => array(
							"title" => __("Categories", 'blessing'),
							"desc" => __("Comma separated category slugs", 'blessing'),
							"value" => '',
							"type" => "text"
						),
						"operator" => array(
							"title" => __("Operator", 'blessing'),
							"desc" => __("Categories operator", 'blessing'),
							"value" => "IN",
							"type" => "checklist",
							"size" => "medium",
							"options" => array(
								"IN" => __('IN', 'blessing'),
								"NOT IN" => __('NOT IN', 'blessing'),
								"AND" => __('AND', 'blessing')
							)
						)
					)
				);
				
				// WooCommerce - Products
				$ANCORA_GLOBALS['shortcodes']["products"] = array(
					"title" => __("Woocommerce: Products", 'blessing'),
					"desc" => __("WooCommerce shortcode: list all products", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"skus" => array(
							"title" => __("SKUs", 'blessing'),
							"desc" => __("Comma separated SKU codes of products", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"ids" => array(
							"title" => __("IDs", 'blessing'),
							"desc" => __("Comma separated ID of products", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"columns" => array(
							"title" => __("Columns", 'blessing'),
							"desc" => __("How many columns per row use for products output", 'blessing'),
							"value" => 4,
							"min" => 2,
							"max" => 4,
							"type" => "spinner"
						),
						"orderby" => array(
							"title" => __("Order by", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "date",
							"type" => "select",
							"options" => array(
								"date" => __('Date', 'blessing'),
								"title" => __('Title', 'blessing')
							)
						),
						"order" => array(
							"title" => __("Order", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "desc",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['ordering']
						)
					)
				);
				
				// WooCommerce - Product attribute
				$ANCORA_GLOBALS['shortcodes']["product_attribute"] = array(
					"title" => __("Woocommerce: Products by Attribute", 'blessing'),
					"desc" => __("WooCommerce shortcode: show products with specified attribute", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"per_page" => array(
							"title" => __("Number", 'blessing'),
							"desc" => __("How many products showed", 'blessing'),
							"value" => 4,
							"min" => 1,
							"type" => "spinner"
						),
						"columns" => array(
							"title" => __("Columns", 'blessing'),
							"desc" => __("How many columns per row use for products output", 'blessing'),
							"value" => 4,
							"min" => 2,
							"max" => 4,
							"type" => "spinner"
						),
						"orderby" => array(
							"title" => __("Order by", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "date",
							"type" => "select",
							"options" => array(
								"date" => __('Date', 'blessing'),
								"title" => __('Title', 'blessing')
							)
						),
						"order" => array(
							"title" => __("Order", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "desc",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['ordering']
						),
						"attribute" => array(
							"title" => __("Attribute", 'blessing'),
							"desc" => __("Attribute name", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"filter" => array(
							"title" => __("Filter", 'blessing'),
							"desc" => __("Attribute value", 'blessing'),
							"value" => "",
							"type" => "text"
						)
					)
				);
				
				// WooCommerce - Products Categories
				$ANCORA_GLOBALS['shortcodes']["product_categories"] = array(
					"title" => __("Woocommerce: Product Categories", 'blessing'),
					"desc" => __("WooCommerce shortcode: show categories with products", 'blessing'),
					"decorate" => false,
					"container" => false,
					"params" => array(
						"number" => array(
							"title" => __("Number", 'blessing'),
							"desc" => __("How many categories showed", 'blessing'),
							"value" => 4,
							"min" => 1,
							"type" => "spinner"
						),
						"columns" => array(
							"title" => __("Columns", 'blessing'),
							"desc" => __("How many columns per row use for categories output", 'blessing'),
							"value" => 4,
							"min" => 2,
							"max" => 4,
							"type" => "spinner"
						),
						"orderby" => array(
							"title" => __("Order by", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "date",
							"type" => "select",
							"options" => array(
								"date" => __('Date', 'blessing'),
								"title" => __('Title', 'blessing')
							)
						),
						"order" => array(
							"title" => __("Order", 'blessing'),
							"desc" => __("Sorting order for products output", 'blessing'),
							"value" => "desc",
							"type" => "switch",
							"size" => "big",
							"options" => $ANCORA_GLOBALS['sc_params']['ordering']
						),
						"parent" => array(
							"title" => __("Parent", 'blessing'),
							"desc" => __("Parent category slug", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"ids" => array(
							"title" => __("IDs", 'blessing'),
							"desc" => __("Comma separated ID of products", 'blessing'),
							"value" => "",
							"type" => "text"
						),
						"hide_empty" => array(
							"title" => __("Hide empty", 'blessing'),
							"desc" => __("Hide empty categories", 'blessing'),
							"value" => "yes",
							"type" => "switch",
							"options" => $ANCORA_GLOBALS['sc_params']['yes_no']
						)
					)
				);

			}
			
			do_action('ancora_action_shortcodes_list');

		}
	}
}
?>