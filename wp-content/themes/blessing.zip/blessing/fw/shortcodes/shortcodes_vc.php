<?php

// Width and height params
if ( !function_exists( 'ancora_vc_width' ) ) {
	function ancora_vc_width($w='') {
		return array(
			"param_name" => "width",
			"heading" => __("Width", 'blessing'),
			"description" => __("Width (in pixels or percent) of the current element", 'blessing'),
			"group" => __('Size &amp; Margins', 'blessing'),
			"value" => $w,
			"type" => "textfield"
		);
	}
}
if ( !function_exists( 'ancora_vc_height' ) ) {
	function ancora_vc_height($h='') {
		return array(
			"param_name" => "height",
			"heading" => __("Height", 'blessing'),
			"description" => __("Height (only in pixels) of the current element", 'blessing'),
			"group" => __('Size &amp; Margins', 'blessing'),
			"value" => $h,
			"type" => "textfield"
		);
	}
}

// Load scripts and styles for VC support
if ( !function_exists( 'ancora_shortcodes_vc_scripts_admin' ) ) {
	//add_action( 'admin_enqueue_scripts', 'ancora_shortcodes_vc_scripts_admin' );
	function ancora_shortcodes_vc_scripts_admin() {
		// Include CSS 
		ancora_enqueue_style ( 'shortcodes_vc-style', ancora_get_file_url('shortcodes/shortcodes_vc_admin.css'), array(), null );
		// Include JS
		ancora_enqueue_script( 'shortcodes_vc-script', ancora_get_file_url('shortcodes/shortcodes_vc_admin.js'), array(), null, true );
	}
}

// Load scripts and styles for VC support
if ( !function_exists( 'ancora_shortcodes_vc_scripts_front' ) ) {
	//add_action( 'wp_enqueue_scripts', 'ancora_shortcodes_vc_scripts_front' );
	function ancora_shortcodes_vc_scripts_front() {
		if (ancora_vc_is_frontend()) {
			// Include CSS 
			ancora_enqueue_style ( 'shortcodes_vc-style', ancora_get_file_url('shortcodes/shortcodes_vc_front.css'), array(), null );
			// Include JS
			ancora_enqueue_script( 'shortcodes_vc-script', ancora_get_file_url('shortcodes/shortcodes_vc_front.js'), array(), null, true );
		}
	}
}

// Add init script into shortcodes output in VC frontend editor
if ( !function_exists( 'ancora_shortcodes_vc_add_init_script' ) ) {
	//add_filter('ancora_shortcode_output', 'ancora_shortcodes_vc_add_init_script', 10, 4);
	function ancora_shortcodes_vc_add_init_script($output, $tag='', $atts=array(), $content='') {
		if ( (isset($_GET['vc_editable']) && $_GET['vc_editable']=='true') && (isset($_POST['action']) && $_POST['action']=='vc_load_shortcode')
				&& ( isset($_POST['shortcodes'][0]['tag']) && $_POST['shortcodes'][0]['tag']==$tag )
		) {
			if (ancora_strpos($output, 'ancora_vc_init_shortcodes')===false) {
				$id = "ancora_vc_init_shortcodes_".str_replace('.', '', mt_rand());
				$output .= '
					<script id="'.esc_attr($id).'">
						try {
							ancora_init_post_formats();
							ancora_init_shortcodes(jQuery("body").eq(0));
							ancora_scroll_actions();
						} catch (e) { };
					</script>
				';
			}
		}
		return $output;
	}
}


/* Theme setup section
-------------------------------------------------------------------- */

if ( !function_exists( 'ancora_shortcodes_vc_theme_setup' ) ) {
	//if ( ancora_vc_is_frontend() )
	if ( (isset($_GET['vc_editable']) && $_GET['vc_editable']=='true') || (isset($_GET['vc_action']) && $_GET['vc_action']=='vc_inline') )
		add_action( 'ancora_action_before_init_theme', 'ancora_shortcodes_vc_theme_setup', 20 );
	else
		add_action( 'ancora_action_after_init_theme', 'ancora_shortcodes_vc_theme_setup' );
	function ancora_shortcodes_vc_theme_setup() {
		if (ancora_shortcodes_is_used()) {
			// Set VC as main editor for the theme
			vc_set_as_theme( true );
			
			// Enable VC on follow post types
			vc_set_default_editor_post_types( array('page', 'team', 'courses') );
			
			// Disable frontend editor
			//vc_disable_frontend();

			// Load scripts and styles for VC support
			add_action( 'wp_enqueue_scripts',		'ancora_shortcodes_vc_scripts_front');
			add_action( 'admin_enqueue_scripts',	'ancora_shortcodes_vc_scripts_admin' );

			// Add init script into shortcodes output in VC frontend editor
			add_filter('ancora_shortcode_output', 'ancora_shortcodes_vc_add_init_script', 10, 4);

			// Remove standard VC shortcodes
			vc_remove_element("vc_button");
			vc_remove_element("vc_posts_slider");
			vc_remove_element("vc_gmaps");
			vc_remove_element("vc_teaser_grid");
			vc_remove_element("vc_progress_bar");
			vc_remove_element("vc_facebook");
			vc_remove_element("vc_tweetmeme");
			vc_remove_element("vc_googleplus");
			vc_remove_element("vc_facebook");
			vc_remove_element("vc_pinterest");
			vc_remove_element("vc_message");
			vc_remove_element("vc_posts_grid");
			vc_remove_element("vc_carousel");
			vc_remove_element("vc_flickr");
			vc_remove_element("vc_tour");
			vc_remove_element("vc_separator");
			vc_remove_element("vc_single_image");
			vc_remove_element("vc_cta_button");
//			vc_remove_element("vc_accordion");
//			vc_remove_element("vc_accordion_tab");
			vc_remove_element("vc_toggle");
			vc_remove_element("vc_tabs");
			vc_remove_element("vc_tab");
			vc_remove_element("vc_images_carousel");
			
			// Remove standard WP widgets
			vc_remove_element("vc_wp_archives");
			vc_remove_element("vc_wp_calendar");
			vc_remove_element("vc_wp_categories");
			vc_remove_element("vc_wp_custommenu");
			vc_remove_element("vc_wp_links");
			vc_remove_element("vc_wp_meta");
			vc_remove_element("vc_wp_pages");
			vc_remove_element("vc_wp_posts");
			vc_remove_element("vc_wp_recentcomments");
			vc_remove_element("vc_wp_rss");
			vc_remove_element("vc_wp_search");
			vc_remove_element("vc_wp_tagcloud");
			vc_remove_element("vc_wp_text");
			
			global $ANCORA_GLOBALS;
			
			$ANCORA_GLOBALS['vc_params'] = array(
				
				// Common arrays and strings
				'category' => __("Ancora shortcodes", 'blessing'),
			
				// Current element id
				'id' => array(
					"param_name" => "id",
					"heading" => __("Element ID", 'blessing'),
					"description" => __("ID for current element", 'blessing'),
					"group" => __('Size &amp; Margins', 'blessing'),
					"value" => "",
					"type" => "textfield"
				),
			
				// Current element class
				'class' => array(
					"param_name" => "class",
					"heading" => __("Element CSS class", 'blessing'),
					"description" => __("CSS class for current element", 'blessing'),
					"group" => __('Size &amp; Margins', 'blessing'),
					"value" => "",
					"type" => "textfield"
				),

				// Current element animation
				'animation' => array(
					"param_name" => "animation",
					"heading" => __("Animation", 'blessing'),
					"description" => __("Select animation while object enter in the visible area of page", 'blessing'),
					"class" => "",
					"value" => array_flip($ANCORA_GLOBALS['sc_params']['animations']),
					"type" => "dropdown"
				),
			
				// Current element style
				'css' => array(
					"param_name" => "css",
					"heading" => __("CSS styles", 'blessing'),
					"description" => __("Any additional CSS rules (if need)", 'blessing'),
					"group" => __('Size &amp; Margins', 'blessing'),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
			
				// Margins params
				'margin_top' => array(
					"param_name" => "top",
					"heading" => __("Top margin", 'blessing'),
					"description" => __("Top margin (in pixels).", 'blessing'),
					"group" => __('Size &amp; Margins', 'blessing'),
					"value" => "",
					"type" => "textfield"
				),
			
				'margin_bottom' => array(
					"param_name" => "bottom",
					"heading" => __("Bottom margin", 'blessing'),
					"description" => __("Bottom margin (in pixels).", 'blessing'),
					"group" => __('Size &amp; Margins', 'blessing'),
					"value" => "",
					"type" => "textfield"
				),
			
				'margin_left' => array(
					"param_name" => "left",
					"heading" => __("Left margin", 'blessing'),
					"description" => __("Left margin (in pixels).", 'blessing'),
					"group" => __('Size &amp; Margins', 'blessing'),
					"value" => "",
					"type" => "textfield"
				),
				
				'margin_right' => array(
					"param_name" => "right",
					"heading" => __("Right margin", 'blessing'),
					"description" => __("Right margin (in pixels).", 'blessing'),
					"group" => __('Size &amp; Margins', 'blessing'),
					"value" => "",
					"type" => "textfield"
				)
			);
	
	
	
			// Accordion
			//-------------------------------------------------------------------------------------
			vc_map( array(
				"base" => "trx_accordion",
				"name" => __("Accordion", 'blessing'),
				"description" => __("Accordion items", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_accordion',
				"class" => "trx_sc_collection trx_sc_accordion",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => false,
				"as_parent" => array('only' => 'trx_accordion_item'),	// Use only|except attributes to limit child shortcodes (separate multiple values with comma)
				"params" => array(
					array(
						"param_name" => "style",
						"heading" => __("Accordion style", 'blessing'),
						"description" => __("Select style for display accordion", 'blessing'),
						"class" => "",
						"admin_label" => true,
						"value" => array(
							__('Style 1', 'blessing') => 1,
							__('Style 2', 'blessing') => 2
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "counter",
						"heading" => __("Counter", 'blessing'),
						"description" => __("Display counter before each accordion title", 'blessing'),
						"class" => "",
						"value" => array("Add item numbers before each element" => "on" ),
						"type" => "checkbox"
					),
					array(
						"param_name" => "initial",
						"heading" => __("Initially opened item", 'blessing'),
						"description" => __("Number of initially opened item", 'blessing'),
						"class" => "",
						"value" => 1,
						"type" => "textfield"
					),
					array(
						"param_name" => "icon_closed",
						"heading" => __("Icon while closed", 'blessing'),
						"description" => __("Select icon for the closed accordion item from Fontello icons set", 'blessing'),
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					array(
						"param_name" => "icon_opened",
						"heading" => __("Icon while opened", 'blessing'),
						"description" => __("Select icon for the opened accordion item from Fontello icons set", 'blessing'),
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'default_content' => '
					[trx_accordion_item title="' . __( 'Item 1 title', 'blessing' ) . '"][/trx_accordion_item]
					[trx_accordion_item title="' . __( 'Item 2 title', 'blessing' ) . '"][/trx_accordion_item]
				',
				"custom_markup" => '
					<div class="wpb_accordion_holder wpb_holder clearfix vc_container_for_children">
						%content%
					</div>
					<div class="tab_controls">
						<button class="add_tab" title="'.__("Add item", 'blessing').'">'.__("Add item", 'blessing').'</button>
					</div>
				',
				'js_view' => 'VcTrxAccordionView'
			) );
			
			
			vc_map( array(
				"base" => "trx_accordion_item",
				"name" => __("Accordion item", 'blessing'),
				"description" => __("Inner accordion item", 'blessing'),
				"show_settings_on_create" => true,
				"content_element" => true,
				"is_container" => true,
				'icon' => 'icon_trx_accordion_item',
				"as_child" => array('only' => 'trx_accordion'), 	// Use only|except attributes to limit parent (separate multiple values with comma)
				"as_parent" => array('except' => 'trx_accordion'),
				"params" => array(
					array(
						"param_name" => "title",
						"heading" => __("Title", 'blessing'),
						"description" => __("Title for current accordion item", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "icon_closed",
						"heading" => __("Icon while closed", 'blessing'),
						"description" => __("Select icon for the closed accordion item from Fontello icons set", 'blessing'),
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					array(
						"param_name" => "icon_opened",
						"heading" => __("Icon while opened", 'blessing'),
						"description" => __("Select icon for the opened accordion item from Fontello icons set", 'blessing'),
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
			  'js_view' => 'VcTrxAccordionTabView'
			) );

			class WPBakeryShortCode_Trx_Accordion extends ANCORA_VC_ShortCodeAccordion {}
			class WPBakeryShortCode_Trx_Accordion_Item extends ANCORA_VC_ShortCodeAccordionItem {}
			
			
			
			
			
			
			// Anchor
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_anchor",
				"name" => __("Anchor", 'blessing'),
				"description" => __("Insert anchor for the TOC (table of content)", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_anchor',
				"class" => "trx_sc_single trx_sc_anchor",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "icon",
						"heading" => __("Anchor's icon", 'blessing'),
						"description" => __("Select icon for the anchor from Fontello icons set", 'blessing'),
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					array(
						"param_name" => "title",
						"heading" => __("Short title", 'blessing'),
						"description" => __("Short title of the anchor (for the table of content)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "description",
						"heading" => __("Long description", 'blessing'),
						"description" => __("Description for the popup (then hover on the icon). You can use '{' and '}' - make the text italic, '|' - insert line break", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "url",
						"heading" => __("External URL", 'blessing'),
						"description" => __("External URL for this TOC item", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "separator",
						"heading" => __("Add separator", 'blessing'),
						"description" => __("Add separator under item in the TOC", 'blessing'),
						"class" => "",
						"value" => array("Add separator" => "yes" ),
						"type" => "checkbox"
					),
					$ANCORA_GLOBALS['vc_params']['id']
				),
			) );
			
			class WPBakeryShortCode_Trx_Anchor extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			// Audio
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_audio",
				"name" => __("Audio", 'blessing'),
				"description" => __("Insert audio player", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_audio',
				"class" => "trx_sc_single trx_sc_audio",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
                    array(
                        "param_name" => "style",
                        "heading" => __("Style", 'blessing'),
                        "description" => __("Select style", 'blessing'),
                        "class" => "",
                        "value" => array('Normal' => 'audio_normal', 'Dark' => 'audio_dark' ),
                        "type" => "dropdown"
                    ),
					array(
						"param_name" => "url",
						"heading" => __("URL for audio file", 'blessing'),
						"description" => __("Put here URL for audio file", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "image",
						"heading" => __("Cover image", 'blessing'),
						"description" => __("Select or upload image or write URL from other site for audio cover", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "title",
						"heading" => __("Title", 'blessing'),
						"description" => __("Title of the audio file", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "author",
						"heading" => __("Author", 'blessing'),
						"description" => __("Author of the audio file", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "controls",
						"heading" => __("Controls", 'blessing'),
						"description" => __("Show/hide controls", 'blessing'),
						"class" => "",
						"value" => array("Hide controls" => "hide" ),
						"type" => "checkbox"
					),
					array(
						"param_name" => "autoplay",
						"heading" => __("Autoplay", 'blessing'),
						"description" => __("Autoplay audio on page load", 'blessing'),
						"class" => "",
						"value" => array("Autoplay" => "on" ),
						"type" => "checkbox"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Select block alignment", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
			) );
			
			class WPBakeryShortCode_Trx_Audio extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Block
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_block",
				"name" => __("Block container", 'blessing'),
				"description" => __("Container for any block ([section] analog - to enable nesting)", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_block',
				"class" => "trx_sc_collection trx_sc_block",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "dedicated",
						"heading" => __("Dedicated", 'blessing'),
						"description" => __("Use this block as dedicated content - show it before post title on single page", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(__('Use as dedicated content', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Select block alignment", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "columns",
						"heading" => __("Columns emulation", 'blessing'),
						"description" => __("Select width for columns emulation", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['columns']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "pan",
						"heading" => __("Use pan effect", 'blessing'),
						"description" => __("Use pan effect to show section content", 'blessing'),
						"group" => __('Scroll', 'blessing'),
						"class" => "",
						"value" => array(__('Content scroller', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "scroll",
						"heading" => __("Use scroller", 'blessing'),
						"description" => __("Use scroller to show section content", 'blessing'),
						"group" => __('Scroll', 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(__('Content scroller', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "scroll_dir",
						"heading" => __("Scroll direction", 'blessing'),
						"description" => __("Scroll direction (if Use scroller = yes)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"group" => __('Scroll', 'blessing'),
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['dir']),
						'dependency' => array(
							'element' => 'scroll',
							'not_empty' => true
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "scroll_controls",
						"heading" => __("Scroll controls", 'blessing'),
						"description" => __("Show scroll controls (if Use scroller = yes)", 'blessing'),
						"class" => "",
						"group" => __('Scroll', 'blessing'),
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['dir']),
						'dependency' => array(
							'element' => 'scroll',
							'not_empty' => true
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "color",
						"heading" => __("Fore color", 'blessing'),
						"description" => __("Any color for objects in this section", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_tint",
						"heading" => __("Background tint", 'blessing'),
						"description" => __("Main background tint: dark or light", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['tint']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "bg_color",
						"heading" => __("Background color", 'blessing'),
						"description" => __("Any background color for this section", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_image",
						"heading" => __("Background image URL", 'blessing'),
						"description" => __("Select background image from library for this section", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "bg_overlay",
						"heading" => __("Overlay", 'blessing'),
						"description" => __("Overlay color opacity (from 0.0 to 1.0)", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_texture",
						"heading" => __("Texture", 'blessing'),
						"description" => __("Texture style from 1 to 11. Empty or 0 - without texture.", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "font_size",
						"heading" => __("Font size", 'blessing'),
						"description" => __("Font size of the text (default - in pixels, allows any CSS units of measure)", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "font_weight",
						"heading" => __("Font weight", 'blessing'),
						"description" => __("Font weight of the text", 'blessing'),
						"class" => "",
						"value" => array(
							__('Default', 'blessing') => 'inherit',
							__('Thin (100)', 'blessing') => '100',
							__('Light (300)', 'blessing') => '300',
							__('Normal (400)', 'blessing') => '400',
							__('Bold (700)', 'blessing') => '700'
						),
						"type" => "dropdown"
					),
//					array(
//						"param_name" => "content",
//						"heading" => __("Container content", 'blessing'),
//						"description" => __("Content for section container", 'blessing'),
//						"class" => "",
//						"value" => "",
//						"type" => "textarea_html"
//					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Block extends ANCORA_VC_ShortCodeCollection {}
			
			
			
			
			
			
			// Blogger
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_blogger",
				"name" => __("Blogger", 'blessing'),
				"description" => __("Insert posts (pages) in many styles from desired categories or directly from ids", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_blogger',
				"class" => "trx_sc_single trx_sc_blogger",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "style",
						"heading" => __("Output style", 'blessing'),
						"description" => __("Select desired style for posts output", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['blogger_styles']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "filters",
						"heading" => __("Show filters", 'blessing'),
						"description" => __("Use post's tags or categories as filter buttons", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['filters']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "hover",
						"heading" => __("Hover effect", 'blessing'),
						"description" => __("Select hover effect (only if style=Portfolio)", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['hovers']),
						'dependency' => array(
							'element' => 'style',
							'value' => array('portfolio_2','portfolio_3','portfolio_4','grid_2','grid_3','grid_4','square_2','square_3','square_4','courses_2','courses_3','courses_4')
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "hover_dir",
						"heading" => __("Hover direction", 'blessing'),
						"description" => __("Select hover direction (only if style=Portfolio and hover=Circle|Square)", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['hovers_dir']),
						'dependency' => array(
							'element' => 'style',
							'value' => array('portfolio_2','portfolio_3','portfolio_4','grid_2','grid_3','grid_4','square_2','square_3','square_4','courses_2','courses_3','courses_4')
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "location",
						"heading" => __("Dedicated content location", 'blessing'),
						"description" => __("Select position for dedicated content (only for style=excerpt)", 'blessing'),
						"class" => "",
						'dependency' => array(
							'element' => 'style',
							'value' => array('excerpt')
						),
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['locations']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "dir",
						"heading" => __("Posts direction", 'blessing'),
						"description" => __("Display posts in horizontal or vertical direction", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['dir']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "rating",
						"heading" => __("Show rating stars", 'blessing'),
						"description" => __("Show rating stars under post's header", 'blessing'),
						"group" => __('Details', 'blessing'),
						"class" => "",
						"value" => array(__('Show rating', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "info",
						"heading" => __("Show post info block", 'blessing'),
						"description" => __("Show post info block (author, date, tags, etc.)", 'blessing'),
						"class" => "",
						"value" => array(__('Show info', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "descr",
						"heading" => __("Description length", 'blessing'),
						"description" => __("How many characters are displayed from post excerpt? If 0 - don't show description", 'blessing'),
						"group" => __('Details', 'blessing'),
						"class" => "",
						"value" => 0,
						"type" => "textfield"
					),
					array(
						"param_name" => "links",
						"heading" => __("Allow links to the post", 'blessing'),
						"description" => __("Allow links to the post from each blogger item", 'blessing'),
						"group" => __('Details', 'blessing'),
						"class" => "",
						"value" => array(__('Allow links', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "readmore",
						"heading" => __("More link text", 'blessing'),
						"description" => __("Read more link text. If empty - show 'More', else - used as link text", 'blessing'),
						"group" => __('Details', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "post_type",
						"heading" => __("Post type", 'blessing'),
						"description" => __("Select post type to show", 'blessing'),
						"group" => __('Query', 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['posts_types']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "ids",
						"heading" => __("Post IDs list", 'blessing'),
						"description" => __("Comma separated list of posts ID. If set - parameters above are ignored!", 'blessing'),
						"group" => __('Query', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "cat",
						"heading" => __("Categories list", 'blessing'),
						"description" => __("Put here comma separated category slugs or ids. If empty - show posts from any category or from IDs list", 'blessing'),
						'dependency' => array(
							'element' => 'ids',
							'is_empty' => true
						),
						"group" => __('Query', 'blessing'),
						"class" => "",
						"value" => array_flip(ancora_array_merge(array(0 => __('- Select category -', 'blessing')), $ANCORA_GLOBALS['sc_params']['categories'])),
						"type" => "dropdown"
					),
					array(
						"param_name" => "count",
						"heading" => __("Total posts to show", 'blessing'),
						"description" => __("How many posts will be displayed? If used IDs - this parameter ignored.", 'blessing'),
						'dependency' => array(
							'element' => 'ids',
							'is_empty' => true
						),
						"admin_label" => true,
						"group" => __('Query', 'blessing'),
						"class" => "",
						"value" => 3,
						"type" => "textfield"
					),
					array(
						"param_name" => "columns",
						"heading" => __("Columns number", 'blessing'),
						"description" => __("How many columns used to display posts?", 'blessing'),
						'dependency' => array(
							'element' => 'dir',
							'value' => 'horizontal'
						),
						"group" => __('Query', 'blessing'),
						"class" => "",
						"value" => 3,
						"type" => "textfield"
					),
					array(
						"param_name" => "offset",
						"heading" => __("Offset before select posts", 'blessing'),
						"description" => __("Skip posts before select next part.", 'blessing'),
						'dependency' => array(
							'element' => 'ids',
							'is_empty' => true
						),
						"group" => __('Query', 'blessing'),
						"class" => "",
						"value" => 0,
						"type" => "textfield"
					),
					array(
						"param_name" => "orderby",
						"heading" => __("Post order by", 'blessing'),
						"description" => __("Select desired posts sorting method", 'blessing'),
						"class" => "",
						"group" => __('Query', 'blessing'),
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['sorting']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "order",
						"heading" => __("Post order", 'blessing'),
						"description" => __("Select desired posts order", 'blessing'),
						"class" => "",
						"group" => __('Query', 'blessing'),
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['ordering']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "only",
						"heading" => __("Select posts only", 'blessing'),
						"description" => __("Select posts only with reviews, videos, audios, thumbs or galleries", 'blessing'),
						"class" => "",
						"group" => __('Query', 'blessing'),
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['formats']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "scroll",
						"heading" => __("Use scroller", 'blessing'),
						"description" => __("Use scroller to show all posts", 'blessing'),
						"group" => __('Scroll', 'blessing'),
						"class" => "",
						"value" => array(__('Use scroller', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "controls",
						"heading" => __("Show slider controls", 'blessing'),
						"description" => __("Show arrows to control scroll slider", 'blessing'),
						"group" => __('Scroll', 'blessing'),
						"class" => "",
						"value" => array(__('Show controls', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
			) );
			
			class WPBakeryShortCode_Trx_Blogger extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			// Br
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_br",
				"name" => __("Line break", 'blessing'),
				"description" => __("Line break or Clear Floating", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_br',
				"class" => "trx_sc_single trx_sc_br",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "clear",
						"heading" => __("Clear floating", 'blessing'),
						"description" => __("Select clear side (if need)", 'blessing'),
						"class" => "",
						"value" => "",
						"value" => array(
							__('None', 'blessing') => 'none',
							__('Left', 'blessing') => 'left',
							__('Right', 'blessing') => 'right',
							__('Both', 'blessing') => 'both'
						),
						"type" => "dropdown"
					)
				)
			) );
			
			class WPBakeryShortCode_Trx_Br extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Button
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_button",
				"name" => __("Button", 'blessing'),
				"description" => __("Button with link", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_button',
				"class" => "trx_sc_single trx_sc_button",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "content",
						"heading" => __("Caption", 'blessing'),
						"description" => __("Button caption", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "type",
						"heading" => __("Button's shape", 'blessing'),
						"description" => __("Select button's shape", 'blessing'),
						"class" => "",
						"value" => array(
							__('Square', 'blessing') => 'square',
							__('Round', 'blessing') => 'round'
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "style",
						"heading" => __("Button's style", 'blessing'),
						"description" => __("Select button's style", 'blessing'),
						"class" => "",
						"value" => array(
                            __('Dark', 'blessing') => 'dark',
                            __('Light', 'blessing') => 'light',
                            __('Global', 'blessing') => 'global'
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "size",
						"heading" => __("Button's size", 'blessing'),
						"description" => __("Select button's size", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
							__('Small', 'blessing') => 'mini',
							__('Medium', 'blessing') => 'medium',
							__('Large', 'blessing') => 'big'
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "icon",
						"heading" => __("Button's icon", 'blessing'),
						"description" => __("Select icon for the title from Fontello icons set", 'blessing'),
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					array(
						"param_name" => "bg_style",
						"heading" => __("Button's color scheme", 'blessing'),
						"description" => __("Select button's color scheme", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['button_styles']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "color",
						"heading" => __("Button's text color", 'blessing'),
						"description" => __("Any color for button's caption", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_color",
						"heading" => __("Button's backcolor", 'blessing'),
						"description" => __("Any color for button's background", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "align",
						"heading" => __("Button's alignment", 'blessing'),
						"description" => __("Align button to left, center or right", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "link",
						"heading" => __("Link URL", 'blessing'),
						"description" => __("URL for the link on button click", 'blessing'),
						"class" => "",
						"group" => __('Link', 'blessing'),
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "target",
						"heading" => __("Link target", 'blessing'),
						"description" => __("Target for the link on button click", 'blessing'),
						"class" => "",
						"group" => __('Link', 'blessing'),
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "popup",
						"heading" => __("Open link in popup", 'blessing'),
						"description" => __("Open link target in popup window", 'blessing'),
						"class" => "",
						"group" => __('Link', 'blessing'),
						"value" => array(__('Open in popup', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "rel",
						"heading" => __("Rel attribute", 'blessing'),
						"description" => __("Rel attribute for the button's link (if need", 'blessing'),
						"class" => "",
						"group" => __('Link', 'blessing'),
						"value" => "",
						"type" => "textfield"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'js_view' => 'VcTrxTextView'
			) );
			
			class WPBakeryShortCode_Trx_Button extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Chat
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_chat",
				"name" => __("Chat", 'blessing'),
				"description" => __("Chat message", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_chat',
				"class" => "trx_sc_container trx_sc_chat",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "title",
						"heading" => __("Item title", 'blessing'),
						"description" => __("Title for current chat item", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "photo",
						"heading" => __("Item photo", 'blessing'),
						"description" => __("Select or upload image or write URL from other site for the item photo (avatar)", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "link",
						"heading" => __("Link URL", 'blessing'),
						"description" => __("URL for the link on chat title click", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
//					array(
//						"param_name" => "content",
//						"heading" => __("Chat item content", 'blessing'),
//						"description" => __("Current chat item content", 'blessing'),
//						"class" => "",
//						"value" => "",
//						"type" => "textarea_html"
//					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'js_view' => 'VcTrxTextContainerView'
			
			) );
			
			class WPBakeryShortCode_Trx_Chat extends ANCORA_VC_ShortCodeContainer {}
			
			
			
			
			
			
			// Columns
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_columns",
				"name" => __("Columns", 'blessing'),
				"description" => __("Insert columns with margins", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_columns',
				"class" => "trx_sc_columns",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => false,
				"as_parent" => array('only' => 'trx_column_item'),
				"params" => array(
					array(
						"param_name" => "count",
						"heading" => __("Columns count", 'blessing'),
						"description" => __("Number of the columns in the container.", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "2",
						"type" => "textfield"
					),
					array(
						"param_name" => "fluid",
						"heading" => __("Fluid columns", 'blessing'),
						"description" => __("To squeeze the columns when reducing the size of the window (fluid=yes) or to rebuild them (fluid=no)", 'blessing'),
						"class" => "",
						"value" => array(__('Fluid columns', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'default_content' => '
					[trx_column_item][/trx_column_item]
					[trx_column_item][/trx_column_item]
				',
				'js_view' => 'VcTrxColumnsView'
			) );
			
			
			vc_map( array(
				"base" => "trx_column_item",
				"name" => __("Column", 'blessing'),
				"description" => __("Column item", 'blessing'),
				"show_settings_on_create" => true,
				"class" => "trx_sc_collection trx_sc_column_item",
				"content_element" => true,
				"is_container" => true,
				'icon' => 'icon_trx_column_item',
				"as_child" => array('only' => 'trx_columns'),
				"as_parent" => array('except' => 'trx_columns'),
				"params" => array(
					array(
						"param_name" => "span",
						"heading" => __("Merge columns", 'blessing'),
						"description" => __("Count merged columns from current", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Alignment text in the column", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "color",
						"heading" => __("Fore color", 'blessing'),
						"description" => __("Any color for objects in this column", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_color",
						"heading" => __("Background color", 'blessing'),
						"description" => __("Any background color for this column", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_image",
						"heading" => __("URL for background image file", 'blessing'),
						"description" => __("Select or upload image or write URL from other site for the background", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
//					array(
//						"param_name" => "content",
//						"heading" => __("Column's content", 'blessing'),
//						"description" => __("Content of the current column", 'blessing'),
//						"class" => "",
//						"value" => "",
//						/*"holder" => "div",*/
//						"type" => "textarea_html"
//					),
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'js_view' => 'VcTrxColumnItemView'
			) );
			
			class WPBakeryShortCode_Trx_Columns extends ANCORA_VC_ShortCodeColumns {}
			class WPBakeryShortCode_Trx_Column_Item extends ANCORA_VC_ShortCodeCollection {}
			
			
			
			
			
			
			
			// Contact form
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_contact_form",
				"name" => __("Contact form", 'blessing'),
				"description" => __("Insert contact form", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_contact_form',
				"class" => "trx_sc_collection trx_sc_contact_form",
				"content_element" => true,
				"is_container" => true,
				"as_parent" => array('only' => 'trx_form_item'),
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "custom",
						"heading" => __("Custom", 'blessing'),
						"description" => __("Use custom fields or create standard contact form (ignore info from 'Field' tabs)", 'blessing'),
						"class" => "",
						"value" => array(__('Create custom form', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "action",
						"heading" => __("Action", 'blessing'),
						"description" => __("Contact form action (URL to handle form data). If empty - use internal action", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Select form alignment", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "title",
						"heading" => __("Title", 'blessing'),
						"description" => __("Title above contact form", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "description",
						"heading" => __("Description (under the title)", 'blessing'),
						"description" => __("Contact form description", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textarea_html"
					),
					ancora_vc_width(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			
			vc_map( array(
				"base" => "trx_form_item",
				"name" => __("Form item (custom field)", 'blessing'),
				"description" => __("Custom field for the contact form", 'blessing'),
				"class" => "trx_sc_item trx_sc_form_item",
				'icon' => 'icon_trx_form_item',
				"allowed_container_element" => 'vc_row',
				"show_settings_on_create" => true,
				"content_element" => true,
				"is_container" => false,
				"as_child" => array('only' => 'trx_contact_form'), // Use only|except attributes to limit parent (separate multiple values with comma)
				"params" => array(
					array(
						"param_name" => "type",
						"heading" => __("Type", 'blessing'),
						"description" => __("Select type of the custom field", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['field_types']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "name",
						"heading" => __("Name", 'blessing'),
						"description" => __("Name of the custom field", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "value",
						"heading" => __("Default value", 'blessing'),
						"description" => __("Default value of the custom field", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "label",
						"heading" => __("Label", 'blessing'),
						"description" => __("Label for the custom field", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "label_position",
						"heading" => __("Label position", 'blessing'),
						"description" => __("Label position relative to the field", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['label_positions']),
						"type" => "dropdown"
					),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Contact_Form extends ANCORA_VC_ShortCodeCollection {}
			class WPBakeryShortCode_Trx_Form_Item extends ANCORA_VC_ShortCodeItem {}
			
			
			
			
			
			
			
			// Content block on fullscreen page
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_content",
				"name" => __("Content block", 'blessing'),
				"description" => __("Container for main content block (use it only on fullscreen pages)", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_content',
				"class" => "trx_sc_collection trx_sc_content",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"params" => array(
//					array(
//						"param_name" => "content",
//						"heading" => __("Container content", 'blessing'),
//						"description" => __("Content for section container", 'blessing'),
//						"class" => "",
//						"value" => "",
//						/*"holder" => "div",*/
//						"type" => "textarea_html"
//					),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Content extends ANCORA_VC_ShortCodeCollection {}
			
			
			
			
			
			
			
			// Countdown
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_countdown",
				"name" => __("Countdown", 'blessing'),
				"description" => __("Insert countdown object", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_countdown',
				"class" => "trx_sc_single trx_sc_countdown",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "date",
						"heading" => __("Date", 'blessing'),
						"description" => __("Upcoming date (format: yyyy-mm-dd)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "time",
						"heading" => __("Time", 'blessing'),
						"description" => __("Upcoming time (format: HH:mm:ss)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "style",
						"heading" => __("Style", 'blessing'),
						"description" => __("Countdown style", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
							__('Style 1', 'blessing') => 1,
							__('Style 2', 'blessing') => 2
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Align counter to left, center or right", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Countdown extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Dropcaps
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_dropcaps",
				"name" => __("Dropcaps", 'blessing'),
				"description" => __("Make first letter of the text as dropcaps", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_dropcaps',
				"class" => "trx_sc_container trx_sc_dropcaps",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "style",
						"heading" => __("Style", 'blessing'),
						"description" => __("Dropcaps style", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
							__('Style 1', 'blessing') => 1,
							__('Style 2', 'blessing') => 2,
							__('Style 3', 'blessing') => 3,
							__('Style 4', 'blessing') => 4
						),
						"type" => "dropdown"
					),
//					array(
//						"param_name" => "content",
//						"heading" => __("Paragraph text", 'blessing'),
//						"description" => __("Paragraph with dropcaps content", 'blessing'),
//						"class" => "",
//						"value" => "",
//						"type" => "textarea_html"
//					),
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'js_view' => 'VcTrxTextContainerView'
			
			) );
			
			class WPBakeryShortCode_Trx_Dropcaps extends ANCORA_VC_ShortCodeContainer {}
			
			
			
			
			
			
			
			// Emailer
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_emailer",
				"name" => __("E-mail collector", 'blessing'),
				"description" => __("Collect e-mails into specified group", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_emailer',
				"class" => "trx_sc_single trx_sc_emailer",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "group",
						"heading" => __("Group", 'blessing'),
						"description" => __("The name of group to collect e-mail address", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "open",
						"heading" => __("Opened", 'blessing'),
						"description" => __("Initially open the input field on show object", 'blessing'),
						"class" => "",
						"value" => array(__('Initially opened', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Align field to left, center or right", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Emailer extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Gap
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_gap",
				"name" => __("Gap", 'blessing'),
				"description" => __("Insert gap (fullwidth area) in the post content", 'blessing'),
				"category" => __('Structure', 'blessing'),
				'icon' => 'icon_trx_gap',
				"class" => "trx_sc_collection trx_sc_gap",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => false,
				"params" => array(
//					array(
//						"param_name" => "content",
//						"heading" => __("Gap content", 'blessing'),
//						"description" => __("Gap inner content", 'blessing'),
//						"class" => "",
//						"value" => "",
//						/*"holder" => "div",*/
//						"type" => "textarea_html"
//					)
				)
			) );
			
			class WPBakeryShortCode_Trx_Gap extends ANCORA_VC_ShortCodeCollection {}
			
			
			
			
			
			
			
			// Googlemap
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_googlemap",
				"name" => __("Google map", 'blessing'),
				"description" => __("Insert Google map with desired address or coordinates", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_googlemap',
				"class" => "trx_sc_single trx_sc_googlemap",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "address",
						"heading" => __("Address", 'blessing'),
						"description" => __("Address to show in map center", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "latlng",
						"heading" => __("Latitude and Longtitude", 'blessing'),
						"description" => __("Comma separated map center coorditanes (instead Address)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
                    array(
                        "param_name" => "description",
                        "heading" => __("Description", 'blessing'),
                        "description" => __("Description", 'blessing'),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    ),
					array(
						"param_name" => "zoom",
						"heading" => __("Zoom", 'blessing'),
						"description" => __("Map zoom factor", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "16",
						"type" => "textfield"
					),
					array(
						"param_name" => "style",
						"heading" => __("Style", 'blessing'),
						"description" => __("Map custom style", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['googlemap_styles']),
						"type" => "dropdown"
					),
					ancora_vc_width('100%'),
					ancora_vc_height(240),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Googlemap extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Highlight
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_highlight",
				"name" => __("Highlight text", 'blessing'),
				"description" => __("Highlight text with selected color, background color and other styles", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_highlight',
				"class" => "trx_sc_container trx_sc_highlight",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "type",
						"heading" => __("Type", 'blessing'),
						"description" => __("Highlight type", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
								__('Custom', 'blessing') => 0,
								__('Type 1', 'blessing') => 1,
								__('Type 2', 'blessing') => 2,
								__('Type 3', 'blessing') => 3
							),
						"type" => "dropdown"
					),
					array(
						"param_name" => "color",
						"heading" => __("Text color", 'blessing'),
						"description" => __("Color for the highlighted text", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_color",
						"heading" => __("Background color", 'blessing'),
						"description" => __("Background color for the highlighted text", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "font_size",
						"heading" => __("Font size", 'blessing'),
						"description" => __("Font size for the highlighted text (default - in pixels, allows any CSS units of measure)", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "content",
						"heading" => __("Highlight text", 'blessing'),
						"description" => __("Content for highlight", 'blessing'),
						"class" => "",
						"value" => "",
						/*"holder" => "div",*/
						"type" => "textarea_html"
					),
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'js_view' => 'VcTrxTextContainerView'
			) );
			
			class WPBakeryShortCode_Trx_Highlight extends ANCORA_VC_ShortCodeContainer {}
			
			
			
			
			
			
			// Icon
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_icon",
				"name" => __("Icon", 'blessing'),
				"description" => __("Insert the icon", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_icon',
				"class" => "trx_sc_single trx_sc_icon",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "icon",
						"heading" => __("Icon", 'blessing'),
						"description" => __("Select icon class from Fontello icons set", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					array(
						"param_name" => "color",
						"heading" => __("Text color", 'blessing'),
						"description" => __("Icon's color", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_color",
						"heading" => __("Background color", 'blessing'),
						"description" => __("Background color for the icon", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_shape",
						"heading" => __("Background shape", 'blessing'),
						"description" => __("Shape of the icon background", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
							__('None', 'blessing') => 'none',
							__('Round', 'blessing') => 'round',
							__('Square', 'blessing') => 'square'
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "bg_style",
						"heading" => __("Icon's color scheme", 'blessing'),
						"description" => __("Select icon's color scheme", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['button_styles']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "font_size",
						"heading" => __("Font size", 'blessing'),
						"description" => __("Icon's font size", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "font_weight",
						"heading" => __("Font weight", 'blessing'),
						"description" => __("Icon's font weight", 'blessing'),
						"class" => "",
						"value" => array(
							__('Default', 'blessing') => 'inherit',
							__('Thin (100)', 'blessing') => '100',
							__('Light (300)', 'blessing') => '300',
							__('Normal (400)', 'blessing') => '400',
							__('Bold (700)', 'blessing') => '700'
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "align",
						"heading" => __("Icon's alignment", 'blessing'),
						"description" => __("Align icon to left, center or right", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "link",
						"heading" => __("Link URL", 'blessing'),
						"description" => __("Link URL from this icon (if not empty)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
			) );
			
			class WPBakeryShortCode_Trx_Icon extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Image
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_image",
				"name" => __("Image", 'blessing'),
				"description" => __("Insert image", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_image',
				"class" => "trx_sc_single trx_sc_image",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "url",
						"heading" => __("Select image", 'blessing'),
						"description" => __("Select image from library", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "align",
						"heading" => __("Image alignment", 'blessing'),
						"description" => __("Align image to left or right side", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['float']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "shape",
						"heading" => __("Image shape", 'blessing'),
						"description" => __("Shape of the image: square or round", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
							__('Square', 'blessing') => 'square',
							__('Round', 'blessing') => 'round'
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "title",
						"heading" => __("Title", 'blessing'),
						"description" => __("Image's title", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "icon",
						"heading" => __("Title's icon", 'blessing'),
						"description" => __("Select icon for the title from Fontello icons set", 'blessing'),
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Image extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Infobox
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_infobox",
				"name" => __("Infobox", 'blessing'),
				"description" => __("Box with info or error message", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_infobox',
				"class" => "trx_sc_container trx_sc_infobox",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "style",
						"heading" => __("Style", 'blessing'),
						"description" => __("Infobox style", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
								__('Regular', 'blessing') => 'regular',
								__('Info', 'blessing') => 'info',
								__('Success', 'blessing') => 'success',
								__('Error', 'blessing') => 'error',
								__('Warning', 'blessing') => 'warning',
							),
						"type" => "dropdown"
					),
					array(
						"param_name" => "closeable",
						"heading" => __("Closeable", 'blessing'),
						"description" => __("Create closeable box (with close button)", 'blessing'),
						"class" => "",
						"value" => array(__('Close button', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "icon",
						"heading" => __("Custom icon", 'blessing'),
						"description" => __("Select icon for the infobox from Fontello icons set. If empty - use default icon", 'blessing'),
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					array(
						"param_name" => "color",
						"heading" => __("Text color", 'blessing'),
						"description" => __("Any color for the text and headers", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_color",
						"heading" => __("Background color", 'blessing'),
						"description" => __("Any background color for this infobox", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
//					array(
//						"param_name" => "content",
//						"heading" => __("Message text", 'blessing'),
//						"description" => __("Message for the infobox", 'blessing'),
//						"class" => "",
//						"value" => "",
//						"type" => "textarea_html"
//					),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'js_view' => 'VcTrxTextContainerView'
			) );
			
			class WPBakeryShortCode_Trx_Infobox extends ANCORA_VC_ShortCodeContainer {}
			
			
			
			
			
			
			
			// Line
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_line",
				"name" => __("Line", 'blessing'),
				"description" => __("Insert line (delimiter)", 'blessing'),
				"category" => __('Content', 'blessing'),
				"class" => "trx_sc_single trx_sc_line",
				'icon' => 'icon_trx_line',
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "style",
						"heading" => __("Style", 'blessing'),
						"description" => __("Line style", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
								__('Solid', 'blessing') => 'solid',
								__('Dashed', 'blessing') => 'dashed',
								__('Dotted', 'blessing') => 'dotted',
								__('Double', 'blessing') => 'double',
								__('Shadow', 'blessing') => 'shadow'
							),
						"type" => "dropdown"
					),
					array(
						"param_name" => "color",
						"heading" => __("Line color", 'blessing'),
						"description" => __("Line color", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Line extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// List
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_list",
				"name" => __("List", 'blessing'),
				"description" => __("List items with specific bullets", 'blessing'),
				"category" => __('Content', 'blessing'),
				"class" => "trx_sc_collection trx_sc_list",
				'icon' => 'icon_trx_list',
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => false,
				"as_parent" => array('only' => 'trx_list_item'),
				"params" => array(
					array(
						"param_name" => "style",
						"heading" => __("Bullet's style", 'blessing'),
						"description" => __("Bullet's style for each list item", 'blessing'),
						"class" => "",
						"admin_label" => true,
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['list_styles']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "color",
						"heading" => __("Color", 'blessing'),
						"description" => __("List items color", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "icon",
						"heading" => __("List icon", 'blessing'),
						"description" => __("Select list icon from Fontello icons set (only for style=Iconed)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						'dependency' => array(
							'element' => 'style',
							'value' => array('iconed')
						),
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					array(
						"param_name" => "icon_color",
						"heading" => __("Icon color", 'blessing'),
						"description" => __("List icons color", 'blessing'),
						"class" => "",
						'dependency' => array(
							'element' => 'style',
							'value' => array('iconed')
						),
						"value" => "",
						"type" => "colorpicker"
					),
                    array(
                        "param_name" => "boxed_icon",
                        "heading" => __("Boxed Icon", 'blessing'),
                        "description" => __("Create border around icon", 'blessing'),
                        "class" => "",
                        "value" => array('No' => '', 'Yes' => 'boxed_icon'),
                        "type" => "dropdown"
                    ),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'default_content' => '
					[trx_list_item]' . __( 'Item 1', 'blessing' ) . '[/trx_list_item]
					[trx_list_item]' . __( 'Item 2', 'blessing' ) . '[/trx_list_item]
				'
			) );
			
			
			vc_map( array(
				"base" => "trx_list_item",
				"name" => __("List item", 'blessing'),
				"description" => __("List item with specific bullet", 'blessing'),
				"class" => "trx_sc_single trx_sc_list_item",
				"show_settings_on_create" => true,
				"content_element" => true,
				"is_container" => false,
				'icon' => 'icon_trx_list_item',
				"as_child" => array('only' => 'trx_list'), // Use only|except attributes to limit parent (separate multiple values with comma)
				"as_parent" => array('except' => 'trx_list'),
				"params" => array(
					array(
						"param_name" => "title",
						"heading" => __("List item title", 'blessing'),
						"description" => __("Title for the current list item (show it as tooltip)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "link",
						"heading" => __("Link URL", 'blessing'),
						"description" => __("Link URL for the current list item", 'blessing'),
						"admin_label" => true,
						"group" => __('Link', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "target",
						"heading" => __("Link target", 'blessing'),
						"description" => __("Link target for the current list item", 'blessing'),
						"admin_label" => true,
						"group" => __('Link', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "color",
						"heading" => __("Color", 'blessing'),
						"description" => __("Text color for this item", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "icon",
						"heading" => __("List item icon", 'blessing'),
						"description" => __("Select list item icon from Fontello icons set (only for style=Iconed)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					array(
						"param_name" => "icon_color",
						"heading" => __("Icon color", 'blessing'),
						"description" => __("Icon color for this item", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
//					array(
//						"param_name" => "content",
//						"heading" => __("List item text", 'blessing'),
//						"description" => __("Current list item content", 'blessing'),
//						"class" => "",
//						"value" => "",
//						"type" => "textarea_html"
//					),
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'js_view' => 'VcTrxTextView'
			
			) );
			
			class WPBakeryShortCode_Trx_List extends ANCORA_VC_ShortCodeCollection {}
			class WPBakeryShortCode_Trx_List_Item extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			
			
			// Number
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_number",
				"name" => __("Number", 'blessing'),
				"description" => __("Insert number or any word as set of separated characters", 'blessing'),
				"category" => __('Content', 'blessing'),
				"class" => "trx_sc_single trx_sc_number",
				'icon' => 'icon_trx_number',
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "value",
						"heading" => __("Value", 'blessing'),
						"description" => __("Number or any word to separate", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Select block alignment", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Number extends ANCORA_VC_ShortCodeSingle {}


			
			
			
			
			
			// Parallax
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_parallax",
				"name" => __("Parallax", 'blessing'),
				"description" => __("Create the parallax container (with asinc background image)", 'blessing'),
				"category" => __('Structure', 'blessing'),
				'icon' => 'icon_trx_parallax',
				"class" => "trx_sc_collection trx_sc_parallax",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "gap",
						"heading" => __("Create gap", 'blessing'),
						"description" => __("Create gap around parallax container (not need in fullscreen pages)", 'blessing'),
						"class" => "",
						"value" => array(__('Create gap', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "dir",
						"heading" => __("Direction", 'blessing'),
						"description" => __("Scroll direction for the parallax background", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
								__('Up', 'blessing') => 'up',
								__('Down', 'blessing') => 'down'
							),
						"type" => "dropdown"
					),
					array(
						"param_name" => "speed",
						"heading" => __("Speed", 'blessing'),
						"description" => __("Parallax background motion speed (from 0.0 to 1.0)", 'blessing'),
						"class" => "",
						"value" => "0.3",
						"type" => "textfield"
					),
					array(
						"param_name" => "color",
						"heading" => __("Text color", 'blessing'),
						"description" => __("Select color for text object inside parallax block", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_tint",
						"heading" => __("Bg tint", 'blessing'),
						"description" => __("Select tint of the parallax background (for correct font color choise)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
								__('Light', 'blessing') => 'light',
								__('Dark', 'blessing') => 'dark'
							),
						"type" => "dropdown"
					),
					array(
						"param_name" => "bg_color",
						"heading" => __("Backgroud color", 'blessing'),
						"description" => __("Select color for parallax background", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_image",
						"heading" => __("Background image", 'blessing'),
						"description" => __("Select or upload image or write URL from other site for the parallax background", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "bg_image_x",
						"heading" => __("Image X position", 'blessing'),
						"description" => __("Parallax background X position (in percents)", 'blessing'),
						"class" => "",
						"value" => "50%",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_video",
						"heading" => __("Video background", 'blessing'),
						"description" => __("Paste URL for video file to show it as parallax background", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_video_ratio",
						"heading" => __("Video ratio", 'blessing'),
						"description" => __("Specify ratio of the video background. For example: 16:9 (default), 4:3, etc.", 'blessing'),
						"class" => "",
						"value" => "16:9",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_overlay",
						"heading" => __("Overlay", 'blessing'),
						"description" => __("Overlay color opacity (from 0.0 to 1.0)", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_texture",
						"heading" => __("Texture", 'blessing'),
						"description" => __("Texture style from 1 to 11. Empty or 0 - without texture.", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
//					array(
//						"param_name" => "content",
//						"heading" => __("Content", 'blessing'),
//						"description" => __("Content for the parallax container", 'blessing'),
//						"class" => "",
//						"value" => "",
//						"type" => "textarea_html"
//					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Parallax extends ANCORA_VC_ShortCodeCollection {}
			
			
			
			
			
			
			// Popup
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_popup",
				"name" => __("Popup window", 'blessing'),
				"description" => __("Container for any html-block with desired class and style for popup window", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_popup',
				"class" => "trx_sc_collection trx_sc_popup",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"params" => array(
//					array(
//						"param_name" => "content",
//						"heading" => __("Container content", 'blessing'),
//						"description" => __("Content for popup container", 'blessing'),
//						"class" => "",
//						"value" => "",
//						/*"holder" => "div",*/
//						"type" => "textarea_html"
//					),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Popup extends ANCORA_VC_ShortCodeCollection {}
			
			
			
			
			
			
			
			// Price
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_price",
				"name" => __("Price", 'blessing'),
				"description" => __("Insert price with decoration", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_price',
				"class" => "trx_sc_single trx_sc_price",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "money",
						"heading" => __("Money", 'blessing'),
						"description" => __("Money value (dot or comma separated)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "currency",
						"heading" => __("Currency symbol", 'blessing'),
						"description" => __("Currency character", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "$",
						"type" => "textfield"
					),
					array(
						"param_name" => "period",
						"heading" => __("Period", 'blessing'),
						"description" => __("Period text (if need). For example: monthly, daily, etc.", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Align price to left or right side", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['float']),
						"type" => "dropdown"
					),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Price extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Price block
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_price_block",
				"name" => __("Price block", 'blessing'),
				"description" => __("Insert price block with title, price and description", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_price_block',
				"class" => "trx_sc_single trx_sc_price_block",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "title",
						"heading" => __("Title", 'blessing'),
						"description" => __("Block title", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "link",
						"heading" => __("Link URL", 'blessing'),
						"description" => __("URL for link from button (at bottom of the block)", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "link_text",
						"heading" => __("Link text", 'blessing'),
						"description" => __("Text (caption) for the link button (at bottom of the block). If empty - button not showed", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "icon",
						"heading" => __("Icon", 'blessing'),
						"description" => __("Select icon from Fontello icons set (placed before/instead price)", 'blessing'),
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					array(
						"param_name" => "money",
						"heading" => __("Money", 'blessing'),
						"description" => __("Money value (dot or comma separated)", 'blessing'),
						"admin_label" => true,
						"group" => __('Money', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "currency",
						"heading" => __("Currency symbol", 'blessing'),
						"description" => __("Currency character", 'blessing'),
						"admin_label" => true,
						"group" => __('Money', 'blessing'),
						"class" => "",
						"value" => "$",
						"type" => "textfield"
					),
					array(
						"param_name" => "period",
						"heading" => __("Period", 'blessing'),
						"description" => __("Period text (if need). For example: monthly, daily, etc.", 'blessing'),
						"admin_label" => true,
						"group" => __('Money', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Align price to left or right side", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['float']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "content",
						"heading" => __("Description", 'blessing'),
						"description" => __("Description for this price block", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textarea_html"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'js_view' => 'VcTrxTextView'
			) );
			
			class WPBakeryShortCode_Trx_PriceBlock extends ANCORA_VC_ShortCodeSingle {}

			
			
			
			
			// Quote
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_quote",
				"name" => __("Quote", 'blessing'),
				"description" => __("Quote text", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_quote',
				"class" => "trx_sc_container trx_sc_quote",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"params" => array(
                    array(
                        "param_name" => "style",
                        "heading" => __("Style", 'blessing'),
                        "description" => __("Quote style", 'blessing'),
                        "class" => "",
                        "value" => array( 'Dark' => '1', 'White' => '2'),
                        "type" => "dropdown"
                    ),
					array(
						"param_name" => "cite",
						"heading" => __("Quote cite", 'blessing'),
						"description" => __("URL for the quote cite link", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "title",
						"heading" => __("Title (author)", 'blessing'),
						"description" => __("Quote title (author name)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "content",
						"heading" => __("Quote content", 'blessing'),
						"description" => __("Quote content", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textarea_html"
					),
					ancora_vc_width(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'js_view' => 'VcTrxTextContainerView'
			) );
			
			class WPBakeryShortCode_Trx_Quote extends ANCORA_VC_ShortCodeContainer {}
			
			
			
			
			
			
			
			// Reviews
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_reviews",
				"name" => __("Reviews", 'blessing'),
				"description" => __("Insert reviews block in the single post", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_reviews',
				"class" => "trx_sc_single trx_sc_reviews",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Align counter to left, center or right", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Reviews extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Search
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_search",
				"name" => __("Search form", 'blessing'),
				"description" => __("Insert search form", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_search',
				"class" => "trx_sc_single trx_sc_search",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "style",
						"heading" => __("Style", 'blessing'),
						"description" => __("Select style to display search field", 'blessing'),
						"class" => "",
						"value" => array(
							__('Regular', 'blessing') => "regular",
							__('Flat', 'blessing') => "flat"
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "title",
						"heading" => __("Title", 'blessing'),
						"description" => __("Title (placeholder) for the search field", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => __("Search &hellip;", 'blessing'),
						"type" => "textfield"
					),
					array(
						"param_name" => "ajax",
						"heading" => __("AJAX", 'blessing'),
						"description" => __("Search via AJAX or reload page", 'blessing'),
						"class" => "",
						"value" => array(__('Use AJAX search', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Search extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Section
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_section",
				"name" => __("Section container", 'blessing'),
				"description" => __("Container for any block ([block] analog - to enable nesting)", 'blessing'),
				"category" => __('Content', 'blessing'),
				"class" => "trx_sc_collection trx_sc_section",
				'icon' => 'icon_trx_block',
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "dedicated",
						"heading" => __("Dedicated", 'blessing'),
						"description" => __("Use this block as dedicated content - show it before post title on single page", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(__('Use as dedicated content', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Select block alignment", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "columns",
						"heading" => __("Columns emulation", 'blessing'),
						"description" => __("Select width for columns emulation", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['columns']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "pan",
						"heading" => __("Use pan effect", 'blessing'),
						"description" => __("Use pan effect to show section content", 'blessing'),
						"group" => __('Scroll', 'blessing'),
						"class" => "",
						"value" => array(__('Content scroller', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "scroll",
						"heading" => __("Use scroller", 'blessing'),
						"description" => __("Use scroller to show section content", 'blessing'),
						"group" => __('Scroll', 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(__('Content scroller', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "scroll_dir",
						"heading" => __("Scroll and Pan direction", 'blessing'),
						"description" => __("Scroll and Pan direction (if Use scroller = yes or Pan = yes)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"group" => __('Scroll', 'blessing'),
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['dir']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "scroll_controls",
						"heading" => __("Scroll controls", 'blessing'),
						"description" => __("Show scroll controls (if Use scroller = yes)", 'blessing'),
						"class" => "",
						"group" => __('Scroll', 'blessing'),
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['dir']),
						'dependency' => array(
							'element' => 'scroll',
							'not_empty' => true
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "color",
						"heading" => __("Fore color", 'blessing'),
						"description" => __("Any color for objects in this section", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_tint",
						"heading" => __("Background tint", 'blessing'),
						"description" => __("Main background tint: dark or light", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['tint']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "bg_color",
						"heading" => __("Background color", 'blessing'),
						"description" => __("Any background color for this section", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_image",
						"heading" => __("Background image URL", 'blessing'),
						"description" => __("Select background image from library for this section", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "bg_overlay",
						"heading" => __("Overlay", 'blessing'),
						"description" => __("Overlay color opacity (from 0.0 to 1.0)", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_texture",
						"heading" => __("Texture", 'blessing'),
						"description" => __("Texture style from 1 to 11. Empty or 0 - without texture.", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "font_size",
						"heading" => __("Font size", 'blessing'),
						"description" => __("Font size of the text (default - in pixels, allows any CSS units of measure)", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "font_weight",
						"heading" => __("Font weight", 'blessing'),
						"description" => __("Font weight of the text", 'blessing'),
						"class" => "",
						"value" => array(
							__('Default', 'blessing') => 'inherit',
							__('Thin (100)', 'blessing') => '100',
							__('Light (300)', 'blessing') => '300',
							__('Normal (400)', 'blessing') => '400',
							__('Bold (700)', 'blessing') => '700'
						),
						"type" => "dropdown"
					),
//					array(
//						"param_name" => "content",
//						"heading" => __("Container content", 'blessing'),
//						"description" => __("Content for section container", 'blessing'),
//						"class" => "",
//						"value" => "",
//						"type" => "textarea_html"
//					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Section extends ANCORA_VC_ShortCodeCollection {}
			
			
			
			
			
			
			
			// Skills
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_skills",
				"name" => __("Skills", 'blessing'),
				"description" => __("Insert skills diagramm", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_skills',
				"class" => "trx_sc_collection trx_sc_skills",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"as_parent" => array('only' => 'trx_skills_item'),
				"params" => array(
					array(
						"param_name" => "max_value",
						"heading" => __("Max value", 'blessing'),
						"description" => __("Max value for skills items", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "100",
						"type" => "textfield"
					),
					array(
						"param_name" => "type",
						"heading" => __("Skills type", 'blessing'),
						"description" => __("Select type of skills block", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
							__('Bar', 'blessing') => 'bar',
							__('Pie chart', 'blessing') => 'pie',
							__('Counter', 'blessing') => 'counter',
							__('Arc', 'blessing') => 'arc'
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "layout",
						"heading" => __("Skills layout", 'blessing'),
						"description" => __("Select layout of skills block", 'blessing'),
						"admin_label" => true,
						'dependency' => array(
							'element' => 'type',
							'value' => array('counter','bar','pie')
						),
						"class" => "",
						"value" => array(
							__('Rows', 'blessing') => 'rows',
							__('Columns', 'blessing') => 'columns'
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "dir",
						"heading" => __("Direction", 'blessing'),
						"description" => __("Select direction of skills block", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['dir']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "style",
						"heading" => __("Counters style", 'blessing'),
						"description" => __("Select style of skills items (only for type=counter)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
							__('Style 1', 'blessing') => '1',
							__('Style 2', 'blessing') => '2',
							__('Style 3', 'blessing') => '3',
							__('Style 4', 'blessing') => '4'
						),
						'dependency' => array(
							'element' => 'type',
							'value' => array('counter')
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "columns",
						"heading" => __("Columns count", 'blessing'),
						"description" => __("Skills columns count (required)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "2",
						"type" => "textfield"
					),
					array(
						"param_name" => "color",
						"heading" => __("Color", 'blessing'),
						"description" => __("Color for all skills items", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_color",
						"heading" => __("Background color", 'blessing'),
						"description" => __("Background color for all skills items (only for type=pie)", 'blessing'),
						'dependency' => array(
							'element' => 'type',
							'value' => array('pie')
						),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "border_color",
						"heading" => __("Border color", 'blessing'),
						"description" => __("Border color for all skills items (only for type=pie)", 'blessing'),
						'dependency' => array(
							'element' => 'type',
							'value' => array('pie')
						),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "title",
						"heading" => __("Title", 'blessing'),
						"description" => __("Title of the skills block", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "subtitle",
						"heading" => __("Subtitle", 'blessing'),
						"description" => __("Default subtitle of the skills block (only if type=arc)", 'blessing'),
						'dependency' => array(
							'element' => 'type',
							'value' => array('arc')
						),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Align skills block to left or right side", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['float']),
						"type" => "dropdown"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			
			vc_map( array(
				"base" => "trx_skills_item",
				"name" => __("Skill", 'blessing'),
				"description" => __("Skills item", 'blessing'),
				"show_settings_on_create" => true,
				"class" => "trx_sc_single trx_sc_skills_item",
				"content_element" => true,
				"is_container" => false,
				"as_child" => array('only' => 'trx_skills'),
				"as_parent" => array('except' => 'trx_skills'),
				"params" => array(
					array(
						"param_name" => "title",
						"heading" => __("Title", 'blessing'),
						"description" => __("Title for the current skills item", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "value",
						"heading" => __("Value", 'blessing'),
						"description" => __("Value for the current skills item", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "50",
						"type" => "textfield"
					),
					array(
						"param_name" => "color",
						"heading" => __("Color", 'blessing'),
						"description" => __("Color for current skills item", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_color",
						"heading" => __("Background color", 'blessing'),
						"description" => __("Background color for current skills item (only for type=pie)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "border_color",
						"heading" => __("Border color", 'blessing'),
						"description" => __("Border color for current skills item (only for type=pie)", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "style",
						"heading" => __("Item style", 'blessing'),
						"description" => __("Select style for the current skills item (only for type=counter)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
							__('Style 1', 'blessing') => '1',
							__('Style 2', 'blessing') => '2',
							__('Style 3', 'blessing') => '3',
							__('Style 4', 'blessing') => '4'
						),
						"type" => "dropdown"
					),
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Skills extends ANCORA_VC_ShortCodeCollection {}
			class WPBakeryShortCode_Trx_Skills_Item extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Slider
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_slider",
				"name" => __("Slider", 'blessing'),
				"description" => __("Insert slider", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_slider',
				"class" => "trx_sc_collection trx_sc_slider",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"as_parent" => array('only' => 'trx_slider_item'),
				"params" => array_merge(array(
					array(
						"param_name" => "engine",
						"heading" => __("Engine", 'blessing'),
						"description" => __("Select engine for slider. Attention! Swiper is built-in engine, all other engines appears only if corresponding plugings are installed", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['sliders']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "align",
						"heading" => __("Float slider", 'blessing'),
						"description" => __("Float slider to left or right side", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['float']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "custom",
						"heading" => __("Custom slides", 'blessing'),
						"description" => __("Make custom slides from inner shortcodes (prepare it on tabs) or prepare slides from posts thumbnails", 'blessing'),
						"class" => "",
						"value" => array(__('Custom slides', 'blessing') => 'yes'),
						"type" => "checkbox"
					)
					),
					ancora_exists_revslider() ? array(
					array(
						"param_name" => "alias",
						"heading" => __("Revolution slider alias", 'blessing'),
						"description" => __("Alias for Revolution slider", 'blessing'),
						"admin_label" => true,
						"class" => "",
						'dependency' => array(
							'element' => 'engine',
							'value' => array('revo','royal')
						),
						"value" => "",
						"type" => "textfield"
					)) : array(), array(
					array(
						"param_name" => "cat",
						"heading" => __("Categories list", 'blessing'),
						"description" => __("Select category. If empty - show posts from any category or from IDs list", 'blessing'),
						'dependency' => array(
							'element' => 'engine',
							'value' => array('swiper')
						),
						"class" => "",
						"value" => array_flip(ancora_array_merge(array(0 => __('- Select category -', 'blessing')), $ANCORA_GLOBALS['sc_params']['categories'])),
						"type" => "dropdown"
					),
					array(
						"param_name" => "count",
						"heading" => __("Swiper: Number of posts", 'blessing'),
						"description" => __("How many posts will be displayed? If used IDs - this parameter ignored.", 'blessing'),
						'dependency' => array(
							'element' => 'engine',
							'value' => array('swiper')
						),
						"class" => "",
						"value" => "3",
						"type" => "textfield"
					),
					array(
						"param_name" => "offset",
						"heading" => __("Swiper: Offset before select posts", 'blessing'),
						"description" => __("Skip posts before select next part.", 'blessing'),
						'dependency' => array(
							'element' => 'engine',
							'value' => array('swiper')
						),
						"class" => "",
						"value" => "0",
						"type" => "textfield"
					),
					array(
						"param_name" => "orderby",
						"heading" => __("Swiper: Post sorting", 'blessing'),
						"description" => __("Select desired posts sorting method", 'blessing'),
						'dependency' => array(
							'element' => 'engine',
							'value' => array('swiper')
						),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['sorting']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "order",
						"heading" => __("Swiper: Post order", 'blessing'),
						"description" => __("Select desired posts order", 'blessing'),
						'dependency' => array(
							'element' => 'engine',
							'value' => array('swiper')
						),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['ordering']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "ids",
						"heading" => __("Swiper: Post IDs list", 'blessing'),
						"description" => __("Comma separated list of posts ID. If set - parameters above are ignored!", 'blessing'),
						'dependency' => array(
							'element' => 'engine',
							'value' => array('swiper')
						),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "controls",
						"heading" => __("Swiper: Show slider controls", 'blessing'),
						"description" => __("Show arrows inside slider", 'blessing'),
						'dependency' => array(
							'element' => 'engine',
							'value' => array('swiper')
						),
						"class" => "",
						"value" => array(__('Show controls', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "pagination",
						"heading" => __("Swiper: Show slider pagination", 'blessing'),
						"description" => __("Show bullets or titles to switch slides", 'blessing'),
						"group" => __('Details', 'blessing'),
						'dependency' => array(
							'element' => 'engine',
							'value' => array('swiper')
						),
						"class" => "",
						"value" => array(
								__('Dots', 'blessing') => 'yes',
								__('Side Titles', 'blessing') => 'full',
								__('Over Titles', 'blessing') => 'over',
								__('None', 'blessing') => 'no'
							),
						"type" => "dropdown"
					),
					array(
						"param_name" => "titles",
						"heading" => __("Swiper: Show titles section", 'blessing'),
						"description" => __("Show section with post's title and short post's description", 'blessing'),
						"group" => __('Details', 'blessing'),
						'dependency' => array(
							'element' => 'engine',
							'value' => array('swiper')
						),
						"class" => "",
						"value" => array(
								__('Not show', 'blessing') => "no",
								__('Show/Hide info', 'blessing') => "slide",
								__('Fixed info', 'blessing') => "fixed"
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "descriptions",
						"heading" => __("Swiper: Post descriptions", 'blessing'),
						"description" => __("Show post's excerpt max length (characters)", 'blessing'),
						"group" => __('Details', 'blessing'),
						'dependency' => array(
							'element' => 'engine',
							'value' => array('swiper')
						),
						"class" => "",
						"value" => "0",
						"type" => "textfield"
					),
					array(
						"param_name" => "links",
						"heading" => __("Swiper: Post's title as link", 'blessing'),
						"description" => __("Make links from post's titles", 'blessing'),
						"group" => __('Details', 'blessing'),
						'dependency' => array(
							'element' => 'engine',
							'value' => array('swiper')
						),
						"class" => "",
						"value" => array(__('Titles as a links', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "crop",
						"heading" => __("Swiper: Crop images", 'blessing'),
						"description" => __("Crop images in each slide or live it unchanged", 'blessing'),
						"group" => __('Details', 'blessing'),
						'dependency' => array(
							'element' => 'engine',
							'value' => array('swiper')
						),
						"class" => "",
						"value" => array(__('Crop images', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "autoheight",
						"heading" => __("Swiper: Autoheight", 'blessing'),
						"description" => __("Change whole slider's height (make it equal current slide's height)", 'blessing'),
						"group" => __('Details', 'blessing'),
						'dependency' => array(
							'element' => 'engine',
							'value' => array('swiper')
						),
						"class" => "",
						"value" => array(__('Autoheight', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					array(
						"param_name" => "interval",
						"heading" => __("Swiper: Slides change interval", 'blessing'),
						"description" => __("Slides change interval (in milliseconds: 1000ms = 1s)", 'blessing'),
						"group" => __('Details', 'blessing'),
						'dependency' => array(
							'element' => 'engine',
							'value' => array('swiper')
						),
						"class" => "",
						"value" => "5000",
						"type" => "textfield"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				))
			) );
			
			
			vc_map( array(
				"base" => "trx_slider_item",
				"name" => __("Slide", 'blessing'),
				"description" => __("Slider item - single slide", 'blessing'),
				"show_settings_on_create" => true,
				"content_element" => true,
				"is_container" => false,
				'icon' => 'icon_trx_slider_item',
				"as_child" => array('only' => 'trx_slider'),
				"as_parent" => array('except' => 'trx_slider'),
				"params" => array(
					array(
						"param_name" => "src",
						"heading" => __("URL (source) for image file", 'blessing'),
						"description" => __("Select or upload image or write URL from other site for the current slide", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Slider extends ANCORA_VC_ShortCodeCollection {}
			class WPBakeryShortCode_Trx_Slider_Item extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Socials
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_socials",
				"name" => __("Social icons", 'blessing'),
				"description" => __("Custom social icons", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_socials',
				"class" => "trx_sc_collection trx_sc_socials",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"as_parent" => array('only' => 'trx_social_item'),
				"params" => array_merge(array(
					array(
						"param_name" => "size",
						"heading" => __("Icon's size", 'blessing'),
						"description" => __("Size of the icons", 'blessing'),
						"class" => "",
						"value" => array(
							__('Tiny', 'blessing') => 'tiny',
							__('Small', 'blessing') => 'small',
							__('Large', 'blessing') => 'large'
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "socials",
						"heading" => __("Manual socials list", 'blessing'),
						"description" => __("Custom list of social networks. For example: twitter=http://twitter.com/my_profile|facebook=http://facebooc.com/my_profile. If empty - use socials from Theme options.", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "custom",
						"heading" => __("Custom socials", 'blessing'),
						"description" => __("Make custom icons from inner shortcodes (prepare it on tabs)", 'blessing'),
						"class" => "",
						"value" => array(__('Custom socials', 'blessing') => 'yes'),
						"type" => "checkbox"
					),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				))
			) );
			
			
			vc_map( array(
				"base" => "trx_social_item",
				"name" => __("Custom social item", 'blessing'),
				"description" => __("Custom social item: name, profile url and icon url", 'blessing'),
				"show_settings_on_create" => true,
				"content_element" => true,
				"is_container" => false,
				'icon' => 'icon_trx_social_item',
				"as_child" => array('only' => 'trx_socials'),
				"as_parent" => array('except' => 'trx_socials'),
				"params" => array(
					array(
						"param_name" => "name",
						"heading" => __("Social name", 'blessing'),
						"description" => __("Name (slug) of the social network (twitter, facebook, linkedin, etc.)", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "url",
						"heading" => __("Your profile URL", 'blessing'),
						"description" => __("URL of your profile in specified social network", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "icon",
						"heading" => __("URL (source) for icon file", 'blessing'),
						"description" => __("Select or upload image or write URL from other site for the current social icon", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					)
				)
			) );
			
			class WPBakeryShortCode_Trx_Socials extends ANCORA_VC_ShortCodeCollection {}
			class WPBakeryShortCode_Trx_Social_Item extends ANCORA_VC_ShortCodeSingle {}
			

			
			
			
			
			
			// Table
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_table",
				"name" => __("Table", 'blessing'),
				"description" => __("Insert a table", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_table',
				"class" => "trx_sc_container trx_sc_table",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "align",
						"heading" => __("Cells content alignment", 'blessing'),
						"description" => __("Select alignment for each table cell", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "content",
						"heading" => __("Table content", 'blessing'),
						"description" => __("Content, created with any table-generator", 'blessing'),
						"class" => "",
						"value" => "Paste here table content, generated on one of many public internet resources, for example: http://www.impressivewebs.com/html-table-code-generator/ or http://html-tables.com/",
						/*"holder" => "div",*/
						"type" => "textarea_html"
					),
					ancora_vc_width(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'js_view' => 'VcTrxTextContainerView'
			) );
			
			class WPBakeryShortCode_Trx_Table extends ANCORA_VC_ShortCodeContainer {}
			
			
			
			
			
			
			
			// Tabs
			//-------------------------------------------------------------------------------------
			
			$tab_id_1 = 'sc_tab_'.time() . '_1_' . rand( 0, 100 );
			$tab_id_2 = 'sc_tab_'.time() . '_2_' . rand( 0, 100 );
			vc_map( array(
				"base" => "trx_tabs",
				"name" => __("Tabs", 'blessing'),
				"description" => __("Tabs", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_tabs',
				"class" => "trx_sc_collection trx_sc_tabs",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => false,
				"as_parent" => array('only' => 'trx_tab'),
				"params" => array(
					array(
						"param_name" => "style",
						"heading" => __("Tabs style", 'blessing'),
						"description" => __("Select style of tabs items", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
							__('Style 1', 'blessing') => '1',
							__('Style 2', 'blessing') => '2'
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "initial",
						"heading" => __("Initially opened tab", 'blessing'),
						"description" => __("Number of initially opened tab", 'blessing'),
						"class" => "",
						"value" => 1,
						"type" => "textfield"
					),
					array(
						"param_name" => "scroll",
						"heading" => __("Scroller", 'blessing'),
						"description" => __("Use scroller to show tab content (height parameter required)", 'blessing'),
						"class" => "",
						"value" => array("Use scroller" => "yes" ),
						"type" => "checkbox"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'default_content' => '
					[trx_tab title="' . __( 'Tab 1', 'blessing' ) . '" tab_id="'.esc_attr($tab_id_1).'"][/trx_tab]
					[trx_tab title="' . __( 'Tab 2', 'blessing' ) . '" tab_id="'.esc_attr($tab_id_2).'"][/trx_tab]
				',
				"custom_markup" => '
					<div class="wpb_tabs_holder wpb_holder vc_container_for_children">
						<ul class="tabs_controls">
						</ul>
						%content%
					</div>
				',
				'js_view' => 'VcTrxTabsView'
			) );
			
			
			vc_map( array(
				"base" => "trx_tab",
				"name" => __("Tab item", 'blessing'),
				"description" => __("Single tab item", 'blessing'),
				"show_settings_on_create" => true,
				"class" => "trx_sc_collection trx_sc_tab",
				"content_element" => true,
				"is_container" => true,
				'icon' => 'icon_trx_tab',
				"as_child" => array('only' => 'trx_tabs'),
				"as_parent" => array('except' => 'trx_tabs'),
				"params" => array(
					array(
						"param_name" => "title",
						"heading" => __("Tab title", 'blessing'),
						"description" => __("Title for current tab", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "tab_id",
						"heading" => __("Tab ID", 'blessing'),
						"description" => __("ID for current tab (required). Please, start it from letter.", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
			  'js_view' => 'VcTrxTabView'
			) );
			class WPBakeryShortCode_Trx_Tabs extends ANCORA_VC_ShortCodeTabs {}
			class WPBakeryShortCode_Trx_Tab extends ANCORA_VC_ShortCodeTab {}
			
			
			
			
			// Team
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_team",
				"name" => __("Team", 'blessing'),
				"description" => __("Insert team members", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_team',
				"class" => "trx_sc_columns trx_sc_team",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"as_parent" => array('only' => 'trx_team_item'),
				"params" => array(
					array(
						"param_name" => "style",
						"heading" => __("Team style", 'blessing'),
						"description" => __("Select style to display team members", 'blessing'),
						"class" => "",
						"admin_label" => true,
						"value" => array(
							__('Style 1', 'blessing') => 1,
							__('Style 2', 'blessing') => 2
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "columns",
						"heading" => __("Columns", 'blessing'),
						"description" => __("How many columns use to show team members", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "3",
						"type" => "textfield"
					),
					array(
						"param_name" => "custom",
						"heading" => __("Custom", 'blessing'),
						"description" => __("Allow get team members from inner shortcodes (custom) or get it from specified group (cat)", 'blessing'),
						"class" => "",
						"value" => array("Custom members" => "yes" ),
						"type" => "checkbox"
					),
					array(
						"param_name" => "cat",
						"heading" => __("Categories", 'blessing'),
						"description" => __("Put here comma separated categories (ids or slugs) to show team members. If empty - select team members from any category (group) or from IDs list", 'blessing'),
						"group" => __('Query', 'blessing'),
						'dependency' => array(
							'element' => 'custom',
							'is_empty' => true
						),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "count",
						"heading" => __("Number of posts", 'blessing'),
						"description" => __("How many posts will be displayed? If used IDs - this parameter ignored.", 'blessing'),
						"group" => __('Query', 'blessing'),
						'dependency' => array(
							'element' => 'custom',
							'is_empty' => true
						),
						"class" => "",
						"value" => "3",
						"type" => "textfield"
					),
					array(
						"param_name" => "offset",
						"heading" => __("Offset before select posts", 'blessing'),
						"description" => __("Skip posts before select next part.", 'blessing'),
						"group" => __('Query', 'blessing'),
						'dependency' => array(
							'element' => 'custom',
							'is_empty' => true
						),
						"class" => "",
						"value" => "0",
						"type" => "textfield"
					),
					array(
						"param_name" => "orderby",
						"heading" => __("Post sorting", 'blessing'),
						"description" => __("Select desired posts sorting method", 'blessing'),
						"group" => __('Query', 'blessing'),
						'dependency' => array(
							'element' => 'custom',
							'is_empty' => true
						),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['sorting']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "order",
						"heading" => __("Post order", 'blessing'),
						"description" => __("Select desired posts order", 'blessing'),
						"group" => __('Query', 'blessing'),
						'dependency' => array(
							'element' => 'custom',
							'is_empty' => true
						),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['ordering']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "ids",
						"heading" => __("Team member's IDs list", 'blessing'),
						"description" => __("Comma separated list of team members's ID. If set - parameters above (category, count, order, etc.)  are ignored!", 'blessing'),
						"group" => __('Query', 'blessing'),
						'dependency' => array(
							'element' => 'custom',
							'is_empty' => true
						),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'default_content' => '
					[trx_team_item user="' . __( 'Member 1', 'blessing' ) . '"][/trx_team_item]
					[trx_team_item user="' . __( 'Member 2', 'blessing' ) . '"][/trx_team_item]
				',
				'js_view' => 'VcTrxColumnsView'
			) );
			
			
			vc_map( array(
				"base" => "trx_team_item",
				"name" => __("Team member", 'blessing'),
				"description" => __("Team member - all data pull out from it account on your site", 'blessing'),
				"show_settings_on_create" => true,
				"class" => "trx_sc_item trx_sc_column_item trx_sc_team_item",
				"content_element" => true,
				"is_container" => false,
				'icon' => 'icon_trx_team_item',
				"as_child" => array('only' => 'trx_team'),
				"as_parent" => array('except' => 'trx_team'),
				"params" => array(
					array(
						"param_name" => "user",
						"heading" => __("Registered user", 'blessing'),
						"description" => __("Select one of registered users (if present) or put name, position, etc. in fields below", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['users']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "member",
						"heading" => __("Team member", 'blessing'),
						"description" => __("Select one of team members (if present) or put name, position, etc. in fields below", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['members']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "link",
						"heading" => __("Link", 'blessing'),
						"description" => __("Link on team member's personal page", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "name",
						"heading" => __("Name", 'blessing'),
						"description" => __("Team member's name", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "position",
						"heading" => __("Position", 'blessing'),
						"description" => __("Team member's position", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "email",
						"heading" => __("E-mail", 'blessing'),
						"description" => __("Team member's e-mail", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "photo",
						"heading" => __("Member's Photo", 'blessing'),
						"description" => __("Team member's photo (avatar", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "socials",
						"heading" => __("Socials", 'blessing'),
						"description" => __("Team member's socials icons: name=url|name=url... For example: facebook=http://facebook.com/myaccount|twitter=http://twitter.com/myaccount", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Team extends ANCORA_VC_ShortCodeColumns {}
			class WPBakeryShortCode_Trx_Team_Item extends ANCORA_VC_ShortCodeItem {}
			
			
			
			
			
			
			
			// Testimonials
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_testimonials",
				"name" => __("Testimonials", 'blessing'),
				"description" => __("Insert testimonials slider", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_testimonials',
				"class" => "trx_sc_collection trx_sc_testimonials",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => true,
				"as_parent" => array('only' => 'trx_testimonials_item'),
				"params" => array(
					array(
						"param_name" => "controls",
						"heading" => __("Show arrows", 'blessing'),
						"description" => __("Show control buttons", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['yes_no']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "interval",
						"heading" => __("Testimonials change interval", 'blessing'),
						"description" => __("Testimonials change interval (in milliseconds: 1000ms = 1s)", 'blessing'),
						"class" => "",
						"value" => "7000",
						"type" => "textfield"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Alignment of the testimonials block", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "autoheight",
						"heading" => __("Autoheight", 'blessing'),
						"description" => __("Change whole slider's height (make it equal current slide's height)", 'blessing'),
						"class" => "",
						"value" => array("Autoheight" => "yes" ),
						"type" => "checkbox"
					),
					array(
						"param_name" => "custom",
						"heading" => __("Custom", 'blessing'),
						"description" => __("Allow get testimonials from inner shortcodes (custom) or get it from specified group (cat)", 'blessing'),
						"class" => "",
						"value" => array("Custom slides" => "yes" ),
						"type" => "checkbox"
					),
					array(
						"param_name" => "cat",
						"heading" => __("Categories", 'blessing'),
						"description" => __("Select categories (groups) to show testimonials. If empty - select testimonials from any category (group) or from IDs list", 'blessing'),
						"group" => __('Query', 'blessing'),
						'dependency' => array(
							'element' => 'custom',
							'is_empty' => true
						),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "count",
						"heading" => __("Number of posts", 'blessing'),
						"description" => __("How many posts will be displayed? If used IDs - this parameter ignored.", 'blessing'),
						"group" => __('Query', 'blessing'),
						'dependency' => array(
							'element' => 'custom',
							'is_empty' => true
						),
						"class" => "",
						"value" => "3",
						"type" => "textfield"
					),
					array(
						"param_name" => "offset",
						"heading" => __("Offset before select posts", 'blessing'),
						"description" => __("Skip posts before select next part.", 'blessing'),
						"group" => __('Query', 'blessing'),
						'dependency' => array(
							'element' => 'custom',
							'is_empty' => true
						),
						"class" => "",
						"value" => "0",
						"type" => "textfield"
					),
					array(
						"param_name" => "orderby",
						"heading" => __("Post sorting", 'blessing'),
						"description" => __("Select desired posts sorting method", 'blessing'),
						"group" => __('Query', 'blessing'),
						'dependency' => array(
							'element' => 'custom',
							'is_empty' => true
						),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['sorting']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "order",
						"heading" => __("Post order", 'blessing'),
						"description" => __("Select desired posts order", 'blessing'),
						"group" => __('Query', 'blessing'),
						'dependency' => array(
							'element' => 'custom',
							'is_empty' => true
						),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['ordering']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "ids",
						"heading" => __("Post IDs list", 'blessing'),
						"description" => __("Comma separated list of posts ID. If set - parameters above are ignored!", 'blessing'),
						"group" => __('Query', 'blessing'),
						'dependency' => array(
							'element' => 'custom',
							'is_empty' => true
						),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_tint",
						"heading" => __("Background tint", 'blessing'),
						"description" => __("Main background tint: dark or light", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['tint']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "bg_color",
						"heading" => __("Background color", 'blessing'),
						"description" => __("Any background color for this section", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_image",
						"heading" => __("Background image URL", 'blessing'),
						"description" => __("Select background image from library for this section", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "bg_overlay",
						"heading" => __("Overlay", 'blessing'),
						"description" => __("Overlay color opacity (from 0.0 to 1.0)", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_texture",
						"heading" => __("Texture", 'blessing'),
						"description" => __("Texture style from 1 to 11. Empty or 0 - without texture.", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			
			vc_map( array(
				"base" => "trx_testimonials_item",
				"name" => __("Testimonial", 'blessing'),
				"description" => __("Single testimonials item", 'blessing'),
				"show_settings_on_create" => true,
				"class" => "trx_sc_container trx_sc_testimonials_item",
				"content_element" => true,
				"is_container" => true,
				'icon' => 'icon_trx_testimonials_item',
				"as_child" => array('only' => 'trx_testimonials'),
				"as_parent" => array('except' => 'trx_testimonials'),
				"params" => array(
					array(
						"param_name" => "author",
						"heading" => __("Author", 'blessing'),
						"description" => __("Name of the testimonmials author", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "link",
						"heading" => __("Link", 'blessing'),
						"description" => __("Link URL to the testimonmials author page", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "email",
						"heading" => __("E-mail", 'blessing'),
						"description" => __("E-mail of the testimonmials author", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "photo",
						"heading" => __("Photo", 'blessing'),
						"description" => __("Select or upload photo of testimonmials author or write URL of photo from other site", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
//					array(
//						"param_name" => "content",
//						"heading" => __("Testimonials text", 'blessing'),
//						"description" => __("Current testimonials text", 'blessing'),
//						"class" => "",
//						"value" => "",
//						"type" => "textarea_html"
//					),
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'js_view' => 'VcTrxTextContainerView'
			) );
			
			class WPBakeryShortCode_Trx_Testimonials extends ANCORA_VC_ShortCodeColumns {}
			class WPBakeryShortCode_Trx_Testimonials_Item extends ANCORA_VC_ShortCodeContainer {}
			
			
			
			
			
			
			
			// Title
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_title",
				"name" => __("Title", 'blessing'),
				"description" => __("Create header tag (1-6 level) with many styles", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_title',
				"class" => "trx_sc_single trx_sc_title",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "content",
						"heading" => __("Title content", 'blessing'),
						"description" => __("Title content", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textarea_html"
					),
					array(
						"param_name" => "type",
						"heading" => __("Title type", 'blessing'),
						"description" => __("Title type (header level)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
							__('Header 1', 'blessing') => '1',
							__('Header 2', 'blessing') => '2',
							__('Header 3', 'blessing') => '3',
							__('Header 4', 'blessing') => '4',
							__('Header 5', 'blessing') => '5',
							__('Header 6', 'blessing') => '6'
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "style",
						"heading" => __("Title style", 'blessing'),
						"description" => __("Title style: only text (regular) or with icon/image (iconed)", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
							__('Regular', 'blessing') => 'regular',
							__('Underline', 'blessing') => 'underline',
							__('Divider', 'blessing') => 'divider',
							__('With icon (image)', 'blessing') => 'iconed'
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Title text alignment", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "font_size",
						"heading" => __("Font size", 'blessing'),
						"description" => __("Custom font size. If empty - use theme default", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "font_weight",
						"heading" => __("Font weight", 'blessing'),
						"description" => __("Custom font weight. If empty or inherit - use theme default", 'blessing'),
						"class" => "",
						"value" => array(
							__('Default', 'blessing') => 'inherit',
							__('Thin (100)', 'blessing') => '100',
							__('Light (300)', 'blessing') => '300',
							__('Normal (400)', 'blessing') => '400',
							__('Semibold (600)', 'blessing') => '600',
							__('Bold (700)', 'blessing') => '700',
							__('Black (900)', 'blessing') => '900'
						),
						"type" => "dropdown"
					),
                    array(
                        "param_name" => "fig_border",
                        "heading" => __("Figure bottom border", 'blessing'),
                        "description" => __("Apply a figure bottom border", 'blessing'),
                        "class" => "",
                        "value" => array('No' => '', 'Yes' => 'fig_border'),
                        "type" => "dropdown"
                    ),
					array(
						"param_name" => "color",
						"heading" => __("Title color", 'blessing'),
						"description" => __("Select color for the title", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "icon",
						"heading" => __("Title font icon", 'blessing'),
						"description" => __("Select font icon for the title from Fontello icons set (if style=iconed)", 'blessing'),
						"class" => "",
						"group" => __('Icon &amp; Image', 'blessing'),
						'dependency' => array(
							'element' => 'style',
							'value' => array('iconed')
						),
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					array(
						"param_name" => "image",
						"heading" => __("or image icon", 'blessing'),
						"description" => __("Select image icon for the title instead icon above (if style=iconed)", 'blessing'),
						"class" => "",
						"group" => __('Icon &amp; Image', 'blessing'),
						'dependency' => array(
							'element' => 'style',
							'value' => array('iconed')
						),
						"value" => $ANCORA_GLOBALS['sc_params']['images'],
						"type" => "dropdown"
					),
					array(
						"param_name" => "picture",
						"heading" => __("or select uploaded image", 'blessing'),
						"description" => __("Select or upload image or write URL from other site (if style=iconed)", 'blessing'),
						"group" => __('Icon &amp; Image', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "image_size",
						"heading" => __("Image (picture) size", 'blessing'),
						"description" => __("Select image (picture) size (if style=iconed)", 'blessing'),
						"group" => __('Icon &amp; Image', 'blessing'),
						"class" => "",
						"value" => array(
							__('Small', 'blessing') => 'small',
							__('Medium', 'blessing') => 'medium',
							__('Large', 'blessing') => 'large'
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "position",
						"heading" => __("Icon (image) position", 'blessing'),
						"description" => __("Select icon (image) position (if style=iconed)", 'blessing'),
						"group" => __('Icon &amp; Image', 'blessing'),
						"class" => "",
						"value" => array(
							__('Top', 'blessing') => 'top',
							__('Left', 'blessing') => 'left'
						),
						"type" => "dropdown"
					),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'js_view' => 'VcTrxTextView'
			) );
			
			class WPBakeryShortCode_Trx_Title extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Toggles
			//-------------------------------------------------------------------------------------
				
			vc_map( array(
				"base" => "trx_toggles",
				"name" => __("Toggles", 'blessing'),
				"description" => __("Toggles items", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_toggles',
				"class" => "trx_sc_collection trx_sc_toggles",
				"content_element" => true,
				"is_container" => true,
				"show_settings_on_create" => false,
				"as_parent" => array('only' => 'trx_toggles_item'),
				"params" => array(
					array(
						"param_name" => "style",
						"heading" => __("Toggles style", 'blessing'),
						"description" => __("Select style for display toggles", 'blessing'),
						"class" => "",
						"admin_label" => true,
						"value" => array(
							__('Style 1', 'blessing') => 1,
							__('Style 2', 'blessing') => 2
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "counter",
						"heading" => __("Counter", 'blessing'),
						"description" => __("Display counter before each toggles title", 'blessing'),
						"class" => "",
						"value" => array("Add item numbers before each element" => "on" ),
						"type" => "checkbox"
					),
					array(
						"param_name" => "icon_closed",
						"heading" => __("Icon while closed", 'blessing'),
						"description" => __("Select icon for the closed toggles item from Fontello icons set", 'blessing'),
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					array(
						"param_name" => "icon_opened",
						"heading" => __("Icon while opened", 'blessing'),
						"description" => __("Select icon for the opened toggles item from Fontello icons set", 'blessing'),
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class']
				),
				'default_content' => '
					[trx_toggles_item title="' . __( 'Item 1 title', 'blessing' ) . '"][/trx_toggles_item]
					[trx_toggles_item title="' . __( 'Item 2 title', 'blessing' ) . '"][/trx_toggles_item]
				',
				"custom_markup" => '
					<div class="wpb_accordion_holder wpb_holder clearfix vc_container_for_children">
						%content%
					</div>
					<div class="tab_controls">
						<button class="add_tab" title="'.__("Add item", 'blessing').'">'.__("Add item", 'blessing').'</button>
					</div>
				',
				'js_view' => 'VcTrxTogglesView'
			) );
			
			
			vc_map( array(
				"base" => "trx_toggles_item",
				"name" => __("Toggles item", 'blessing'),
				"description" => __("Single toggles item", 'blessing'),
				"show_settings_on_create" => true,
				"content_element" => true,
				"is_container" => true,
				'icon' => 'icon_trx_toggles_item',
				"as_child" => array('only' => 'trx_toggles'),
				"as_parent" => array('except' => 'trx_toggles'),
				"params" => array(
					array(
						"param_name" => "title",
						"heading" => __("Title", 'blessing'),
						"description" => __("Title for current toggles item", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "open",
						"heading" => __("Open on show", 'blessing'),
						"description" => __("Open current toggle item on show", 'blessing'),
						"class" => "",
						"value" => array("Opened" => "yes" ),
						"type" => "checkbox"
					),
					array(
						"param_name" => "icon_closed",
						"heading" => __("Icon while closed", 'blessing'),
						"description" => __("Select icon for the closed toggles item from Fontello icons set", 'blessing'),
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					array(
						"param_name" => "icon_opened",
						"heading" => __("Icon while opened", 'blessing'),
						"description" => __("Select icon for the opened toggles item from Fontello icons set", 'blessing'),
						"class" => "",
						"value" => $ANCORA_GLOBALS['sc_params']['icons'],
						"type" => "dropdown"
					),
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
				'js_view' => 'VcTrxTogglesTabView'
			) );
			class WPBakeryShortCode_Trx_Toggles extends ANCORA_VC_ShortCodeToggles {}
			class WPBakeryShortCode_Trx_Toggles_Item extends ANCORA_VC_ShortCodeTogglesItem {}
			
			
			
			
			
			
			// Twitter
			//-------------------------------------------------------------------------------------

			vc_map( array(
				"base" => "trx_twitter",
				"name" => __("Twitter", 'blessing'),
				"description" => __("Insert twitter feed into post (page)", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_twitter',
				"class" => "trx_sc_single trx_sc_twitter",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "user",
						"heading" => __("Twitter Username", 'blessing'),
						"description" => __("Your username in the twitter account. If empty - get it from Theme Options.", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "consumer_key",
						"heading" => __("Consumer Key", 'blessing'),
						"description" => __("Consumer Key from the twitter account", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "consumer_secret",
						"heading" => __("Consumer Secret", 'blessing'),
						"description" => __("Consumer Secret from the twitter account", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "token_key",
						"heading" => __("Token Key", 'blessing'),
						"description" => __("Token Key from the twitter account", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "token_secret",
						"heading" => __("Token Secret", 'blessing'),
						"description" => __("Token Secret from the twitter account", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "count",
						"heading" => __("Tweets number", 'blessing'),
						"description" => __("Number tweets to show", 'blessing'),
						"class" => "",
						"divider" => true,
						"value" => 3,
						"type" => "textfield"
					),
					array(
						"param_name" => "controls",
						"heading" => __("Show arrows", 'blessing'),
						"description" => __("Show control buttons", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['yes_no']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "interval",
						"heading" => __("Tweets change interval", 'blessing'),
						"description" => __("Tweets change interval (in milliseconds: 1000ms = 1s)", 'blessing'),
						"class" => "",
						"value" => "7000",
						"type" => "textfield"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Alignment of the tweets block", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "autoheight",
						"heading" => __("Autoheight", 'blessing'),
						"description" => __("Change whole slider's height (make it equal current slide's height)", 'blessing'),
						"class" => "",
						"value" => array("Autoheight" => "yes" ),
						"type" => "checkbox"
					),
					array(
						"param_name" => "bg_tint",
						"heading" => __("Background tint", 'blessing'),
						"description" => __("Main background tint: dark or light", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['tint']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "bg_color",
						"heading" => __("Background color", 'blessing'),
						"description" => __("Any background color for this section", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "colorpicker"
					),
					array(
						"param_name" => "bg_image",
						"heading" => __("Background image URL", 'blessing'),
						"description" => __("Select background image from library for this section", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "bg_overlay",
						"heading" => __("Overlay", 'blessing'),
						"description" => __("Overlay color opacity (from 0.0 to 1.0)", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_texture",
						"heading" => __("Texture", 'blessing'),
						"description" => __("Texture style from 1 to 11. Empty or 0 - without texture.", 'blessing'),
						"group" => __('Colors and Images', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				),
			) );
			
			class WPBakeryShortCode_Trx_Twitter extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Video
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_video",
				"name" => __("Video", 'blessing'),
				"description" => __("Insert video player", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_video',
				"class" => "trx_sc_single trx_sc_video",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "url",
						"heading" => __("URL for video file", 'blessing'),
						"description" => __("Paste URL for video file", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "ratio",
						"heading" => __("Ratio", 'blessing'),
						"description" => __("Select ratio for display video", 'blessing'),
						"class" => "",
						"value" => array(
							__('16:9', 'blessing') => "16:9",
							__('4:3', 'blessing') => "4:3"
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "autoplay",
						"heading" => __("Autoplay video", 'blessing'),
						"description" => __("Autoplay video on page load", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array("Autoplay" => "on" ),
						"type" => "checkbox"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Select block alignment", 'blessing'),
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['align']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "image",
						"heading" => __("Cover image", 'blessing'),
						"description" => __("Select or upload image or write URL from other site for video preview", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "bg_image",
						"heading" => __("Background image", 'blessing'),
						"description" => __("Select or upload image or write URL from other site for video background. Attention! If you use background image - specify paddings below from background margins to video block in percents!", 'blessing'),
						"group" => __('Background', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "bg_top",
						"heading" => __("Top offset", 'blessing'),
						"description" => __("Top offset (padding) from background image to video block (in percent). For example: 3%", 'blessing'),
						"group" => __('Background', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_bottom",
						"heading" => __("Bottom offset", 'blessing'),
						"description" => __("Bottom offset (padding) from background image to video block (in percent). For example: 3%", 'blessing'),
						"group" => __('Background', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_left",
						"heading" => __("Left offset", 'blessing'),
						"description" => __("Left offset (padding) from background image to video block (in percent). For example: 20%", 'blessing'),
						"group" => __('Background', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_right",
						"heading" => __("Right offset", 'blessing'),
						"description" => __("Right offset (padding) from background image to video block (in percent). For example: 12%", 'blessing'),
						"group" => __('Background', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Video extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
			
			
			
			// Zoom
			//-------------------------------------------------------------------------------------
			
			vc_map( array(
				"base" => "trx_zoom",
				"name" => __("Zoom", 'blessing'),
				"description" => __("Insert the image with zoom/lens effect", 'blessing'),
				"category" => __('Content', 'blessing'),
				'icon' => 'icon_trx_zoom',
				"class" => "trx_sc_single trx_sc_zoom",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "effect",
						"heading" => __("Effect", 'blessing'),
						"description" => __("Select effect to display overlapping image", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array(
							__('Lens', 'blessing') => 'lens',
							__('Zoom', 'blessing') => 'zoom'
						),
						"type" => "dropdown"
					),
					array(
						"param_name" => "url",
						"heading" => __("Main image", 'blessing'),
						"description" => __("Select or upload main image", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "over",
						"heading" => __("Overlaping image", 'blessing'),
						"description" => __("Select or upload overlaping image", 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "align",
						"heading" => __("Alignment", 'blessing'),
						"description" => __("Float zoom to left or right side", 'blessing'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($ANCORA_GLOBALS['sc_params']['float']),
						"type" => "dropdown"
					),
					array(
						"param_name" => "bg_image",
						"heading" => __("Background image", 'blessing'),
						"description" => __("Select or upload image or write URL from other site for zoom background. Attention! If you use background image - specify paddings below from background margins to video block in percents!", 'blessing'),
						"group" => __('Background', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "attach_image"
					),
					array(
						"param_name" => "bg_top",
						"heading" => __("Top offset", 'blessing'),
						"description" => __("Top offset (padding) from background image to zoom block (in percent). For example: 3%", 'blessing'),
						"group" => __('Background', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_bottom",
						"heading" => __("Bottom offset", 'blessing'),
						"description" => __("Bottom offset (padding) from background image to zoom block (in percent). For example: 3%", 'blessing'),
						"group" => __('Background', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_left",
						"heading" => __("Left offset", 'blessing'),
						"description" => __("Left offset (padding) from background image to zoom block (in percent). For example: 20%", 'blessing'),
						"group" => __('Background', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					array(
						"param_name" => "bg_right",
						"heading" => __("Right offset", 'blessing'),
						"description" => __("Right offset (padding) from background image to zoom block (in percent). For example: 12%", 'blessing'),
						"group" => __('Background', 'blessing'),
						"class" => "",
						"value" => "",
						"type" => "textfield"
					),
					ancora_vc_width(),
					ancora_vc_height(),
					$ANCORA_GLOBALS['vc_params']['margin_top'],
					$ANCORA_GLOBALS['vc_params']['margin_bottom'],
					$ANCORA_GLOBALS['vc_params']['margin_left'],
					$ANCORA_GLOBALS['vc_params']['margin_right'],
					$ANCORA_GLOBALS['vc_params']['id'],
					$ANCORA_GLOBALS['vc_params']['class'],
					$ANCORA_GLOBALS['vc_params']['animation'],
					$ANCORA_GLOBALS['vc_params']['css']
				)
			) );
			
			class WPBakeryShortCode_Trx_Zoom extends ANCORA_VC_ShortCodeSingle {}
			

			do_action('ancora_action_shortcodes_list_vc');
			
			
			if (ancora_exists_woocommerce()) {
			
				// WooCommerce - Cart
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "woocommerce_cart",
					"name" => __("Cart", 'blessing'),
					"description" => __("WooCommerce shortcode: show cart page", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_wooc_cart',
					"class" => "trx_sc_alone trx_sc_woocommerce_cart",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => false,
					"params" => array()
				) );
				
				class WPBakeryShortCode_Woocommerce_Cart extends ANCORA_VC_ShortCodeAlone {}
			
			
				// WooCommerce - Checkout
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "woocommerce_checkout",
					"name" => __("Checkout", 'blessing'),
					"description" => __("WooCommerce shortcode: show checkout page", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_wooc_checkout',
					"class" => "trx_sc_alone trx_sc_woocommerce_checkout",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => false,
					"params" => array()
				) );
				
				class WPBakeryShortCode_Woocommerce_Checkout extends ANCORA_VC_ShortCodeAlone {}
			
			
				// WooCommerce - My Account
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "woocommerce_my_account",
					"name" => __("My Account", 'blessing'),
					"description" => __("WooCommerce shortcode: show my account page", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_wooc_my_account',
					"class" => "trx_sc_alone trx_sc_woocommerce_my_account",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => false,
					"params" => array()
				) );
				
				class WPBakeryShortCode_Woocommerce_My_Account extends ANCORA_VC_ShortCodeAlone {}
			
			
				// WooCommerce - Order Tracking
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "woocommerce_order_tracking",
					"name" => __("Order Tracking", 'blessing'),
					"description" => __("WooCommerce shortcode: show order tracking page", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_wooc_order_tracking',
					"class" => "trx_sc_alone trx_sc_woocommerce_order_tracking",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => false,
					"params" => array()
				) );
				
				class WPBakeryShortCode_Woocommerce_Order_Tracking extends ANCORA_VC_ShortCodeAlone {}
			
			
				// WooCommerce - Shop Messages
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "shop_messages",
					"name" => __("Shop Messages", 'blessing'),
					"description" => __("WooCommerce shortcode: show shop messages", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_wooc_shop_messages',
					"class" => "trx_sc_alone trx_sc_shop_messages",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => false,
					"params" => array()
				) );
				
				class WPBakeryShortCode_Shop_Messages extends ANCORA_VC_ShortCodeAlone {}
			
			
				// WooCommerce - Product Page
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "product_page",
					"name" => __("Product Page", 'blessing'),
					"description" => __("WooCommerce shortcode: display single product page", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_product_page',
					"class" => "trx_sc_single trx_sc_product_page",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => true,
					"params" => array(
						array(
							"param_name" => "sku",
							"heading" => __("SKU", 'blessing'),
							"description" => __("SKU code of displayed product", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "",
							"type" => "textfield"
						),
						array(
							"param_name" => "id",
							"heading" => __("ID", 'blessing'),
							"description" => __("ID of displayed product", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "",
							"type" => "textfield"
						),
						array(
							"param_name" => "posts_per_page",
							"heading" => __("Number", 'blessing'),
							"description" => __("How many products showed", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "1",
							"type" => "textfield"
						),
						array(
							"param_name" => "post_type",
							"heading" => __("Post type", 'blessing'),
							"description" => __("Post type for the WP query (leave 'product')", 'blessing'),
							"class" => "",
							"value" => "product",
							"type" => "textfield"
						),
						array(
							"param_name" => "post_status",
							"heading" => __("Post status", 'blessing'),
							"description" => __("Display posts only with this status", 'blessing'),
							"class" => "",
							"value" => array(
								__('Publish', 'blessing') => 'publish',
								__('Protected', 'blessing') => 'protected',
								__('Private', 'blessing') => 'private',
								__('Pending', 'blessing') => 'pending',
								__('Draft', 'blessing') => 'draft'
							),
							"type" => "dropdown"
						)
					)
				) );
				
				class WPBakeryShortCode_Product_Page extends ANCORA_VC_ShortCodeSingle {}
			
			
			
				// WooCommerce - Product
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "product",
					"name" => __("Product", 'blessing'),
					"description" => __("WooCommerce shortcode: display one product", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_product',
					"class" => "trx_sc_single trx_sc_product",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => true,
					"params" => array(
						array(
							"param_name" => "sku",
							"heading" => __("SKU", 'blessing'),
							"description" => __("Product's SKU code", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "",
							"type" => "textfield"
						),
						array(
							"param_name" => "id",
							"heading" => __("ID", 'blessing'),
							"description" => __("Product's ID", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "",
							"type" => "textfield"
						)
					)
				) );
				
				class WPBakeryShortCode_Product extends ANCORA_VC_ShortCodeSingle {}
			
			
				// WooCommerce - Best Selling Products
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "best_selling_products",
					"name" => __("Best Selling Products", 'blessing'),
					"description" => __("WooCommerce shortcode: show best selling products", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_best_selling_products',
					"class" => "trx_sc_single trx_sc_best_selling_products",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => true,
					"params" => array(
						array(
							"param_name" => "per_page",
							"heading" => __("Number", 'blessing'),
							"description" => __("How many products showed", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "columns",
							"heading" => __("Columns", 'blessing'),
							"description" => __("How many columns per row use for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						)
					)
				) );
				
				class WPBakeryShortCode_Best_Selling_Products extends ANCORA_VC_ShortCodeSingle {}
			
			
			
				// WooCommerce - Recent Products
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "recent_products",
					"name" => __("Recent Products", 'blessing'),
					"description" => __("WooCommerce shortcode: show recent products", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_recent_products',
					"class" => "trx_sc_single trx_sc_recent_products",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => true,
					"params" => array(
						array(
							"param_name" => "per_page",
							"heading" => __("Number", 'blessing'),
							"description" => __("How many products showed", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "columns",
							"heading" => __("Columns", 'blessing'),
							"description" => __("How many columns per row use for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "orderby",
							"heading" => __("Order by", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array(
								__('Date', 'blessing') => 'date',
								__('Title', 'blessing') => 'title'
							),
							"type" => "dropdown"
						),
						array(
							"param_name" => "order",
							"heading" => __("Order", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array_flip($ANCORA_GLOBALS['sc_params']['ordering']),
							"type" => "dropdown"
						)
					)
				) );
				
				class WPBakeryShortCode_Recent_Products extends ANCORA_VC_ShortCodeSingle {}
			
			
			
				// WooCommerce - Related Products
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "related_products",
					"name" => __("Related Products", 'blessing'),
					"description" => __("WooCommerce shortcode: show related products", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_related_products',
					"class" => "trx_sc_single trx_sc_related_products",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => true,
					"params" => array(
						array(
							"param_name" => "posts_per_page",
							"heading" => __("Number", 'blessing'),
							"description" => __("How many products showed", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "columns",
							"heading" => __("Columns", 'blessing'),
							"description" => __("How many columns per row use for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "orderby",
							"heading" => __("Order by", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array(
								__('Date', 'blessing') => 'date',
								__('Title', 'blessing') => 'title'
							),
							"type" => "dropdown"
						)
					)
				) );
				
				class WPBakeryShortCode_Related_Products extends ANCORA_VC_ShortCodeSingle {}
			
			
			
				// WooCommerce - Featured Products
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "featured_products",
					"name" => __("Featured Products", 'blessing'),
					"description" => __("WooCommerce shortcode: show featured products", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_featured_products',
					"class" => "trx_sc_single trx_sc_featured_products",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => true,
					"params" => array(
						array(
							"param_name" => "per_page",
							"heading" => __("Number", 'blessing'),
							"description" => __("How many products showed", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "columns",
							"heading" => __("Columns", 'blessing'),
							"description" => __("How many columns per row use for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "orderby",
							"heading" => __("Order by", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array(
								__('Date', 'blessing') => 'date',
								__('Title', 'blessing') => 'title'
							),
							"type" => "dropdown"
						),
						array(
							"param_name" => "order",
							"heading" => __("Order", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array_flip($ANCORA_GLOBALS['sc_params']['ordering']),
							"type" => "dropdown"
						)
					)
				) );
				
				class WPBakeryShortCode_Featured_Products extends ANCORA_VC_ShortCodeSingle {}
			
			
			
				// WooCommerce - Top Rated Products
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "top_rated_products",
					"name" => __("Top Rated Products", 'blessing'),
					"description" => __("WooCommerce shortcode: show top rated products", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_top_rated_products',
					"class" => "trx_sc_single trx_sc_top_rated_products",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => true,
					"params" => array(
						array(
							"param_name" => "per_page",
							"heading" => __("Number", 'blessing'),
							"description" => __("How many products showed", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "columns",
							"heading" => __("Columns", 'blessing'),
							"description" => __("How many columns per row use for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "orderby",
							"heading" => __("Order by", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array(
								__('Date', 'blessing') => 'date',
								__('Title', 'blessing') => 'title'
							),
							"type" => "dropdown"
						),
						array(
							"param_name" => "order",
							"heading" => __("Order", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array_flip($ANCORA_GLOBALS['sc_params']['ordering']),
							"type" => "dropdown"
						)
					)
				) );
				
				class WPBakeryShortCode_Top_Rated_Products extends ANCORA_VC_ShortCodeSingle {}
			
			
			
				// WooCommerce - Sale Products
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "sale_products",
					"name" => __("Sale Products", 'blessing'),
					"description" => __("WooCommerce shortcode: list products on sale", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_sale_products',
					"class" => "trx_sc_single trx_sc_sale_products",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => true,
					"params" => array(
						array(
							"param_name" => "per_page",
							"heading" => __("Number", 'blessing'),
							"description" => __("How many products showed", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "columns",
							"heading" => __("Columns", 'blessing'),
							"description" => __("How many columns per row use for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "orderby",
							"heading" => __("Order by", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array(
								__('Date', 'blessing') => 'date',
								__('Title', 'blessing') => 'title'
							),
							"type" => "dropdown"
						),
						array(
							"param_name" => "order",
							"heading" => __("Order", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array_flip($ANCORA_GLOBALS['sc_params']['ordering']),
							"type" => "dropdown"
						)
					)
				) );
				
				class WPBakeryShortCode_Sale_Products extends ANCORA_VC_ShortCodeSingle {}
			
			
			
				// WooCommerce - Product Category
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "product_category",
					"name" => __("Products from category", 'blessing'),
					"description" => __("WooCommerce shortcode: list products in specified category(-ies)", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_product_category',
					"class" => "trx_sc_single trx_sc_product_category",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => true,
					"params" => array(
						array(
							"param_name" => "per_page",
							"heading" => __("Number", 'blessing'),
							"description" => __("How many products showed", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "columns",
							"heading" => __("Columns", 'blessing'),
							"description" => __("How many columns per row use for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "orderby",
							"heading" => __("Order by", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array(
								__('Date', 'blessing') => 'date',
								__('Title', 'blessing') => 'title'
							),
							"type" => "dropdown"
						),
						array(
							"param_name" => "order",
							"heading" => __("Order", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array_flip($ANCORA_GLOBALS['sc_params']['ordering']),
							"type" => "dropdown"
						),
						array(
							"param_name" => "category",
							"heading" => __("Categories", 'blessing'),
							"description" => __("Comma separated category slugs", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "",
							"type" => "textfield"
						),
						array(
							"param_name" => "operator",
							"heading" => __("Operator", 'blessing'),
							"description" => __("Categories operator", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array(
								__('IN', 'blessing') => 'IN',
								__('NOT IN', 'blessing') => 'NOT IN',
								__('AND', 'blessing') => 'AND'
							),
							"type" => "dropdown"
						)
					)
				) );
				
				class WPBakeryShortCode_Product_Category extends ANCORA_VC_ShortCodeSingle {}
			
			
			
				// WooCommerce - Products
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "products",
					"name" => __("Products", 'blessing'),
					"description" => __("WooCommerce shortcode: list all products", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_products',
					"class" => "trx_sc_single trx_sc_products",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => true,
					"params" => array(
						array(
							"param_name" => "skus",
							"heading" => __("SKUs", 'blessing'),
							"description" => __("Comma separated SKU codes of products", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "",
							"type" => "textfield"
						),
						array(
							"param_name" => "ids",
							"heading" => __("IDs", 'blessing'),
							"description" => __("Comma separated ID of products", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "",
							"type" => "textfield"
						),
						array(
							"param_name" => "columns",
							"heading" => __("Columns", 'blessing'),
							"description" => __("How many columns per row use for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "orderby",
							"heading" => __("Order by", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array(
								__('Date', 'blessing') => 'date',
								__('Title', 'blessing') => 'title'
							),
							"type" => "dropdown"
						),
						array(
							"param_name" => "order",
							"heading" => __("Order", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array_flip($ANCORA_GLOBALS['sc_params']['ordering']),
							"type" => "dropdown"
						)
					)
				) );
				
				class WPBakeryShortCode_Products extends ANCORA_VC_ShortCodeSingle {}
			
			
			
			
				// WooCommerce - Product Attribute
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "product_attribute",
					"name" => __("Products by Attribute", 'blessing'),
					"description" => __("WooCommerce shortcode: show products with specified attribute", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_product_attribute',
					"class" => "trx_sc_single trx_sc_product_attribute",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => true,
					"params" => array(
						array(
							"param_name" => "per_page",
							"heading" => __("Number", 'blessing'),
							"description" => __("How many products showed", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "columns",
							"heading" => __("Columns", 'blessing'),
							"description" => __("How many columns per row use for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "orderby",
							"heading" => __("Order by", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array(
								__('Date', 'blessing') => 'date',
								__('Title', 'blessing') => 'title'
							),
							"type" => "dropdown"
						),
						array(
							"param_name" => "order",
							"heading" => __("Order", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array_flip($ANCORA_GLOBALS['sc_params']['ordering']),
							"type" => "dropdown"
						),
						array(
							"param_name" => "attribute",
							"heading" => __("Attribute", 'blessing'),
							"description" => __("Attribute name", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "",
							"type" => "textfield"
						),
						array(
							"param_name" => "filter",
							"heading" => __("Filter", 'blessing'),
							"description" => __("Attribute value", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "",
							"type" => "textfield"
						)
					)
				) );
				
				class WPBakeryShortCode_Product_Attribute extends ANCORA_VC_ShortCodeSingle {}
			
			
			
				// WooCommerce - Products Categories
				//-------------------------------------------------------------------------------------
				
				vc_map( array(
					"base" => "product_categories",
					"name" => __("Product Categories", 'blessing'),
					"description" => __("WooCommerce shortcode: show categories with products", 'blessing'),
					"category" => __('WooCommerce', 'blessing'),
					'icon' => 'icon_trx_product_categories',
					"class" => "trx_sc_single trx_sc_product_categories",
					"content_element" => true,
					"is_container" => false,
					"show_settings_on_create" => true,
					"params" => array(
						array(
							"param_name" => "number",
							"heading" => __("Number", 'blessing'),
							"description" => __("How many categories showed", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "columns",
							"heading" => __("Columns", 'blessing'),
							"description" => __("How many columns per row use for categories output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "4",
							"type" => "textfield"
						),
						array(
							"param_name" => "orderby",
							"heading" => __("Order by", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array(
								__('Date', 'blessing') => 'date',
								__('Title', 'blessing') => 'title'
							),
							"type" => "dropdown"
						),
						array(
							"param_name" => "order",
							"heading" => __("Order", 'blessing'),
							"description" => __("Sorting order for products output", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => array_flip($ANCORA_GLOBALS['sc_params']['ordering']),
							"type" => "dropdown"
						),
						array(
							"param_name" => "parent",
							"heading" => __("Parent", 'blessing'),
							"description" => __("Parent category slug", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "date",
							"type" => "textfield"
						),
						array(
							"param_name" => "ids",
							"heading" => __("IDs", 'blessing'),
							"description" => __("Comma separated ID of products", 'blessing'),
							"admin_label" => true,
							"class" => "",
							"value" => "",
							"type" => "textfield"
						),
						array(
							"param_name" => "hide_empty",
							"heading" => __("Hide empty", 'blessing'),
							"description" => __("Hide empty categories", 'blessing'),
							"class" => "",
							"value" => array("Hide empty" => "1" ),
							"type" => "checkbox"
						)
					)
				) );
				
				class WPBakeryShortCode_Products_Categories extends ANCORA_VC_ShortCodeSingle {}
			}

		}
	}
}
?>