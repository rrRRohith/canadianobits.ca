<?php
/* Calculated fields form support functions
------------------------------------------------------------------------------- */

// Theme init
if (!function_exists('ancora_calcfields_form_theme_setup')) {
	add_action( 'ancora_action_before_init_theme', 'ancora_calcfields_form_theme_setup', 1 );
	function ancora_calcfields_form_theme_setup() {
		// Register shortcode in the shortcodes list
		if (ancora_exists_calcfields_form()) {
            if (is_admin()) {
				add_filter( 'ancora_filter_importer_options',			'ancora_calcfields_form_importer_set_options', 10, 2 );
				add_action( 'ancora_action_importer_params',			'ancora_calcfields_form_importer_show_params', 10, 1 );
				add_action( 'ancora_action_importer_import',			'ancora_calcfields_form_importer_import', 10, 2 );
				add_action( 'ancora_action_importer_import_fields',	'ancora_calcfields_form_importer_import_fields', 10, 1 );
				add_action( 'ancora_action_importer_export',			'ancora_calcfields_form_importer_export', 10, 1 );
				add_action( 'ancora_action_importer_export_fields',	'ancora_calcfields_form_importer_export_fields', 10, 1 );
			}
		}
		if (is_admin()) {
			add_filter( 'ancora_filter_importer_required_plugins',	'ancora_calcfields_form_importer_required_plugins', 10, 2 );
		}
	}
}

// Check if plugin installed and activated
if ( !function_exists( 'ancora_exists_calcfields_form' ) ) {
	function ancora_exists_calcfields_form() {
        return defined('CP_SCHEME');
	}
}

// One-click import support
//------------------------------------------------------------------------

// Check in the required plugins
if ( !function_exists( 'ancora_calcfields_form_importer_required_plugins' ) ) {
	//add_filter( 'ancora_filter_importer_required_plugins',	'ancora_calcfields_form_importer_required_plugins', 10, 2 );
	function ancora_calcfields_form_importer_required_plugins($not_installed='', $list='') {
		if (ancora_strpos($list, 'calcfields')!==false && !ancora_exists_calcfields_form() )
			$not_installed .= '<br>'.esc_html__('Calculated Fields Form', 'blessing');
		return $not_installed;
	}
}

// Set options for one-click importer
if ( !function_exists( 'ancora_calcfields_form_importer_set_options' ) ) {
	//add_filter( 'ancora_filter_importer_options',	'ancora_calcfields_form_importer_set_options', 10, 1 );
	function ancora_calcfields_form_importer_set_options($options=array()) {
        global $ANCORA_GLOBALS;
		if ( in_array('calculated-fields-form', $ANCORA_GLOBALS['required_plugins']) && ancora_exists_calcfields_form() ) {
			$options['additional_options'][]	= 'CP_CFF_LOAD_SCRIPTS';				// Add slugs to export options of this plugin
			$options['additional_options'][]	= 'CP_CALCULATEDFIELDSF_USE_CACHE';
			$options['additional_options'][]	= 'CP_CALCULATEDFIELDSF_EXCLUDE_CRAWLERS';
			if (is_array($options['files']) && count($options['files']) > 0) {
				foreach ($options['files'] as $k => $v) {
					$options['files'][$k]['file_with_calcfields_form'] = str_replace('name.ext', 'calcfields_form.txt', $v['file_with_']);
				}
			}
		}
		return $options;
	}
}

// Add checkbox to the one-click importer
if ( !function_exists( 'ancora_calcfields_form_importer_show_params' ) ) {
	//add_action( 'ancora_action_importer_params',	'ancora_calcfields_form_importer_show_params', 10, 1 );
	function ancora_calcfields_form_importer_show_params($importer) {
		$importer->show_importer_params(array(
			'slug' => 'calcfields_form',
			'title' => esc_html__('Import Calculated Fields Form', 'blessing'),
			'part' => 1
			));
	}
}

// Import posts
if ( !function_exists( 'ancora_calcfields_form_importer_import' ) ) {
	//add_action( 'ancora_action_importer_import',	'ancora_calcfields_form_importer_import', 10, 2 );
	function ancora_calcfields_form_importer_import($importer, $action) {
		if ( $action == 'import_calcfields_form' ) {
			$importer->response['start_from_id'] = 0;
			$importer->import_dump('calcfields_form', esc_html__('Calculated Fields Form', 'blessing'));
		}
	}
}

// Display import progress
if ( !function_exists( 'ancora_calcfields_form_importer_import_fields' ) ) {
	//add_action( 'ancora_action_importer_import_fields',	'ancora_calcfields_form_importer_import_fields', 10, 1 );
	function ancora_calcfields_form_importer_import_fields($importer) {
		$importer->show_importer_fields(array(
			'slug' => 'calcfields_form',
			'title' => esc_html__('Calculated Fields Form', 'blessing')
			));
	}
}

// Export posts
if ( !function_exists( 'ancora_calcfields_form_importer_export' ) ) {
	//add_action( 'ancora_action_importer_export',	'ancora_calcfields_form_importer_export', 10, 1 );
	function ancora_calcfields_form_importer_export($importer) {
		ancora_fpc(ancora_get_file_dir('core/core.importer/export/calcfields_form.txt'), serialize( array(
			CP_CALCULATEDFIELDSF_FORMS_TABLE => $importer->export_dump(CP_CALCULATEDFIELDSF_FORMS_TABLE)
			) )
		);
	}
}

// Display exported data in the fields
if ( !function_exists( 'ancora_calcfields_form_importer_export_fields' ) ) {
	//add_action( 'ancora_action_importer_export_fields',	'ancora_calcfields_form_importer_export_fields', 10, 1 );
	function ancora_calcfields_form_importer_export_fields($importer) {
		$importer->show_exporter_fields(array(
			'slug' => 'calcfields_form',
			'title' => esc_html__('Calculated Fields Form', 'blessing')
			));
	}
}
?>