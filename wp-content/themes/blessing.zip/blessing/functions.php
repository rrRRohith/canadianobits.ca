<?php
/**
 * Theme sprecific functions and definitions
 */


/* Theme setup section
------------------------------------------------------------------- */

// Set the content width based on the theme's design and stylesheet.
if ( ! isset( $content_width ) ) $content_width = 1170; /* pixels */

// Add theme specific actions and filters
// Attention! Function were add theme specific actions and filters handlers must have priority 1
if ( !function_exists( 'ancora_theme_setup' ) ) {
	add_action( 'ancora_action_before_init_theme', 'ancora_theme_setup', 1 );
	function ancora_theme_setup() {

		// Register theme menus
		add_filter( 'ancora_filter_add_theme_menus',		'ancora_add_theme_menus' );

		// Register theme sidebars
		add_filter( 'ancora_filter_add_theme_sidebars',	'ancora_add_theme_sidebars' );

        // Set options for importer
        add_filter( 'ancora_filter_importer_options',		'ancora_set_importer_options' );

		// Set theme name and folder (for the update notifier)
		add_filter('ancora_filter_update_notifier', 		'ancora_set_theme_names_for_updater');

		// Set list of the theme required custom fonts from folder /css/font-faces
		// Attention! Font's folder must have name equal to the font's name
		ancora_set_global('required_custom_fonts', array(
			'Amadeus'
			)
		);

        global $ANCORA_GLOBALS;
        $ANCORA_GLOBALS['demo_data_url'] = esc_url(ancora_get_protocol() . '://blessing.ancorathemes.com/demo/');
        $ANCORA_GLOBALS['required_plugins'] = array (
            'revslider',
            'ancora-utils',
            'woocommerce',
            'ancora-paypal-donation',
            'calculated-fields-form',
            'wp-instagram-widget',
            'visual_composer'
        );
	}
}


// Add/Remove theme nav menus
if ( !function_exists( 'ancora_add_theme_menus' ) ) {
	//add_filter( 'ancora_action_add_theme_menus', 'ancora_add_theme_menus' );
	function ancora_add_theme_menus($menus) {
		if (isset($menus['menu_side'])) unset($menus['menu_side']);
		return $menus;
	}
}


// Add theme specific widgetized areas
if ( !function_exists( 'ancora_add_theme_sidebars' ) ) {
	//add_filter( 'ancora_filter_add_theme_sidebars',	'ancora_add_theme_sidebars' );
	function ancora_add_theme_sidebars($sidebars=array()) {
		if (is_array($sidebars)) {
			$theme_sidebars = array(
				'sidebar_main'		=> __( 'Main Sidebar', 'blessing' ),
				'sidebar_footer'	=> __( 'Footer Sidebar', 'blessing' )
			);
			if (ancora_exists_woocommerce()) {
				$theme_sidebars['sidebar_cart']  = __( 'WooCommerce Cart Sidebar', 'blessing' );
			}
			$sidebars = array_merge($theme_sidebars, $sidebars);
		}
		return $sidebars;
	}
}


// Set theme name and folder (for the update notifier)
if ( !function_exists( 'ancora_set_theme_names_for_updater' ) ) {
	//add_filter('ancora_filter_update_notifier', 'ancora_set_theme_names_for_updater');
	function ancora_set_theme_names_for_updater($opt) {
		$opt['theme_name']   = 'Blessing';
		$opt['theme_folder'] = 'blessing';
		return $opt;
	}
}


function wpb_move_comment_field_to_bottom( $fields ) {
    $comment_field = $fields['comment'];
    unset( $fields['comment'] );
    $fields['comment'] = $comment_field;
    return $fields;
}

add_filter( 'comment_form_fields', 'wpb_move_comment_field_to_bottom' );


// One-click import support
//------------------------------------------------------------------------

// Set theme specific importer options
if ( !function_exists( 'ancora_set_importer_options' ) ) {
    //add_filter( 'ancora_filter_importer_options',	'ancora_set_importer_options' );
    function ancora_set_importer_options($options=array()) {
        if (is_array($options)) {
            global $ANCORA_GLOBALS;
            // Default demo
            $options['demo_url'] = $ANCORA_GLOBALS['demo_data_url'];
            // Default demo
            $options['files']['default']['title'] = esc_html__('Ancora Demo', 'blessing');
            $options['files']['default']['domain_dev'] = '';		// Developers domain
            $options['files']['default']['domain_demo']= esc_url(ancora_get_protocol().'://blessing.dv.ancorathemes.com');		// Demo-site domain
        }
        return $options;
    }
}

/* Include framework core files
------------------------------------------------------------------- */

require_once( get_template_directory().'/fw/loader.php' );
?>