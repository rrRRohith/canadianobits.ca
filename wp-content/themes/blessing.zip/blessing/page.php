<?php
/**
Template Name: Page
 */

get_template_part('single');
?>