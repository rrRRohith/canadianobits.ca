<?php
/**
Template Name: Team members list
 */
global $ANCORA_GLOBALS;
$ANCORA_GLOBALS['blog_filters'] = 'team';

get_template_part('blog');
?>