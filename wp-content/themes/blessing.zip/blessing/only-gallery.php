<?php
/*
Template Name: Only Gallery
*/

global $ANCORA_GLOBALS;
$ANCORA_GLOBALS['blog_filters'] = 'gallery';

get_template_part('blog');
?>