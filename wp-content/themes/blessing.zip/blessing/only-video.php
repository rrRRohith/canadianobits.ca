<?php
/*
Template Name: Only Video
*/

global $ANCORA_GLOBALS;
$ANCORA_GLOBALS['blog_filters'] = 'video';

get_template_part('blog');
?>